"use client"
import { NavigationContainer } from "@react-navigation/native"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import { createStackNavigator } from "@react-navigation/stack"
import { SafeAreaProvider } from "react-native-safe-area-context"
import { StatusBar } from "react-native"
import { Ionicons } from "@expo/vector-icons"

// Screens
import HomeScreen from "./src/screens/HomeScreen"
import MapScreen from "./src/screens/MapScreen"
import TripPlannerScreen from "./src/screens/TripPlannerScreen"
import ProfileScreen from "./src/screens/ProfileScreen"
import SettingsScreen from "./src/screens/SettingsScreen"
import AuthScreen from "./src/screens/AuthScreen"
import SearchScreen from "./src/screens/SearchScreen"
import OfflineMapsScreen from "./src/screens/OfflineMapsScreen"
import ARNavigationScreen from "./src/screens/ARNavigationScreen"
import RealTimeNavigationScreen from "./src/screens/RealTimeNavigationScreen"
import Map3DScreen from "./src/screens/Map3DScreen"
import AIPlannerScreen from "./src/screens/AIPlannerScreen"
import FoodDiscoveryScreen from "./src/screens/FoodDiscoveryScreen"
import ItineraryBuilderScreen from "./src/screens/ItineraryBuilderScreen"
import TripListsScreen from "./src/screens/TripListsScreen"
import DataExplorerScreen from "./src/screens/DataExplorerScreen"
import DataVisualizationScreen from "./src/screens/DataVisualizationScreen"

// Components
import BottomTabBar from "./src/components/BottomTabBar"

// Context
import { AuthProvider, useAuth } from "./src/context/AuthContext"

// Services
import { initializeDataIntegration } from "./src/services/data-integration"

const Tab = createBottomTabNavigator()
const Stack = createStackNavigator()

// Initialize data integration services
const dataIntegrationConfig = {
  apiKeys: {
    openWeatherMap: process.env.OPEN_WEATHER_MAP_API_KEY,
    googleMaps: process.env.GOOGLE_MAPS_API_KEY,
    booking: process.env.BOOKING_API_KEY,
    amadeus: process.env.AMADEUS_API_KEY,
    tripAdvisor: process.env.TRIP_ADVISOR_API_KEY,
    openAI: process.env.OPENAI_API_KEY,
  },
  endpoints: {
    weather: "https://api.openweathermap.org/data/2.5",
    maps: "https://maps.googleapis.com/maps/api",
    accommodation: "https://booking-com.p.rapidapi.com",
    flights: "https://test.api.amadeus.com/v2",
    attractions: "https://tripadvisor-com.p.rapidapi.com",
  },
  cacheOptions: {
    enabled: true,
    ttl: 3600, // 1 hour
  },
  offlineMode: false,
  debugMode: process.env.NODE_ENV === "development",
}

// Initialize data integration services
initializeDataIntegration(dataIntegrationConfig)

function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Auth" component={AuthScreen} />
    </Stack.Navigator>
  )
}

function MainTabs() {
  return (
    <Tab.Navigator
      tabBar={(props) => <BottomTabBar {...props} />}
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName

          if (route.name === "Home") {
            iconName = focused ? "home" : "home-outline"
          } else if (route.name === "Map") {
            iconName = focused ? "map" : "map-outline"
          } else if (route.name === "TripPlanner") {
            iconName = focused ? "calendar" : "calendar-outline"
          } else if (route.name === "Profile") {
            iconName = focused ? "person" : "person-outline"
          }

          return <Ionicons name={iconName} size={size} color={color} />
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Map" component={MapScreen} />
      <Tab.Screen name="TripPlanner" component={TripPlannerScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  )
}

function MainStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="MainTabs" component={MainTabs} options={{ headerShown: false }} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="Search" component={SearchScreen} />
      <Stack.Screen name="OfflineMaps" component={OfflineMapsScreen} />
      <Stack.Screen name="ARNavigation" component={ARNavigationScreen} />
      <Stack.Screen name="RealTimeNavigation" component={RealTimeNavigationScreen} />
      <Stack.Screen name="Map3D" component={Map3DScreen} />
      <Stack.Screen name="AIPlanner" component={AIPlannerScreen} />
      <Stack.Screen name="FoodDiscovery" component={FoodDiscoveryScreen} />
      <Stack.Screen name="ItineraryBuilder" component={ItineraryBuilderScreen} />
      <Stack.Screen name="TripLists" component={TripListsScreen} />
      <Stack.Screen name="DataExplorer" component={DataExplorerScreen} />
      <Stack.Screen name="DataVisualization" component={DataVisualizationScreen} />
    </Stack.Navigator>
  )
}

function AppNavigator() {
  const { isAuthenticated, isLoading } = useAuth()

  if (isLoading) {
    // You could return a loading screen here
    return null
  }

  return <NavigationContainer>{isAuthenticated ? <MainStack /> : <AuthStack />}</NavigationContainer>
}

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar barStyle="dark-content" />
      <AuthProvider>
        <AppNavigator />
      </AuthProvider>
    </SafeAreaProvider>
  )
}
