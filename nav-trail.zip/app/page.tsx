"use client"

import RouteSummary from "../src/components/RouteSummary"

export default function SyntheticV0PageForDeployment() {
  return <RouteSummary />
}