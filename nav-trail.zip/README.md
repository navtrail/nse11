# NavTrail - Advanced Travel Companion App

NavTrail is a comprehensive travel companion app built with React Native that helps users plan trips, navigate trails, discover new places, and manage their travel experiences.

## Features

- **Authentication**: Secure login and signup functionality
- **Profile Management**: View and edit user profile information
- **Trip Planning**: Plan trips with detailed itineraries
- **Map Integration**: Interactive maps with various viewing options
- **Offline Maps**: Download maps for offline use
- **AR Navigation**: Augmented reality navigation for trails
- **Real-time Navigation**: Turn-by-turn navigation with traffic updates
- **3D Maps**: 3D visualization of terrain and routes
- **AI Trip Planner**: AI-powered trip suggestions
- **Food Discovery**: Find restaurants and hidden gems
- **Itinerary Builder**: Create and manage trip itineraries
- **Trip Lists**: Save and organize favorite places
- **Data Explorer**: Explore travel data and statistics
- **Data Visualization**: Visualize travel patterns and trends

## Project Structure

\`\`\`
NavTrail/
├── App.tsx                  # Main application entry point
├── src/
│   ├── components/          # Reusable UI components
│   │   ├── SearchInput.tsx
│   │   ├── RouteSummary.tsx
│   │   └── BottomTabBar.tsx
│   ├── context/             # React Context providers
│   │   └── AuthContext.tsx
│   ├── screens/             # Application screens
│   │   ├── AuthScreen.tsx
│   │   ├── HomeScreen.tsx
│   │   ├── MapScreen.tsx
│   │   ├── TripPlannerScreen.tsx
│   │   ├── ProfileScreen.tsx
│   │   ├── SettingsScreen.tsx
│   │   ├── SearchScreen.tsx
│   │   ├── OfflineMapsScreen.tsx
│   │   ├── ARNavigationScreen.tsx
│   │   ├── RealTimeNavigationScreen.tsx
│   │   ├── Map3DScreen.tsx
│   │
