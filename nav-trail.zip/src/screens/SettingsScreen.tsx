"use client"

import { useState } from "react"
import { View, Text, StyleSheet, SafeAreaView, ScrollView, TouchableOpacity, Switch, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import BottomTabBar from "../components/BottomTabBar"

const SettingsScreen = ({ navigation }) => {
  const [settings, setSettings] = useState({
    notifications: true,
    locationTracking: true,
    darkMode: false,
    offlineMaps: true,
    metricUnits: true,
    saveTrailHistory: true,
    highQualityMaps: false,
    autoDownloadMaps: false,
  })

  const toggleSetting = (key) => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const clearCache = () => {
    Alert.alert("Clear Cache", "This will clear all cached map data. Are you sure?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Clear",
        style: "destructive",
        onPress: () => {
          // In a real app, this would clear the cache
          Alert.alert("Success", "Cache cleared successfully")
        },
      },
    ])
  }

  const settingsGroups = [
    {
      title: "General",
      settings: [
        {
          key: "notifications",
          label: "Push Notifications",
          icon: "notifications-outline",
          type: "toggle",
          value: settings.notifications,
        },
        {
          key: "locationTracking",
          label: "Location Tracking",
          icon: "location-outline",
          type: "toggle",
          value: settings.locationTracking,
        },
        {
          key: "darkMode",
          label: "Dark Mode",
          icon: "moon-outline",
          type: "toggle",
          value: settings.darkMode,
        },
        {
          key: "metricUnits",
          label: "Use Metric Units",
          icon: "speedometer-outline",
          type: "toggle",
          value: settings.metricUnits,
        },
      ],
    },
    {
      title: "Maps & Navigation",
      settings: [
        {
          key: "offlineMaps",
          label: "Enable Offline Maps",
          icon: "map-outline",
          type: "toggle",
          value: settings.offlineMaps,
        },
        {
          key: "highQualityMaps",
          label: "High Quality Maps",
          icon: "image-outline",
          type: "toggle",
          value: settings.highQualityMaps,
        },
        {
          key: "autoDownloadMaps",
          label: "Auto-Download Map Areas",
          icon: "download-outline",
          type: "toggle",
          value: settings.autoDownloadMaps,
        },
        {
          key: "clearCache",
          label: "Clear Map Cache",
          icon: "trash-outline",
          type: "button",
          action: clearCache,
        },
      ],
    },
    {
      title: "Privacy & Data",
      settings: [
        {
          key: "saveTrailHistory",
          label: "Save Trail History",
          icon: "footsteps-outline",
          type: "toggle",
          value: settings.saveTrailHistory,
        },
        {
          key: "privacyPolicy",
          label: "Privacy Policy",
          icon: "shield-outline",
          type: "link",
        },
        {
          key: "termsOfService",
          label: "Terms of Service",
          icon: "document-text-outline",
          type: "link",
        },
      ],
    },
    {
      title: "About",
      settings: [
        {
          key: "appVersion",
          label: "App Version",
          value: "1.0.0",
          type: "info",
        },
        {
          key: "contactSupport",
          label: "Contact Support",
          icon: "mail-outline",
          type: "link",
        },
        {
          key: "rateApp",
          label: "Rate the App",
          icon: "star-outline",
          type: "link",
        },
      ],
    },
  ]

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Settings</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content}>
        {settingsGroups.map((group, groupIndex) => (
          <View key={groupIndex} style={styles.settingsGroup}>
            <Text style={styles.groupTitle}>{group.title}</Text>
            <View style={styles.settingsContainer}>
              {group.settings.map((item, itemIndex) => (
                <TouchableOpacity
                  key={item.key}
                  style={[styles.settingItem, itemIndex === group.settings.length - 1 && styles.lastSettingItem]}
                  onPress={() => {
                    if (item.type === "button" && item.action) {
                      item.action()
                    } else if (item.type === "link") {
                      // Handle navigation to links
                    } else if (item.type === "toggle") {
                      toggleSetting(item.key)
                    }
                  }}
                  disabled={item.type === "info"}
                >
                  {item.icon && (
                    <Ionicons
                      name={item.icon}
                      size={22}
                      color={item.key === "clearCache" ? "#F44336" : "#4CAF50"}
                      style={styles.settingIcon}
                    />
                  )}
                  <View style={styles.settingContent}>
                    <Text style={[styles.settingLabel, item.key === "clearCache" && styles.dangerText]}>
                      {item.label}
                    </Text>
                    {item.type === "info" && item.value && <Text style={styles.settingValue}>{item.value}</Text>}
                  </View>
                  {item.type === "toggle" && (
                    <Switch
                      value={item.value}
                      onValueChange={() => toggleSetting(item.key)}
                      trackColor={{ false: "#E0E0E0", true: "#A5D6A7" }}
                      thumbColor={item.value ? "#4CAF50" : "#BDBDBD"}
                    />
                  )}
                  {item.type === "link" && <Ionicons name="chevron-forward" size={20} color="#BDBDBD" />}
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}
      </ScrollView>

      <BottomTabBar
        activeTab="Settings"
        onTabPress={(tab) => {
          if (tab !== "Settings") {
            navigation.navigate(tab)
          }
        }}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  placeholder: {
    width: 40,
  },
  content: {
    flex: 1,
  },
  settingsGroup: {
    marginBottom: 24,
  },
  groupTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#4CAF50",
    marginHorizontal: 16,
    marginBottom: 8,
  },
  settingsContainer: {
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    marginHorizontal: 16,
    overflow: "hidden",
  },
  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  lastSettingItem: {
    borderBottomWidth: 0,
  },
  settingIcon: {
    marginRight: 16,
  },
  settingContent: {
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    color: "#212121",
  },
  settingValue: {
    fontSize: 14,
    color: "#757575",
    marginTop: 2,
  },
  dangerText: {
    color: "#F44336",
  },
})

export default SettingsScreen
