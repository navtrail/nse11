"use client"

import { useState, useEffect, useRef } from "react"
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Dimensions, Platform, Animated } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import MapView, { PROVIDER_GOOGLE, Marker, Polyline, type MapMarker } from "react-native-maps"
import * as Location from "expo-location"
import { Audio } from "expo-av"
import { getDirections, getTrafficInfo } from "../services/navigation"
import { formatDistance, formatDuration } from "../utils/helpers"

const { width, height } = Dimensions.get("window")

const RealTimeNavigationScreen = ({ navigation, route }) => {
  const { destination, transportMode = "driving" } = route.params || {}
  const mapRef = useRef(null)
  const markerRef = useRef<MapMarker>(null)
  const [region, setRegion] = useState({
    latitude: 37.78825,
    longitude: -122.4324,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  })
  const [userLocation, setUserLocation] = useState(null)
  const [directions, setDirections] = useState(null)
  const [currentStep, setCurrentStep] = useState(0)
  const [remainingDistance, setRemainingDistance] = useState(0)
  const [remainingTime, setRemainingTime] = useState(0)
  const [isNavigating, setIsNavigating] = useState(true)
  const [trafficInfo, setTrafficInfo] = useState(null)
  const [mapStyle, setMapStyle] = useState("standard")
  const [sound, setSound] = useState(null)
  const [speedLimit, setSpeedLimit] = useState(55)
  const [currentSpeed, setCurrentSpeed] = useState(0)
  const [showSpeedWarning, setShowSpeedWarning] = useState(false)
  const [alternateRoutes, setAlternateRoutes] = useState([])
  const [showAlternateRoutes, setShowAlternateRoutes] = useState(false)

  // Animation for the next turn card
  const slideAnim = useRef(new Animated.Value(0)).current

  useEffect(() => {
    let locationSubscription
    let headingSubscription

    const startNavigation = async () => {
      try {
        // Request permissions
        const { status } = await Location.requestForegroundPermissionsAsync()
        if (status !== "granted") {
          console.error("Location permission denied")
          return
        }

        // Get initial location
        const location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.BestForNavigation,
        })
        const initialLocation = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        }
        setUserLocation(initialLocation)
        setRegion({
          ...initialLocation,
          latitudeDelta: 0.005,
          longitudeDelta: 0.005,
        })

        // Get directions
        if (destination) {
          const directionsData = await getDirections(initialLocation, destination, transportMode)
          setDirections(directionsData)
          setRemainingDistance(directionsData.distance)
          setRemainingTime(directionsData.duration)

          // Get traffic info
          const traffic = await getTrafficInfo(directionsData.route)
          setTrafficInfo(traffic)

          // Get alternate routes
          setAlternateRoutes(directionsData.alternateRoutes || [])

          // Fit map to show the route
          if (mapRef.current) {
            mapRef.current.fitToCoordinates([initialLocation, destination], {
              edgePadding: { top: 100, right: 50, bottom: 300, left: 50 },
              animated: true,
            })
          }
        }

        // Start location tracking
        locationSubscription = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.BestForNavigation,
            distanceInterval: 5,
            timeInterval: 1000,
          },
          (newLocation) => {
            const coords = {
              latitude: newLocation.coords.latitude,
              longitude: newLocation.coords.longitude,
            }
            setUserLocation(coords)
            setCurrentSpeed(newLocation.coords.speed * 2.23694) // Convert m/s to mph

            // Update map region to follow user
            setRegion({
              ...coords,
              latitudeDelta: 0.005,
              longitudeDelta: 0.005,
            })

            // Update remaining distance and time
            if (directions) {
              updateNavigationProgress(coords)
            }

            // Check speed limit
            if (currentSpeed > speedLimit + 5) {
              setShowSpeedWarning(true)
              playSpeedWarning()
            } else {
              setShowSpeedWarning(false)
            }

            // Animate marker rotation based on heading
            if (markerRef.current && newLocation.coords.heading) {
              markerRef.current.animateMarkerToCoordinate(coords, 0)
            }
          },
        )

        // Start heading tracking
        headingSubscription = await Location.watchHeadingAsync((heading) => {
          // Update map rotation to match heading
          if (mapRef.current) {
            mapRef.current.animateCamera({
              heading: heading.trueHeading,
              center: userLocation,
              pitch: 45,
              zoom: 18,
            })
          }
        })
      } catch (error) {
        console.error("Error starting navigation:", error)
      }
    }

    startNavigation()

    // Cleanup
    return () => {
      if (locationSubscription) {
        locationSubscription.remove()
      }
      if (headingSubscription) {
        headingSubscription.remove()
      }
      if (sound) {
        sound.unloadAsync()
      }
    }
  }, [destination, transportMode])

  // Animate the next turn card when step changes
  useEffect(() => {
    if (directions && directions.steps[currentStep]) {
      Animated.sequence([
        Animated.timing(slideAnim, {
          toValue: -50,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start()

      // Play voice guidance
      playVoiceGuidance(directions.steps[currentStep].instruction)
    }
  }, [currentStep])

  const updateNavigationProgress = (currentLocation) => {
    if (!directions || !directions.steps || directions.steps.length === 0) return

    // Calculate distance to next step
    const nextStepCoords = directions.steps[currentStep].startLocation
    const distanceToNextStep = calculateDistance(
      currentLocation.latitude,
      currentLocation.longitude,
      nextStepCoords.latitude,
      nextStepCoords.longitude,
    )

    // Update remaining distance and time
    const newRemainingDistance = directions.distance - distanceToNextStep
    setRemainingDistance(newRemainingDistance > 0 ? newRemainingDistance : 0)

    const newRemainingTime = (newRemainingDistance / directions.distance) * directions.duration
    setRemainingTime(newRemainingTime > 0 ? newRemainingTime : 0)

    // Check if we've reached the next step
    if (distanceToNextStep < 0.02) {
      // 20 meters threshold
      if (currentStep < directions.steps.length - 1) {
        setCurrentStep(currentStep + 1)
      } else if (distanceToNextStep < 0.01) {
        // Reached destination
        setIsNavigating(false)
        playArrivalSound()
      }
    }
  }

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371 // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1)
    const dLon = deg2rad(lon2 - lon1)
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    const d = R * c // Distance in km
    return d
  }

  const deg2rad = (deg) => {
    return deg * (Math.PI / 180)
  }

  const playVoiceGuidance = async (instruction) => {
    try {
      const { sound } = await Audio.Sound.createAsync(
        { uri: `https://api.voicerss.org/?key=YOUR_API_KEY&hl=en-us&src=${encodeURIComponent(instruction)}` },
        { shouldPlay: true },
      )
      setSound(sound)
    } catch (error) {
      console.error("Error playing voice guidance:", error)
    }
  }

  const playSpeedWarning = async () => {
    try {
      const { sound } = await Audio.Sound.createAsync(require("../../assets/sounds/speed-warning.mp3"), {
        shouldPlay: true,
      })
      setSound(sound)
    } catch (error) {
      console.error("Error playing speed warning:", error)
    }
  }

  const playArrivalSound = async () => {
    try {
      const { sound } = await Audio.Sound.createAsync(require("../../assets/sounds/arrival.mp3"), { shouldPlay: true })
      setSound(sound)
    } catch (error) {
      console.error("Error playing arrival sound:", error)
    }
  }

  const toggleMapStyle = () => {
    setMapStyle(mapStyle === "standard" ? "satellite" : "standard")
  }

  const selectAlternateRoute = (route) => {
    setDirections({
      ...directions,
      route: route.route,
      distance: route.distance,
      duration: route.duration,
    })
    setShowAlternateRoutes(false)
  }

  const getRouteColor = (index, isSelected) => {
    if (isSelected) return "#4CAF50"
    const colors = ["#2196F3", "#FF9800", "#9C27B0"]
    return colors[index % colors.length]
  }

  const renderTrafficOverlay = () => {
    if (!trafficInfo || !directions) return null

    return trafficInfo.segments.map((segment, index) => (
      <Polyline
        key={`traffic-${index}`}
        coordinates={segment.coordinates}
        strokeWidth={6}
        strokeColor={
          segment.level === "heavy"
            ? "#F44336"
            : segment.level === "moderate"
              ? "#FF9800"
              : segment.level === "light"
                ? "#4CAF50"
                : "#2196F3"
        }
        lineDashPattern={[1, 0]}
      />
    ))
  }

  const renderDirectionIcon = (maneuver) => {
    const icons = {
      straight: "arrow-up",
      "turn-left": "arrow-back",
      "turn-right": "arrow-forward",
      "turn-slight-left": "arrow-back",
      "turn-slight-right": "arrow-forward",
      "turn-sharp-left": "arrow-back",
      "turn-sharp-right": "arrow-forward",
      merge: "git-merge-outline",
      "roundabout-left": "refresh",
      "roundabout-right": "refresh",
      "uturn-left": "refresh",
      "uturn-right": "refresh",
      arrive: "location",
      depart: "flag",
    }
    return icons[maneuver] || "arrow-up"
  }

  return (
    <SafeAreaView style={styles.container}>
      <MapView
        ref={mapRef}
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        region={region}
        showsUserLocation={false}
        showsMyLocationButton={false}
        showsCompass={false}
        showsTraffic={false}
        showsBuildings={true}
        showsIndoors={true}
        mapType={mapStyle}
        followsUserLocation={true}
        pitchEnabled={true}
        rotateEnabled={true}
      >
        {userLocation && (
          <Marker ref={markerRef} coordinate={userLocation} anchor={{ x: 0.5, y: 0.5 }} flat={true}>
            <View style={styles.userMarker}>
              <Ionicons name="navigate" size={24} color="#4285F4" />
            </View>
          </Marker>
        )}

        {destination && (
          <Marker coordinate={destination} title="Destination">
            <View style={styles.destinationMarker}>
              <Ionicons name="location" size={30} color="#F44336" />
            </View>
          </Marker>
        )}

        {directions && !showAlternateRoutes && (
          <Polyline coordinates={directions.route} strokeWidth={6} strokeColor="#4CAF50" lineDashPattern={[1, 0]} />
        )}

        {showAlternateRoutes &&
          alternateRoutes.map((route, index) => (
            <Polyline
              key={`route-${index}`}
              coordinates={route.route}
              strokeWidth={6}
              strokeColor={getRouteColor(index, false)}
              lineDashPattern={[1, 0]}
              onPress={() => selectAlternateRoute(route)}
            />
          ))}

        {trafficInfo && renderTrafficOverlay()}
      </MapView>

      {/* Top Bar */}
      <View style={styles.topBar}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>

        <View style={styles.destinationInfo}>
          <Text style={styles.destinationName} numberOfLines={1}>
            {destination?.name || "Navigation"}
          </Text>
          <Text style={styles.eta}>
            ETA:{" "}
            {new Date(Date.now() + remainingTime * 1000).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </Text>
        </View>

        <TouchableOpacity style={styles.endButton} onPress={() => navigation.goBack()}>
          <Text style={styles.endButtonText}>End</Text>
        </TouchableOpacity>
      </View>

      {/* Next Turn Card */}
      {directions && directions.steps[currentStep] && (
        <Animated.View
          style={[
            styles.nextTurnCard,
            {
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.maneuverIconContainer}>
            <Ionicons name={renderDirectionIcon(directions.steps[currentStep].maneuver)} size={36} color="#fff" />
          </View>
          <View style={styles.nextTurnInfo}>
            <Text style={styles.nextTurnDistance}>{formatDistance(directions.steps[currentStep].distance)}</Text>
            <Text style={styles.nextTurnInstruction}>{directions.steps[currentStep].instruction}</Text>
          </View>
        </Animated.View>
      )}

      {/* Bottom Panel */}
      <View style={styles.bottomPanel}>
        <View style={styles.tripInfo}>
          <View style={styles.infoItem}>
            <Text style={styles.infoValue}>{formatDistance(remainingDistance)}</Text>
            <Text style={styles.infoLabel}>Remaining</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoValue}>{formatDuration(remainingTime)}</Text>
            <Text style={styles.infoLabel}>Time Left</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoValue}>{Math.round(currentSpeed)} mph</Text>
            <Text style={styles.infoLabel}>Speed</Text>
          </View>
        </View>

        <View style={styles.controlsRow}>
          <TouchableOpacity style={styles.controlButton} onPress={toggleMapStyle}>
            <Ionicons name={mapStyle === "standard" ? "map" : "earth"} size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.controlButton} onPress={() => setShowAlternateRoutes(!showAlternateRoutes)}>
            <Ionicons name="git-branch" size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.controlButton}
            onPress={() => navigation.navigate("ARNavigation", { directions })}
          >
            <Ionicons name="glasses" size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.controlButton}>
            <Ionicons name="options" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Speed Warning */}
      {showSpeedWarning && (
        <View style={styles.speedWarning}>
          <Ionicons name="speedometer" size={24} color="#fff" />
          <Text style={styles.speedWarningText}>Slow Down! Speed Limit: {speedLimit} mph</Text>
        </View>
      )}

      {/* Arrival Card */}
      {!isNavigating && (
        <View style={styles.arrivalCard}>
          <View style={styles.arrivalHeader}>
            <Ionicons name="checkmark-circle" size={36} color="#4CAF50" />
            <Text style={styles.arrivalTitle}>You have arrived!</Text>
          </View>
          <Text style={styles.arrivalSubtitle}>Your destination is on the right</Text>
          <View style={styles.arrivalActions}>
            <TouchableOpacity style={styles.arrivalButton} onPress={() => navigation.goBack()}>
              <Text style={styles.arrivalButtonText}>Done</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.arrivalButton, styles.arrivalButtonSecondary]}
              onPress={() => navigation.navigate("ARNavigation")}
            >
              <Text style={styles.arrivalButtonTextSecondary}>AR View</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  topBar: {
    position: "absolute",
    top: Platform.OS === "ios" ? 50 : 30,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    borderRadius: 8,
    margin: 16,
  },
  backButton: {
    padding: 8,
  },
  destinationInfo: {
    flex: 1,
    marginHorizontal: 12,
  },
  destinationName: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  eta: {
    color: "#ccc",
    fontSize: 14,
  },
  endButton: {
    backgroundColor: "#F44336",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  endButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  nextTurnCard: {
    position: "absolute",
    top: Platform.OS === "ios" ? 140 : 120,
    left: 16,
    right: 16,
    backgroundColor: "rgba(33, 150, 243, 0.9)",
    borderRadius: 12,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  maneuverIconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 16,
  },
  nextTurnInfo: {
    flex: 1,
  },
  nextTurnDistance: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  nextTurnInstruction: {
    color: "#fff",
    fontSize: 16,
  },
  bottomPanel: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "rgba(0, 0, 0, 0.8)",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    padding: 16,
  },
  tripInfo: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  infoItem: {
    alignItems: "center",
  },
  infoValue: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "bold",
  },
  infoLabel: {
    color: "#ccc",
    fontSize: 14,
  },
  controlsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingBottom: Platform.OS === "ios" ? 20 : 0,
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    justifyContent: "center",
    alignItems: "center",
  },
  userMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(66, 133, 244, 0.2)",
    borderWidth: 2,
    borderColor: "#4285F4",
    justifyContent: "center",
    alignItems: "center",
  },
  destinationMarker: {
    alignItems: "center",
  },
  speedWarning: {
    position: "absolute",
    top: Platform.OS === "ios" ? 220 : 200,
    left: 16,
    right: 16,
    backgroundColor: "rgba(244, 67, 54, 0.9)",
    borderRadius: 12,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  speedWarningText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
    marginLeft: 8,
  },
  arrivalCard: {
    position: "absolute",
    bottom: 100,
    left: 16,
    right: 16,
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 24,
    alignItems: "center",
  },
  arrivalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  arrivalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#212121",
    marginLeft: 12,
  },
  arrivalSubtitle: {
    fontSize: 16,
    color: "#757575",
    marginBottom: 24,
  },
  arrivalActions: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
  },
  arrivalButton: {
    flex: 1,
    backgroundColor: "#4CAF50",
    paddingVertical: 12,
    borderRadius: 24,
    alignItems: "center",
    marginHorizontal: 8,
  },
  arrivalButtonSecondary: {
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#4CAF50",
  },
  arrivalButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  arrivalButtonTextSecondary: {
    color: "#4CAF50",
    fontSize: 16,
    fontWeight: "bold",
  },
})

export default RealTimeNavigationScreen
