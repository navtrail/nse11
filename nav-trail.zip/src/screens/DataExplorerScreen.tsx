"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  TextInput,
  ActivityIndicator,
  ScrollView,
  Image,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import {
  getBookingDestinations,
  getStravlData,
  getOPTDLocations,
  getTravelRecommendations,
  getIndiaTourismData,
  searchAcrossDatasets,
  type BookingDestination,
  type OPTDLocation,
  type TravelRecommendation,
  type StravlDataPoint,
  type IndiaTourismData,
} from "../services/data-integration"

const DataExplorerScreen = ({ navigation }) => {
  const [activeTab, setActiveTab] = useState("booking")
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [bookingDestinations, setBookingDestinations] = useState<BookingDestination[]>([])
  const [stravlData, setStravlData] = useState<StravlDataPoint[]>([])
  const [optdLocations, setOptdLocations] = useState<OPTDLocation[]>([])
  const [travelRecommendations, setTravelRecommendations] = useState<TravelRecommendation[]>([])
  const [indiaTourismData, setIndiaTourismData] = useState<IndiaTourismData[]>([])
  const [searchResults, setSearchResults] = useState<any>({})

  useEffect(() => {
    loadInitialData()
  }, [])

  const loadInitialData = async () => {
    setIsLoading(true)
    try {
      switch (activeTab) {
        case "booking":
          const destinations = await getBookingDestinations()
          setBookingDestinations(destinations)
          break
        case "stravl":
          const stravlRoutes = await getStravlData("user-1") // Using a mock user ID
          setStravlData(stravlRoutes)
          break
        case "optd":
          const locations = await getOPTDLocations()
          setOptdLocations(locations)
          break
        case "india":
          const tourismData = await getIndiaTourismData()
          setIndiaTourismData(tourismData)
          break
        case "recommendations":
          const recommendations = await getTravelRecommendations()
          setTravelRecommendations(recommendations)
          break
        default:
          break
      }
    } catch (error) {
      console.error("Error loading initial data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      loadInitialData()
      return
    }

    setIsLoading(true)
    try {
      if (activeTab === "search") {
        const results = await searchAcrossDatasets(searchQuery)
        setSearchResults(results)
      } else {
        switch (activeTab) {
          case "booking":
            const destinations = await getBookingDestinations(searchQuery)
            setBookingDestinations(destinations)
            break
          case "stravl":
            // For Stravl, we'll just filter the existing data client-side
            const stravlRoutes = await getStravlData("user-1")
            const filteredStravl = stravlRoutes.filter(
              (route) =>
                route.activityType.toLowerCase().includes(searchQuery.toLowerCase()) ||
                (route.difficulty && route.difficulty.toLowerCase().includes(searchQuery.toLowerCase())),
            )
            setStravlData(filteredStravl)
            break
          case "optd":
            const locations = await getOPTDLocations(searchQuery)
            setOptdLocations(locations)
            break
          case "india":
            // For India Tourism, we'll just filter by state
            const tourismData = await getIndiaTourismData(undefined, undefined, searchQuery)
            setIndiaTourismData(tourismData)
            break
          case "recommendations":
            const recommendations = await getTravelRecommendations([searchQuery])
            setTravelRecommendations(recommendations)
            break
          default:
            break
        }
      }
    } catch (error) {
      console.error("Error searching data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const renderBookingDestination = ({ item }: { item: BookingDestination }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate("ItineraryBuilder", { destination: item.name })}
    >
      <Image source={{ uri: item.image || "https://via.placeholder.com/150" }} style={styles.cardImage} />
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{item.name}</Text>
        <Text style={styles.cardSubtitle}>{item.country}</Text>
        <View style={styles.cardDetails}>
          <View style={styles.cardDetail}>
            <Ionicons name="star" size={16} color="#FFC107" />
            <Text style={styles.cardDetailText}>{item.popularity.toFixed(1)}</Text>
          </View>
          <View style={styles.cardDetail}>
            <Ionicons name="bed" size={16} color="#757575" />
            <Text style={styles.cardDetailText}>{item.accommodations}</Text>
          </View>
          <View style={styles.cardDetail}>
            <Ionicons name="cash" size={16} color="#4CAF50" />
            <Text style={styles.cardDetailText}>${item.averagePrice}</Text>
          </View>
        </View>
        <View style={styles.tagsContainer}>
          {item.tags.slice(0, 3).map((tag, index) => (
            <View key={index} style={styles.tag}>
              <Text style={styles.tagText}>{tag}</Text>
            </View>
          ))}
        </View>
      </View>
    </TouchableOpacity>
  )

  const renderStravlRoute = ({ item }: { item: StravlDataPoint }) => (
    <TouchableOpacity style={styles.card} onPress={() => navigation.navigate("Map", { routePoints: item.routePoints })}>
      {item.photos && item.photos.length > 0 ? (
        <Image source={{ uri: item.photos[0] }} style={styles.cardImage} />
      ) : (
        <View style={[styles.cardImage, styles.noImage]}>
          <Ionicons name="trail-sign" size={40} color="#E0E0E0" />
        </View>
      )}
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{item.activityType.charAt(0).toUpperCase() + item.activityType.slice(1)}</Text>
        <Text style={styles.cardSubtitle}>
          {new Date(item.timestamp).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" })}
        </Text>
        <View style={styles.cardDetails}>
          <View style={styles.cardDetail}>
            <Ionicons name="speedometer" size={16} color="#757575" />
            <Text style={styles.cardDetailText}>{item.distance.toFixed(1)} km</Text>
          </View>
          <View style={styles.cardDetail}>
            <Ionicons name="time" size={16} color="#757575" />
            <Text style={styles.cardDetailText}>{Math.floor(item.duration / 60)} min</Text>
          </View>
          {item.difficulty && (
            <View style={styles.cardDetail}>
              <Ionicons name="trending-up" size={16} color="#757575" />
              <Text style={styles.cardDetailText}>{item.difficulty}</Text>
            </View>
          )}
        </View>
        {item.weather && (
          <View style={styles.weatherContainer}>
            <Text style={styles.weatherText}>
              {item.weather.temperature}°C, {item.weather.conditions}
            </Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  )

  const renderOPTDLocation = ({ item }: { item: OPTDLocation }) => (
    <TouchableOpacity style={styles.card} onPress={() => navigation.navigate("Map", { location: item.coordinates })}>
      <View style={[styles.cardImage, styles.noImage]}>
        <Ionicons
          name={item.type === "airport" ? "airplane" : item.type === "railway_station" ? "train" : "bus"}
          size={40}
          color="#E0E0E0"
        />
      </View>
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{item.name}</Text>
        <Text style={styles.cardSubtitle}>
          {item.city}, {item.countryName}
        </Text>
        <View style={styles.cardDetails}>
          <View style={styles.cardDetail}>
            <Ionicons name="code" size={16} color="#757575" />
            <Text style={styles.cardDetailText}>{item.iataCode}</Text>
          </View>
          <View style={styles.cardDetail}>
            <Ionicons name="star" size={16} color="#FFC107" />
            <Text style={styles.cardDetailText}>{item.popularity.toFixed(1)}</Text>
          </View>
          <View style={styles.cardDetail}>
            <Ionicons name="time" size={16} color="#757575" />
            <Text style={styles.cardDetailText}>{item.timezone}</Text>
          </View>
        </View>
        <View style={styles.tagsContainer}>
          {item.facilities.slice(0, 3).map((facility, index) => (
            <View key={index} style={styles.tag}>
              <Text style={styles.tagText}>{facility.replace("_", " ")}</Text>
            </View>
          ))}
        </View>
      </View>
    </TouchableOpacity>
  )

  const renderIndiaTourismData = ({ item }: { item: IndiaTourismData }) => (
    <TouchableOpacity style={styles.card}>
      <View style={[styles.cardImage, styles.noImage]}>
        <Ionicons name="analytics" size={40} color="#E0E0E0" />
      </View>
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{item.state}</Text>
        <Text style={styles.cardSubtitle}>
          {item.month} {item.year}
        </Text>
        <View style={styles.cardDetails}>
          <View style={styles.cardDetail}>
            <Ionicons name="people" size={16} color="#757575" />
            <Text style={styles.cardDetailText}>{(item.totalVisitors / 1000000).toFixed(1)}M visitors</Text>
          </View>
          <View style={styles.cardDetail}>
            <Ionicons name="globe" size={16} color="#757575" />
            <Text style={styles.cardDetailText}>{(item.foreignVisitors / 1000).toFixed(1)}K foreign</Text>
          </View>
          <View style={styles.cardDetail}>
            <Ionicons name="cash" size={16} color="#4CAF50" />
            <Text style={styles.cardDetailText}>${(item.revenue / 1000000).toFixed(1)}M</Text>
          </View>
        </View>
        <View style={styles.tagsContainer}>
          {item.topAttractions.slice(0, 3).map((attraction, index) => (
            <View key={index} style={styles.tag}>
              <Text style={styles.tagText}>{attraction}</Text>
            </View>
          ))}
        </View>
      </View>
    </TouchableOpacity>
  )

  const renderTravelRecommendation = ({ item }: { item: TravelRecommendation }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate("ItineraryBuilder", { destination: item.destination })}
    >
      <Image source={{ uri: item.image || "https://via.placeholder.com/150" }} style={styles.cardImage} />
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{item.destination}</Text>
        <Text style={styles.cardSubtitle}>{item.country}</Text>
        <View style={styles.cardDetails}>
          <View style={styles.cardDetail}>
            <Ionicons name="star" size={16} color="#FFC107" />
            <Text style={styles.cardDetailText}>{item.rating.toFixed(1)}</Text>
          </View>
          <View style={styles.cardDetail}>
            <Ionicons name="cash" size={16} color="#757575" />
            <Text style={styles.cardDetailText}>{"$".repeat(item.priceLevel)}</Text>
          </View>
          <View style={styles.cardDetail}>
            <Ionicons name="calendar" size={16} color="#757575" />
            <Text style={styles.cardDetailText}>{item.bestTimeToVisit.join(", ")}</Text>
          </View>
        </View>
        <View style={styles.tagsContainer}>
          {item.tags.slice(0, 3).map((tag, index) => (
            <View key={index} style={styles.tag}>
              <Text style={styles.tagText}>{tag}</Text>
            </View>
          ))}
        </View>
      </View>
    </TouchableOpacity>
  )

  const renderSearchResults = () => (
    <ScrollView style={styles.searchResultsContainer}>
      {searchResults.bookingDestinations && searchResults.bookingDestinations.length > 0 && (
        <View style={styles.searchResultSection}>
          <Text style={styles.searchResultSectionTitle}>Destinations</Text>
          <FlatList
            data={searchResults.bookingDestinations}
            renderItem={renderBookingDestination}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalListContent}
          />
        </View>
      )}

      {searchResults.optdLocations && searchResults.optdLocations.length > 0 && (
        <View style={styles.searchResultSection}>
          <Text style={styles.searchResultSectionTitle}>Airports & Stations</Text>
          <FlatList
            data={searchResults.optdLocations}
            renderItem={renderOPTDLocation}
            keyExtractor={(item) => item.iataCode}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalListContent}
          />
        </View>
      )}

      {searchResults.travelRecommendations && searchResults.travelRecommendations.length > 0 && (
        <View style={styles.searchResultSection}>
          <Text style={styles.searchResultSectionTitle}>Recommendations</Text>
          <FlatList
            data={searchResults.travelRecommendations}
            renderItem={renderTravelRecommendation}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalListContent}
          />
        </View>
      )}

      {(!searchResults.bookingDestinations || searchResults.bookingDestinations.length === 0) &&
        (!searchResults.optdLocations || searchResults.optdLocations.length === 0) &&
        (!searchResults.travelRecommendations || searchResults.travelRecommendations.length === 0) && (
          <View style={styles.noResultsContainer}>
            <Ionicons name="search" size={64} color="#E0E0E0" />
            <Text style={styles.noResultsText}>No results found</Text>
            <Text style={styles.noResultsSubtext}>Try a different search term</Text>
          </View>
        )}
    </ScrollView>
  )

  const renderContent = () => {
    if (isLoading) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4CAF50" />
          <Text style={styles.loadingText}>Loading data...</Text>
        </View>
      )
    }

    if (activeTab === "search" && searchQuery) {
      return renderSearchResults()
    }

    switch (activeTab) {
      case "booking":
        return (
          <FlatList
            data={bookingDestinations}
            renderItem={renderBookingDestination}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.noResultsContainer}>
                <Ionicons name="search" size={64} color="#E0E0E0" />
                <Text style={styles.noResultsText}>No destinations found</Text>
                <Text style={styles.noResultsSubtext}>Try a different search term</Text>
              </View>
            }
          />
        )
      case "stravl":
        return (
          <FlatList
            data={stravlData}
            renderItem={renderStravlRoute}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.noResultsContainer}>
                <Ionicons name="search" size={64} color="#E0E0E0" />
                <Text style={styles.noResultsText}>No routes found</Text>
                <Text style={styles.noResultsSubtext}>Try a different search term</Text>
              </View>
            }
          />
        )
      case "optd":
        return (
          <FlatList
            data={optdLocations}
            renderItem={renderOPTDLocation}
            keyExtractor={(item) => item.iataCode}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.noResultsContainer}>
                <Ionicons name="search" size={64} color="#E0E0E0" />
                <Text style={styles.noResultsText}>No locations found</Text>
                <Text style={styles.noResultsSubtext}>Try a different search term</Text>
              </View>
            }
          />
        )
      case "india":
        return (
          <FlatList
            data={indiaTourismData}
            renderItem={renderIndiaTourismData}
            keyExtractor={(item, index) => `${item.state}-${item.month}-${item.year}-${index}`}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.noResultsContainer}>
                <Ionicons name="search" size={64} color="#E0E0E0" />
                <Text style={styles.noResultsText}>No tourism data found</Text>
                <Text style={styles.noResultsSubtext}>Try a different search term</Text>
              </View>
            }
          />
        )
      case "recommendations":
        return (
          <FlatList
            data={travelRecommendations}
            renderItem={renderTravelRecommendation}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.noResultsContainer}>
                <Ionicons name="search" size={64} color="#E0E0E0" />
                <Text style={styles.noResultsText}>No recommendations found</Text>
                <Text style={styles.noResultsSubtext}>Try a different search term</Text>
              </View>
            }
          />
        )
      default:
        return null
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Travel Data Explorer</Text>
        <View style={styles.placeholder} />
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Ionicons name="search" size={20} color="#757575" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search destinations, routes, airports..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
          />
          {searchQuery ? (
            <TouchableOpacity onPress={() => setSearchQuery("")}>
              <Ionicons name="close-circle" size={20} color="#757575" />
            </TouchableOpacity>
          ) : null}
        </View>
        <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
          <Text style={styles.searchButtonText}>Search</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.tabsContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabs}>
          <TouchableOpacity
            style={[styles.tab, activeTab === "search" && styles.activeTab]}
            onPress={() => {
              setActiveTab("search")
              if (searchQuery) handleSearch()
            }}
          >
            <Ionicons
              name="search"
              size={20}
              color={activeTab === "search" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "search" && styles.activeTabText]}>All</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === "booking" && styles.activeTab]}
            onPress={() => {
              setActiveTab("booking")
              loadInitialData()
            }}
          >
            <Ionicons
              name="bed"
              size={20}
              color={activeTab === "booking" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "booking" && styles.activeTabText]}>Booking.com</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === "stravl" && styles.activeTab]}
            onPress={() => {
              setActiveTab("stravl")
              loadInitialData()
            }}
          >
            <Ionicons
              name="trail-sign"
              size={20}
              color={activeTab === "stravl" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "stravl" && styles.activeTabText]}>Stravl</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === "optd" && styles.activeTab]}
            onPress={() => {
              setActiveTab("optd")
              loadInitialData()
            }}
          >
            <Ionicons
              name="airplane"
              size={20}
              color={activeTab === "optd" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "optd" && styles.activeTabText]}>OPTD</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === "india" && styles.activeTab]}
            onPress={() => {
              setActiveTab("india")
              loadInitialData()
            }}
          >
            <Ionicons
              name="analytics"
              size={20}
              color={activeTab === "india" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "india" && styles.activeTabText]}>India Tourism</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === "recommendations" && styles.activeTab]}
            onPress={() => {
              setActiveTab("recommendations")
              loadInitialData()
            }}
          >
            <Ionicons
              name="thumbs-up"
              size={20}
              color={activeTab === "recommendations" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "recommendations" && styles.activeTabText]}>
              Recommendations
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      <View style={styles.content}>{renderContent()}</View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  placeholder: {
    width: 40,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 40,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: "#212121",
  },
  searchButton: {
    marginLeft: 12,
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  searchButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  tabsContainer: {
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  tabs: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  tab: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: "#f5f5f5",
    marginRight: 8,
  },
  activeTab: {
    backgroundColor: "#e8f5e9",
  },
  tabIcon: {
    marginRight: 4,
  },
  tabText: {
    fontSize: 14,
    color: "#757575",
  },
  activeTabText: {
    color: "#4CAF50",
    fontWeight: "bold",
  },
  content: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: "#757575",
  },
  listContent: {
    padding: 16,
  },
  card: {
    flexDirection: "row",
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    marginBottom: 16,
    overflow: "hidden",
  },
  cardImage: {
    width: 120,
    height: 120,
  },
  noImage: {
    backgroundColor: "#f0f0f0",
    justifyContent: "center",
    alignItems: "center",
  },
  cardContent: {
    flex: 1,
    padding: 12,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 8,
  },
  cardDetails: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 8,
  },
  cardDetail: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 12,
    marginBottom: 4,
  },
  cardDetailText: {
    fontSize: 14,
    color: "#757575",
    marginLeft: 4,
  },
  tagsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  tag: {
    backgroundColor: "#e8f5e9",
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 8,
    marginBottom: 4,
  },
  tagText: {
    fontSize: 12,
    color: "#4CAF50",
  },
  weatherContainer: {
    marginTop: 4,
  },
  weatherText: {
    fontSize: 14,
    color: "#757575",
  },
  noResultsContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  noResultsText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#757575",
    marginTop: 16,
  },
  noResultsSubtext: {
    fontSize: 14,
    color: "#9E9E9E",
    marginTop: 8,
  },
  searchResultsContainer: {
    flex: 1,
  },
  searchResultSection: {
    marginBottom: 24,
  },
  searchResultSectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
    marginHorizontal: 16,
    marginBottom: 12,
  },
  horizontalListContent: {
    paddingHorizontal: 16,
  },
})

export default DataExplorerScreen
