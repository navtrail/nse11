"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  ActivityIndicator,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import {
  getStravlData,
  getBookingDestinations,
  getIndiaTourismData,
  getTravelRecommendations,
} from "../services/data-integration"

// Import a charting library for React Native
// For a real app, you would use something like react-native-chart-kit or victory-native
// Here we'll create a simple mock implementation
const { width } = Dimensions.get("window")

const BarChart = ({ data, labels, color = "#4CAF50", height = 200 }) => {
  const maxValue = Math.max(...data)

  return (
    <View style={[styles.chartContainer, { height }]}>
      <View style={styles.chartBars}>
        {data.map((value, index) => (
          <View key={index} style={styles.barContainer}>
            <View style={[styles.bar, { height: (value / maxValue) * (height - 40), backgroundColor: color }]} />
            <Text style={styles.barLabel}>{labels[index]}</Text>
          </View>
        ))}
      </View>
      <View style={styles.chartYAxis}>
        <Text style={styles.yAxisLabel}>{maxValue}</Text>
        <Text style={styles.yAxisLabel}>{Math.round(maxValue / 2)}</Text>
        <Text style={styles.yAxisLabel}>0</Text>
      </View>
    </View>
  )
}

const LineChart = ({ data, labels, color = "#2196F3", height = 200 }) => {
  const maxValue = Math.max(...data)
  const points = data.map((value, index) => ({
    x: (index / (data.length - 1)) * (width - 80),
    y: height - 40 - (value / maxValue) * (height - 40),
  }))

  // Create SVG path
  let path = `M ${points[0].x} ${points[0].y}`
  for (let i = 1; i < points.length; i++) {
    path += ` L ${points[i].x} ${points[i].y}`
  }

  return (
    <View style={[styles.chartContainer, { height }]}>
      <View style={styles.chartLines}>
        <View style={styles.chartLine} />
        <View style={[styles.chartLine, { top: (height - 40) / 2 }]} />
        <View style={[styles.chartLine, { top: height - 40 }]} />
      </View>
      <View style={styles.chartYAxis}>
        <Text style={styles.yAxisLabel}>{maxValue}</Text>
        <Text style={styles.yAxisLabel}>{Math.round(maxValue / 2)}</Text>
        <Text style={styles.yAxisLabel}>0</Text>
      </View>
      <View style={styles.chartContent}>
        {points.map((point, index) => (
          <View
            key={index}
            style={[
              styles.dataPoint,
              {
                left: point.x,
                top: point.y,
                backgroundColor: color,
              },
            ]}
          />
        ))}
        <View
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            width: width - 80,
            height: height - 40,
            borderColor: color,
            borderWidth: 0,
          }}
        >
          <View
            style={{
              position: "absolute",
              left: 0,
              top: 0,
              width: width - 80,
              height: height - 40,
            }}
          >
            {points.map((point, index) => {
              if (index < points.length - 1) {
                return (
                  <View
                    key={index}
                    style={{
                      position: "absolute",
                      left: point.x,
                      top: point.y,
                      width: points[index + 1].x - point.x,
                      height: 2,
                      backgroundColor: color,
                      transform: [
                        {
                          rotate: `${Math.atan2(points[index + 1].y - point.y, points[index + 1].x - point.x)}rad`,
                        },
                      ],
                      transformOrigin: "left",
                    }}
                  />
                )
              }
              return null
            })}
          </View>
        </View>
      </View>
      <View style={styles.chartXAxis}>
        {labels.map((label, index) => (
          <Text
            key={index}
            style={[
              styles.xAxisLabel,
              {
                left: (index / (labels.length - 1)) * (width - 80),
              },
            ]}
          >
            {label}
          </Text>
        ))}
      </View>
    </View>
  )
}

const PieChart = ({ data, labels, colors, height = 200 }) => {
  const total = data.reduce((sum, value) => sum + value, 0)
  let startAngle = 0

  return (
    <View style={[styles.pieChartContainer, { height }]}>
      <View style={styles.pieChart}>
        {data.map((value, index) => {
          const angle = (value / total) * 360
          const endAngle = startAngle + angle
          const result = (
            <View
              key={index}
              style={[
                styles.pieSlice,
                {
                  backgroundColor: colors[index % colors.length],
                  transform: [
                    { rotate: `${startAngle}deg` },
                    { translateX: height / 4 },
                    { rotate: `${angle / 2}deg` },
                    { translateX: -height / 4 },
                  ],
                  width: angle > 180 ? "100%" : "50%",
                  height: "100%",
                  borderTopRightRadius: angle > 180 ? 0 : height / 2,
                  borderBottomRightRadius: angle > 180 ? 0 : height / 2,
                  zIndex: angle > 180 ? 1 : 0,
                },
              ]}
            />
          )
          startAngle += angle
          return result
        })}
      </View>
      <View style={styles.pieLegend}>
        {data.map((value, index) => (
          <View key={index} style={styles.legendItem}>
            <View style={[styles.legendColor, { backgroundColor: colors[index % colors.length] }]} />
            <Text style={styles.legendLabel}>{labels[index]}</Text>
            <Text style={styles.legendValue}>{Math.round((value / total) * 100)}%</Text>
          </View>
        ))}
      </View>
    </View>
  )
}

const DataVisualizationScreen = ({ navigation }) => {
  const [activeTab, setActiveTab] = useState("stravl")
  const [isLoading, setIsLoading] = useState(false)
  const [stravlData, setStravlData] = useState(null)
  const [bookingData, setBookingData] = useState(null)
  const [indiaTourismData, setIndiaTourismData] = useState(null)
  const [recommendationsData, setRecommendationsData] = useState(null)

  useEffect(() => {
    loadData()
  }, [activeTab])

  const loadData = async () => {
    setIsLoading(true)
    try {
      switch (activeTab) {
        case "stravl":
          if (!stravlData) {
            const data = await getStravlData("user-1")
            // Process data for visualization
            const processedData = processStravlData(data)
            setStravlData(processedData)
          }
          break
        case "booking":
          if (!bookingData) {
            const data = await getBookingDestinations()
            // Process data for visualization
            const processedData = processBookingData(data)
            setBookingData(processedData)
          }
          break
        case "india":
          if (!indiaTourismData) {
            const data = await getIndiaTourismData()
            // Process data for visualization
            const processedData = processIndiaTourismData(data)
            setIndiaTourismData(processedData)
          }
          break
        case "recommendations":
          if (!recommendationsData) {
            const data = await getTravelRecommendations()
            // Process data for visualization
            const processedData = processRecommendationsData(data)
            setRecommendationsData(processedData)
          }
          break
        default:
          break
      }
    } catch (error) {
      console.error("Error loading data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const processStravlData = (data) => {
    // Group by activity type
    const activityCounts = {}
    data.forEach((item) => {
      activityCounts[item.activityType] = (activityCounts[item.activityType] || 0) + 1
    })

    // Calculate average distance by activity type
    const activityDistances = {}
    data.forEach((item) => {
      if (!activityDistances[item.activityType]) {
        activityDistances[item.activityType] = {
          total: 0,
          count: 0,
        }
      }
      activityDistances[item.activityType].total += item.distance
      activityDistances[item.activityType].count += 1
    })

    const avgDistances = {}
    Object.keys(activityDistances).forEach((key) => {
      avgDistances[key] = activityDistances[key].total / activityDistances[key].count
    })

    // Group by difficulty
    const difficultyCounts = {}
    data.forEach((item) => {
      if (item.difficulty) {
        difficultyCounts[item.difficulty] = (difficultyCounts[item.difficulty] || 0) + 1
      }
    })

    return {
      activityCounts,
      avgDistances,
      difficultyCounts,
    }
  }

  const processBookingData = (data) => {
    // Group by country
    const countryCounts = {}
    data.forEach((item) => {
      countryCounts[item.country] = (countryCounts[item.country] || 0) + 1
    })

    // Calculate average price by country
    const countryPrices = {}
    data.forEach((item) => {
      if (!countryPrices[item.country]) {
        countryPrices[item.country] = {
          total: 0,
          count: 0,
        }
      }
      countryPrices[item.country].total += item.averagePrice
      countryPrices[item.country].count += 1
    })

    const avgPrices = {}
    Object.keys(countryPrices).forEach((key) => {
      avgPrices[key] = countryPrices[key].total / countryPrices[key].count
    })

    // Group by popularity
    const popularityRanges = {
      "9-10": 0,
      "8-9": 0,
      "7-8": 0,
      "6-7": 0,
      "<6": 0,
    }

    data.forEach((item) => {
      if (item.popularity >= 9) {
        popularityRanges["9-10"] += 1
      } else if (item.popularity >= 8) {
        popularityRanges["8-9"] += 1
      } else if (item.popularity >= 7) {
        popularityRanges["7-8"] += 1
      } else if (item.popularity >= 6) {
        popularityRanges["6-7"] += 1
      } else {
        popularityRanges["<6"] += 1
      }
    })

    return {
      countryCounts,
      avgPrices,
      popularityRanges,
    }
  }

  const processIndiaTourismData = (data) => {
    // Group by state
    const stateCounts = {}
    data.forEach((item) => {
      stateCounts[item.state] = (stateCounts[item.state] || 0) + item.totalVisitors
    })

    // Group by month
    const monthlyVisitors = {
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0,
    }

    data.forEach((item) => {
      if (monthlyVisitors[item.month] !== undefined) {
        monthlyVisitors[item.month] += item.totalVisitors
      }
    })

    // Calculate domestic vs foreign ratio
    const visitorTypes = {
      Domestic: 0,
      Foreign: 0,
    }

    data.forEach((item) => {
      visitorTypes.Domestic += item.domesticVisitors
      visitorTypes.Foreign += item.foreignVisitors
    })

    return {
      stateCounts,
      monthlyVisitors,
      visitorTypes,
    }
  }

  const processRecommendationsData = (data) => {
    // Group by country
    const countryCounts = {}
    data.forEach((item) => {
      countryCounts[item.country] = (countryCounts[item.country] || 0) + 1
    })

    // Group by recommendation type
    const typeCounts = {}
    data.forEach((item) => {
      typeCounts[item.recommendationType] = (typeCounts[item.recommendationType] || 0) + 1
    })

    // Group by price level
    const priceLevelCounts = {
      1: 0,
      2: 0,
      3: 0,
      4: 0,
      5: 0,
    }

    data.forEach((item) => {
      if (priceLevelCounts[item.priceLevel] !== undefined) {
        priceLevelCounts[item.priceLevel] += 1
      }
    })

    return {
      countryCounts,
      typeCounts,
      priceLevelCounts,
    }
  }

  const renderStravlCharts = () => {
    if (!stravlData) return null

    const activityLabels = Object.keys(stravlData.activityCounts)
    const activityValues = activityLabels.map((key) => stravlData.activityCounts[key])

    const distanceLabels = Object.keys(stravlData.avgDistances)
    const distanceValues = distanceLabels.map((key) => stravlData.avgDistances[key])

    const difficultyLabels = Object.keys(stravlData.difficultyCounts)
    const difficultyValues = difficultyLabels.map((key) => stravlData.difficultyCounts[key])

    return (
      <ScrollView style={styles.chartsContainer}>
        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Activities by Type</Text>
          <BarChart data={activityValues} labels={activityLabels} color="#4CAF50" />
        </View>

        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Average Distance by Activity (km)</Text>
          <BarChart data={distanceValues} labels={distanceLabels} color="#2196F3" />
        </View>

        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Routes by Difficulty</Text>
          <PieChart
            data={difficultyValues}
            labels={difficultyLabels}
            colors={["#4CAF50", "#FFC107", "#F44336", "#9C27B0", "#2196F3"]}
          />
        </View>
      </ScrollView>
    )
  }

  const renderBookingCharts = () => {
    if (!bookingData) return null

    const countryLabels = Object.keys(bookingData.countryCounts).slice(0, 5) // Top 5 countries
    const countryValues = countryLabels.map((key) => bookingData.countryCounts[key])

    const priceLabels = Object.keys(bookingData.avgPrices).slice(0, 5) // Top 5 countries
    const priceValues = priceLabels.map((key) => bookingData.avgPrices[key])

    const popularityLabels = Object.keys(bookingData.popularityRanges)
    const popularityValues = popularityLabels.map((key) => bookingData.popularityRanges[key])

    return (
      <ScrollView style={styles.chartsContainer}>
        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Top Destinations by Country</Text>
          <BarChart data={countryValues} labels={countryLabels} color="#4CAF50" />
        </View>

        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Average Price by Country ($)</Text>
          <BarChart data={priceValues} labels={priceLabels} color="#F44336" />
        </View>

        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Destinations by Popularity Rating</Text>
          <PieChart
            data={popularityValues}
            labels={popularityLabels}
            colors={["#4CAF50", "#8BC34A", "#FFC107", "#FF9800", "#F44336"]}
          />
        </View>
      </ScrollView>
    )
  }

  const renderIndiaTourismCharts = () => {
    if (!indiaTourismData) return null

    const stateLabels = Object.keys(indiaTourismData.stateCounts).slice(0, 5) // Top 5 states
    const stateValues = stateLabels.map((key) => indiaTourismData.stateCounts[key] / 1000000) // Convert to millions

    const monthLabels = Object.keys(indiaTourismData.monthlyVisitors)
    const monthValues = monthLabels.map((key) => indiaTourismData.monthlyVisitors[key] / 1000000) // Convert to millions

    const visitorTypeLabels = Object.keys(indiaTourismData.visitorTypes)
    const visitorTypeValues = visitorTypeLabels.map((key) => indiaTourismData.visitorTypes[key])

    return (
      <ScrollView style={styles.chartsContainer}>
        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Top States by Visitors (Millions)</Text>
          <BarChart data={stateValues} labels={stateLabels} color="#4CAF50" />
        </View>

        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Monthly Visitors (Millions)</Text>
          <LineChart data={monthValues} labels={monthLabels.map((m) => m.substring(0, 3))} color="#2196F3" />
        </View>

        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Domestic vs Foreign Visitors</Text>
          <PieChart data={visitorTypeValues} labels={visitorTypeLabels} colors={["#4CAF50", "#2196F3"]} />
        </View>
      </ScrollView>
    )
  }

  const renderRecommendationsCharts = () => {
    if (!recommendationsData) return null

    const countryLabels = Object.keys(recommendationsData.countryCounts).slice(0, 5) // Top 5 countries
    const countryValues = countryLabels.map((key) => recommendationsData.countryCounts[key])

    const typeLabels = Object.keys(recommendationsData.typeCounts)
    const typeValues = typeLabels.map((key) => recommendationsData.typeCounts[key])

    const priceLevelLabels = Object.keys(recommendationsData.priceLevelCounts)
    const priceLevelValues = priceLevelLabels.map((key) => recommendationsData.priceLevelCounts[key])

    return (
      <ScrollView style={styles.chartsContainer}>
        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Top Recommended Countries</Text>
          <BarChart data={countryValues} labels={countryLabels} color="#4CAF50" />
        </View>

        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Recommendations by Type</Text>
          <PieChart data={typeValues} labels={typeLabels} colors={["#4CAF50", "#FFC107", "#F44336", "#9C27B0"]} />
        </View>

        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Recommendations by Price Level</Text>
          <BarChart
            data={priceLevelValues}
            labels={priceLevelLabels.map((level) => `${"$".repeat(Number.parseInt(level))}`)}
            color="#F44336"
          />
        </View>
      </ScrollView>
    )
  }

  const renderContent = () => {
    if (isLoading) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4CAF50" />
          <Text style={styles.loadingText}>Loading data...</Text>
        </View>
      )
    }

    switch (activeTab) {
      case "stravl":
        return renderStravlCharts()
      case "booking":
        return renderBookingCharts()
      case "india":
        return renderIndiaTourismCharts()
      case "recommendations":
        return renderRecommendationsCharts()
      default:
        return null
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Data Insights</Text>
        <View style={styles.placeholder} />
      </View>

      <View style={styles.tabsContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabs}>
          <TouchableOpacity
            style={[styles.tab, activeTab === "stravl" && styles.activeTab]}
            onPress={() => setActiveTab("stravl")}
          >
            <Ionicons
              name="trail-sign"
              size={20}
              color={activeTab === "stravl" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "stravl" && styles.activeTabText]}>Stravl</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === "booking" && styles.activeTab]}
            onPress={() => setActiveTab("booking")}
          >
            <Ionicons
              name="bed"
              size={20}
              color={activeTab === "booking" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "booking" && styles.activeTabText]}>Booking.com</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === "india" && styles.activeTab]}
            onPress={() => setActiveTab("india")}
          >
            <Ionicons
              name="analytics"
              size={20}
              color={activeTab === "india" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "india" && styles.activeTabText]}>India Tourism</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === "recommendations" && styles.activeTab]}
            onPress={() => setActiveTab("recommendations")}
          >
            <Ionicons
              name="thumbs-up"
              size={20}
              color={activeTab === "recommendations" ? "#4CAF50" : "#757575"}
              style={styles.tabIcon}
            />
            <Text style={[styles.tabText, activeTab === "recommendations" && styles.activeTabText]}>
              Recommendations
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      <View style={styles.content}>{renderContent()}</View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  placeholder: {
    width: 40,
  },
  tabsContainer: {
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  tabs: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  tab: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: "#f5f5f5",
    marginRight: 8,
  },
  activeTab: {
    backgroundColor: "#e8f5e9",
  },
  tabIcon: {
    marginRight: 4,
  },
  tabText: {
    fontSize: 14,
    color: "#757575",
  },
  activeTabText: {
    color: "#4CAF50",
    fontWeight: "bold",
  },
  content: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: "#757575",
  },
  chartsContainer: {
    padding: 16,
  },
  chartCard: {
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 16,
  },
  chartContainer: {
    position: "relative",
    marginLeft: 40,
  },
  chartBars: {
    flexDirection: "row",
    alignItems: "flex-end",
    height: "100%",
    paddingBottom: 20,
  },
  barContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "flex-end",
    height: "100%",
  },
  bar: {
    width: 20,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
  },
  barLabel: {
    fontSize: 12,
    color: "#757575",
    marginTop: 4,
    textAlign: "center",
  },
  chartYAxis: {
    position: "absolute",
    left: -40,
    top: 0,
    bottom: 0,
    width: 40,
    justifyContent: "space-between",
    paddingBottom: 20,
  },
  yAxisLabel: {
    fontSize: 12,
    color: "#757575",
    textAlign: "right",
    paddingRight: 8,
  },
  chartLines: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 20,
  },
  chartLine: {
    position: "absolute",
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: "#e0e0e0",
  },
  chartContent: {
    position: "absolute",
    left: 0,
    top: 0,
    right: 0,
    bottom: 20,
  },
  dataPoint: {
    position: "absolute",
    width: 8,
    height: 8,
    borderRadius: 4,
    marginLeft: -4,
    marginTop: -4,
  },
  chartXAxis: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    height: 20,
  },
  xAxisLabel: {
    position: "absolute",
    fontSize: 12,
    color: "#757575",
    textAlign: "center",
    width: 40,
    marginLeft: -20,
  },
  pieChartContainer: {
    alignItems: "center",
  },
  pieChart: {
    width: 150,
    height: 150,
    borderRadius: 75,
    overflow: "hidden",
    position: "relative",
    backgroundColor: "#f0f0f0",
  },
  pieSlice: {
    position: "absolute",
    left: 0,
    top: 0,
    width: "50%",
    height: "100%",
    transformOrigin: "right center",
  },
  pieLegend: {
    marginTop: 16,
    width: "100%",
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  legendColor: {
    width: 16,
    height: 16,
    borderRadius: 8,
    marginRight: 8,
  },
  legendLabel: {
    flex: 1,
    fontSize: 14,
    color: "#212121",
  },
  legendValue: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
  },
})

export default DataVisualizationScreen
