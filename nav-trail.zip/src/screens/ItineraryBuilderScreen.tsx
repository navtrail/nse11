"use client"

import { useState, useEffect, useRef } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  Animated,
  Alert,
  ActivityIndicator,
  Dimensions,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import DraggableFlatList from "react-native-draggable-flatlist"
import MapView, { PROVIDER_GOOGLE, Marker, Polyline } from "react-native-maps"
import { searchTrails } from "../services/map"
import { getHiddenGems } from "../services/ai"

const { width } = Dimensions.get("window")

const ItineraryBuilderScreen = ({ navigation, route }) => {
  const [tripName, setTripName] = useState(route.params?.tripName || "My Trip")
  const [startDate, setStartDate] = useState(route.params?.startDate || new Date())
  const [endDate, setEndDate] = useState(route.params?.endDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000))
  const [days, setDays] = useState([])
  const [activeDay, setActiveDay] = useState(0)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [isSearching, setIsSearching] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const [mapRegion, setMapRegion] = useState({
    latitude: 37.78825,
    longitude: -122.4324,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  })
  const [routeCoordinates, setRouteCoordinates] = useState([])
  const [totalDistance, setTotalDistance] = useState(0)
  const [totalDuration, setTotalDuration] = useState(0)
  const [collaborators, setCollaborators] = useState([])
  const [showCollaborators, setShowCollaborators] = useState(false)
  const [tripProgress, setTripProgress] = useState(0)
  const [userLevel, setUserLevel] = useState("Basic")
  const [expenses, setExpenses] = useState([])
  const [totalExpenses, setTotalExpenses] = useState(0)
  const [showExpenses, setShowExpenses] = useState(false)
  const [notes, setNotes] = useState([])
  const [showNotes, setShowNotes] = useState(false)
  const [currentNote, setCurrentNote] = useState({ id: null, text: "" })
  const [isEditing, setIsEditing] = useState(false)
  const [isOfflineMode, setIsOfflineMode] = useState(false)

  const mapRef = useRef(null)
  const searchInputRef = useRef(null)
  const searchAnimation = useRef(new Animated.Value(0)).current

  useEffect(() => {
    // Initialize days based on start and end dates
    const dayCount = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1
    const initialDays = Array.from({ length: dayCount }, (_, i) => ({
      id: `day-${i}`,
      date: new Date(startDate.getTime() + i * 24 * 60 * 60 * 1000),
      places: [],
    }))
    setDays(initialDays)

    // Calculate initial trip progress
    calculateTripProgress()

    // Simulate loading collaborators
    setCollaborators([
      { id: "1", name: "Alex Johnson", avatar: "https://via.placeholder.com/40", status: "active" },
      { id: "2", name: "Sam Wilson", avatar: "https://via.placeholder.com/40", status: "pending" },
    ])

    // Simulate loading expenses
    const sampleExpenses = [
      { id: "1", category: "Accommodation", amount: 120, currency: "USD", day: 0 },
      { id: "2", category: "Transportation", amount: 45, currency: "USD", day: 0 },
      { id: "3", category: "Food", amount: 65, currency: "USD", day: 1 },
    ]
    setExpenses(sampleExpenses)
    calculateTotalExpenses(sampleExpenses)

    // Simulate loading notes
    setNotes([
      { id: "1", text: "Remember to pack sunscreen!", day: 0 },
      { id: "2", text: "Check if restaurant requires reservation", day: 1 },
    ])
  }, [startDate, endDate])

  useEffect(() => {
    // Update route when active day or places change
    if (days.length > 0 && activeDay < days.length) {
      const activeDayPlaces = days[activeDay].places
      if (activeDayPlaces.length > 1) {
        const coordinates = activeDayPlaces.map((place) => ({
          latitude: place.coordinates.latitude,
          longitude: place.coordinates.longitude,
        }))
        setRouteCoordinates(coordinates)

        // Calculate total distance and duration
        let totalDist = 0
        let totalDur = 0
        for (let i = 0; i < activeDayPlaces.length - 1; i++) {
          const dist = calculateDistance(
            activeDayPlaces[i].coordinates.latitude,
            activeDayPlaces[i].coordinates.longitude,
            activeDayPlaces[i + 1].coordinates.latitude,
            activeDayPlaces[i + 1].coordinates.longitude,
          )
          totalDist += dist
          // Estimate duration: 1km takes about 10 minutes to walk
          totalDur += dist * 10
        }
        setTotalDistance(totalDist)
        setTotalDuration(totalDur)

        // Fit map to show all markers
        if (mapRef.current && coordinates.length > 0) {
          mapRef.current.fitToCoordinates(coordinates, {
            edgePadding: { top: 50, right: 50, bottom: 50, left: 50 },
            animated: true,
          })
        }
      } else if (activeDayPlaces.length === 1) {
        // If only one place, center map on it
        setMapRegion({
          latitude: activeDayPlaces[0].coordinates.latitude,
          longitude: activeDayPlaces[0].coordinates.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        })
        setRouteCoordinates([])
        setTotalDistance(0)
        setTotalDuration(0)
      } else {
        setRouteCoordinates([])
        setTotalDistance(0)
        setTotalDuration(0)
      }
    }
  }, [days, activeDay])

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371 // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1)
    const dLon = deg2rad(lon2 - lon1)
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    const d = R * c // Distance in km
    return d
  }

  const deg2rad = (deg) => {
    return deg * (Math.PI / 180)
  }

  const calculateTripProgress = () => {
    // Calculate progress based on filled days, added places, notes, etc.
    let progress = 0

    // Basic info adds 20%
    if (tripName !== "My Trip") progress += 10
    if (days.length > 0) progress += 10

    // Places add up to 50%
    const totalPlaces = days.reduce((sum, day) => sum + day.places.length, 0)
    const maxExpectedPlaces = days.length * 3 // Expect 3 places per day
    const placesProgress = Math.min(totalPlaces / maxExpectedPlaces, 1) * 50
    progress += placesProgress

    // Notes add up to 15%
    const notesProgress = Math.min(notes.length / days.length, 1) * 15
    progress += notesProgress

    // Expenses add up to 15%
    const expensesProgress = Math.min(expenses.length / (days.length * 2), 1) * 15
    progress += expensesProgress

    setTripProgress(Math.min(Math.round(progress), 100))

    // Set user level based on progress
    if (progress < 30) {
      setUserLevel("Basic")
    } else if (progress < 70) {
      setUserLevel("Proficient")
    } else {
      setUserLevel("All-star")
    }
  }

  const calculateTotalExpenses = (expenseList) => {
    const total = expenseList.reduce((sum, expense) => sum + expense.amount, 0)
    setTotalExpenses(total)
  }

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    setIsSearching(true)
    try {
      // Search for places
      const results = await searchTrails(searchQuery)

      // Also get hidden gems
      const gems = await getHiddenGems("San Francisco", ["nature", "food"])

      // Combine results
      const combinedResults = [...results, ...gems]
      setSearchResults(combinedResults)
    } catch (error) {
      console.error("Error searching:", error)
      Alert.alert("Search Error", "Failed to search for places. Please try again.")
    } finally {
      setIsSearching(false)
    }
  }

  const toggleSearch = () => {
    const toValue = showSearch ? 0 : 1
    setShowSearch(!showSearch)
    Animated.timing(searchAnimation, {
      toValue,
      duration: 300,
      useNativeDriver: false,
    }).start(() => {
      if (!showSearch) {
        searchInputRef.current?.focus()
      }
    })
  }

  const addPlaceToDay = (place) => {
    const updatedDays = [...days]
    const dayIndex = activeDay

    // Add place to the active day
    updatedDays[dayIndex].places.push({
      id: place.id || `place-${Date.now()}`,
      name: place.name,
      location: place.location,
      coordinates: place.coordinates,
      image: place.image,
      type: place.type || "attraction",
      duration: place.duration || 60, // Default 60 minutes
      notes: "",
    })

    setDays(updatedDays)
    setShowSearch(false)
    searchAnimation.setValue(0)
    setSearchQuery("")
    setSearchResults([])

    // Update trip progress
    calculateTripProgress()
  }

  const removePlaceFromDay = (placeId) => {
    Alert.alert("Remove Place", "Are you sure you want to remove this place?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove",
        style: "destructive",
        onPress: () => {
          const updatedDays = [...days]
          updatedDays[activeDay].places = updatedDays[activeDay].places.filter((place) => place.id !== placeId)
          setDays(updatedDays)

          // Update trip progress
          calculateTripProgress()
        },
      },
    ])
  }

  const handleDragEnd = ({ data }) => {
    const updatedDays = [...days]
    updatedDays[activeDay].places = data
    setDays(updatedDays)
  }

  const addDay = () => {
    const lastDay = days[days.length - 1]
    const newDayDate = new Date(lastDay.date.getTime() + 24 * 60 * 60 * 1000)
    const newDay = {
      id: `day-${days.length}`,
      date: newDayDate,
      places: [],
    }
    setDays([...days, newDay])
    setEndDate(newDayDate)
  }

  const removeDay = (index) => {
    if (days.length <= 1) {
      Alert.alert("Cannot Remove", "You must have at least one day in your itinerary.")
      return
    }

    Alert.alert("Remove Day", "Are you sure you want to remove this day?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove",
        style: "destructive",
        onPress: () => {
          const updatedDays = days.filter((_, i) => i !== index)
          setDays(updatedDays)
          if (activeDay >= updatedDays.length) {
            setActiveDay(updatedDays.length - 1)
          }
          // Update end date if removing the last day
          if (index === days.length - 1 && updatedDays.length > 0) {
            setEndDate(updatedDays[updatedDays.length - 1].date)
          }
        },
      },
    ])
  }

  const addExpense = () => {
    Alert.prompt("Add Expense", "Enter expense category:", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Next",
        onPress: (category) => {
          if (!category) return

          Alert.prompt("Amount", "Enter amount:", [
            { text: "Cancel", style: "cancel" },
            {
              text: "Add",
              onPress: (amountStr) => {
                const amount = Number.parseFloat(amountStr)
                if (isNaN(amount)) {
                  Alert.alert("Invalid Amount", "Please enter a valid number.")
                  return
                }

                const newExpense = {
                  id: `expense-${Date.now()}`,
                  category,
                  amount,
                  currency: "USD",
                  day: activeDay,
                }

                const updatedExpenses = [...expenses, newExpense]
                setExpenses(updatedExpenses)
                calculateTotalExpenses(updatedExpenses)
                calculateTripProgress()
              },
            },
          ])
        },
      },
    ])
  }

  const removeExpense = (expenseId) => {
    const updatedExpenses = expenses.filter((expense) => expense.id !== expenseId)
    setExpenses(updatedExpenses)
    calculateTotalExpenses(updatedExpenses)
    calculateTripProgress()
  }

  const addNote = () => {
    setCurrentNote({ id: null, text: "" })
    setIsEditing(true)
    setShowNotes(true)
  }

  const saveNote = () => {
    if (!currentNote.text.trim()) {
      setIsEditing(false)
      return
    }

    if (currentNote.id) {
      // Update existing note
      const updatedNotes = notes.map((note) =>
        note.id === currentNote.id ? { ...note, text: currentNote.text } : note,
      )
      setNotes(updatedNotes)
    } else {
      // Add new note
      const newNote = {
        id: `note-${Date.now()}`,
        text: currentNote.text,
        day: activeDay,
      }
      setNotes([...notes, newNote])
    }

    setIsEditing(false)
    setCurrentNote({ id: null, text: "" })
    calculateTripProgress()
  }

  const editNote = (note) => {
    setCurrentNote(note)
    setIsEditing(true)
  }

  const removeNote = (noteId) => {
    const updatedNotes = notes.filter((note) => note.id !== noteId)
    setNotes(updatedNotes)
    calculateTripProgress()
  }

  const inviteCollaborator = () => {
    Alert.prompt("Invite Collaborator", "Enter email address:", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Invite",
        onPress: (email) => {
          if (!email || !email.includes("@")) {
            Alert.alert("Invalid Email", "Please enter a valid email address.")
            return
          }

          Alert.alert("Invitation Sent", `An invitation has been sent to ${email}.`)
          // In a real app, you would send an invitation to the server
        },
      },
    ])
  }

  const removeCollaborator = (collaboratorId) => {
    const updatedCollaborators = collaborators.filter((collab) => collab.id !== collaboratorId)
    setCollaborators(updatedCollaborators)
  }

  const toggleOfflineMode = () => {
    setIsOfflineMode(!isOfflineMode)
    Alert.alert(
      isOfflineMode ? "Online Mode" : "Offline Mode",
      isOfflineMode
        ? "Your itinerary is now syncing with the cloud."
        : "Your itinerary is now available offline. Changes will sync when you're back online.",
    )
  }

  const shareItinerary = () => {
    Alert.alert(
      "Share Itinerary",
      "Choose how you want to share your itinerary:",
      [
        {
          text: "Copy Link",
          onPress: () => Alert.alert("Link Copied", "Itinerary link copied to clipboard!"),
        },
        {
          text: "Export PDF",
          onPress: () => Alert.alert("PDF Generated", "Your itinerary PDF has been generated and saved."),
        },
        {
          text: "Share to Community",
          onPress: () => Alert.alert("Shared to Community", "Your itinerary is now visible to the NavTrail community!"),
        },
        { text: "Cancel", style: "cancel" },
      ],
      { cancelable: true },
    )
  }

  const renderPlaceItem = ({ item, drag, isActive }) => (
    <TouchableOpacity
      style={[styles.placeItem, isActive && styles.placeItemDragging]}
      onLongPress={drag}
      delayLongPress={200}
      activeOpacity={0.7}
    >
      <Image source={{ uri: item.image || "https://via.placeholder.com/60" }} style={styles.placeImage} />
      <View style={styles.placeContent}>
        <Text style={styles.placeName}>{item.name}</Text>
        <Text style={styles.placeLocation}>{item.location}</Text>
        <Text style={styles.placeDuration}>{item.duration} min</Text>
      </View>
      <View style={styles.placeActions}>
        <TouchableOpacity style={styles.placeAction} onPress={() => navigation.navigate("Map", { place: item })}>
          <Ionicons name="map" size={20} color="#4CAF50" />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.placeAction}
          onPress={() => navigation.navigate("RealTimeNavigation", { destination: item })}
        >
          <Ionicons name="navigate" size={20} color="#2196F3" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.placeAction} onPress={() => removePlaceFromDay(item.id)}>
          <Ionicons name="trash" size={20} color="#F44336" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  )

  const renderSearchResult = ({ item }) => (
    <TouchableOpacity style={styles.searchResultItem} onPress={() => addPlaceToDay(item)}>
      <Image source={{ uri: item.image || "https://via.placeholder.com/60" }} style={styles.searchResultImage} />
      <View style={styles.searchResultContent}>
        <Text style={styles.searchResultName}>{item.name}</Text>
        <Text style={styles.searchResultLocation}>{item.location}</Text>
        {item.rating && (
          <View style={styles.ratingContainer}>
            <Ionicons name="star" size={16} color="#FFC107" />
            <Text style={styles.rating}>{item.rating}</Text>
            {item.reviewCount && <Text style={styles.reviewCount}>({item.reviewCount})</Text>}
          </View>
        )}
      </View>
      <Ionicons name="add-circle" size={24} color="#4CAF50" />
    </TouchableOpacity>
  )

  const renderDayTab = (day, index) => (
    <TouchableOpacity
      key={day.id}
      style={[styles.dayTab, activeDay === index && styles.activeDayTab]}
      onPress={() => setActiveDay(index)}
    >
      <Text style={[styles.dayTabText, activeDay === index && styles.activeDayTabText]}>
        Day {index + 1}
        {day.date && (
          <>
            {"\n"}
            <Text style={styles.dayTabDate}>{day.date.toLocaleDateString([], { month: "short", day: "numeric" })}</Text>
          </>
        )}
      </Text>
      {days.length > 1 && (
        <TouchableOpacity style={styles.removeDayButton} onPress={() => removeDay(index)}>
          <Ionicons name="close-circle" size={16} color="#F44336" />
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  )

  const renderExpenseItem = ({ item }) => (
    <View style={styles.expenseItem}>
      <View style={styles.expenseInfo}>
        <Text style={styles.expenseCategory}>{item.category}</Text>
        <Text style={styles.expenseDay}>Day {item.day + 1}</Text>
      </View>
      <Text style={styles.expenseAmount}>
        {item.currency} {item.amount.toFixed(2)}
      </Text>
      <TouchableOpacity style={styles.removeExpenseButton} onPress={() => removeExpense(item.id)}>
        <Ionicons name="close-circle" size={20} color="#F44336" />
      </TouchableOpacity>
    </View>
  )

  const renderNoteItem = ({ item }) => (
    <View style={styles.noteItem}>
      <Text style={styles.noteText}>{item.text}</Text>
      <Text style={styles.noteDay}>Day {item.day + 1}</Text>
      <View style={styles.noteActions}>
        <TouchableOpacity style={styles.noteAction} onPress={() => editNote(item)}>
          <Ionicons name="create" size={20} color="#2196F3" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.noteAction} onPress={() => removeNote(item.id)}>
          <Ionicons name="trash" size={20} color="#F44336" />
        </TouchableOpacity>
      </View>
    </View>
  )

  const renderCollaboratorItem = ({ item }) => (
    <View style={styles.collaboratorItem}>
      <Image source={{ uri: item.avatar }} style={styles.collaboratorAvatar} />
      <View style={styles.collaboratorInfo}>
        <Text style={styles.collaboratorName}>{item.name}</Text>
        <Text style={styles.collaboratorStatus}>{item.status === "active" ? "Active" : "Pending"}</Text>
      </View>
      <TouchableOpacity style={styles.removeCollaboratorButton} onPress={() => removeCollaborator(item.id)}>
        <Ionicons name="close-circle" size={20} color="#F44336" />
      </TouchableOpacity>
    </View>
  )

  const searchHeight = searchAnimation.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 300],
  })

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <TextInput
          style={styles.tripNameInput}
          value={tripName}
          onChangeText={setTripName}
          onEndEditing={calculateTripProgress}
        />
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerAction} onPress={toggleOfflineMode}>
            <Ionicons name={isOfflineMode ? "cloud-offline" : "cloud"} size={24} color="#212121" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerAction} onPress={shareItinerary}>
            <Ionicons name="share" size={24} color="#212121" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <View style={[styles.progress, { width: `${tripProgress}%` }]} />
        </View>
        <View style={styles.progressInfo}>
          <Text style={styles.progressText}>{tripProgress}% Complete</Text>
          <Text style={styles.userLevel}>{userLevel} Planner</Text>
        </View>
      </View>

      <View style={styles.daysContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.dayTabs}>
          {days.map((day, index) => renderDayTab(day, index))}
          <TouchableOpacity style={styles.addDayButton} onPress={addDay}>
            <Ionicons name="add" size={20} color="#4CAF50" />
            <Text style={styles.addDayText}>Add Day</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      <View style={styles.content}>
        <View style={styles.mapContainer}>
          <MapView
            ref={mapRef}
            provider={PROVIDER_GOOGLE}
            style={styles.map}
            initialRegion={mapRegion}
            showsUserLocation
            showsMyLocationButton
          >
            {days[activeDay]?.places.map((place, index) => (
              <Marker
                key={place.id}
                coordinate={place.coordinates}
                title={place.name}
                description={place.location}
                pinColor={index === 0 ? "#4CAF50" : index === days[activeDay].places.length - 1 ? "#F44336" : "#2196F3"}
              >
                <View style={styles.markerContainer}>
                  <View
                    style={[
                      styles.marker,
                      {
                        backgroundColor:
                          index === 0 ? "#4CAF50" : index === days[activeDay].places.length - 1 ? "#F44336" : "#2196F3",
                      },
                    ]}
                  >
                    <Text style={styles.markerText}>{index + 1}</Text>
                  </View>
                </View>
              </Marker>
            ))}
            {routeCoordinates.length > 1 && (
              <Polyline coordinates={routeCoordinates} strokeWidth={3} strokeColor="#2196F3" />
            )}
          </MapView>

          {routeCoordinates.length > 1 && (
            <View style={styles.routeInfo}>
              <Text style={styles.routeInfoText}>
                Distance: {totalDistance.toFixed(1)} km • Est. Time: {Math.round(totalDuration)} min
              </Text>
            </View>
          )}

          <View style={styles.mapActions}>
            <TouchableOpacity style={styles.mapAction} onPress={toggleSearch}>
              <Ionicons name="search" size={24} color="#212121" />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.mapAction}
              onPress={() => {
                if (days[activeDay]?.places.length > 0) {
                  const coordinates = days[activeDay].places.map((place) => ({
                    latitude: place.coordinates.latitude,
                    longitude: place.coordinates.longitude,
                  }))
                  mapRef.current?.fitToCoordinates(coordinates, {
                    edgePadding: { top: 50, right: 50, bottom: 50, left: 50 },
                    animated: true,
                  })
                }
              }}
            >
              <Ionicons name="expand" size={24} color="#212121" />
            </TouchableOpacity>
          </View>
        </View>

        <Animated.View style={[styles.searchContainer, { height: searchHeight }]}>
          <View style={styles.searchInputContainer}>
            <Ionicons name="search" size={20} color="#757575" style={styles.searchIcon} />
            <TextInput
              ref={searchInputRef}
              style={styles.searchInput}
              placeholder="Search for places, attractions, restaurants..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              onSubmitEditing={handleSearch}
            />
            {searchQuery ? (
              <TouchableOpacity onPress={() => setSearchQuery("")}>
                <Ionicons name="close-circle" size={20} color="#757575" />
              </TouchableOpacity>
            ) : null}
          </View>
          <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
            <Text style={styles.searchButtonText}>Search</Text>
          </TouchableOpacity>

          {isSearching ? (
            <View style={styles.searchLoadingContainer}>
              <ActivityIndicator size="large" color="#4CAF50" />
              <Text style={styles.searchLoadingText}>Searching...</Text>
            </View>
          ) : (
            <ScrollView style={styles.searchResults}>
              {searchResults.map((result) => (
                <TouchableOpacity key={result.id} style={styles.searchResultItem} onPress={() => addPlaceToDay(result)}>
                  <Image
                    source={{ uri: result.image || "https://via.placeholder.com/60" }}
                    style={styles.searchResultImage}
                  />
                  <View style={styles.searchResultContent}>
                    <Text style={styles.searchResultName}>{result.name}</Text>
                    <Text style={styles.searchResultLocation}>{result.location}</Text>
                    {result.rating && (
                      <View style={styles.ratingContainer}>
                        <Ionicons name="star" size={16} color="#FFC107" />
                        <Text style={styles.rating}>{result.rating}</Text>
                        {result.reviewCount && <Text style={styles.reviewCount}>({result.reviewCount})</Text>}
                      </View>
                    )}
                  </View>
                  <Ionicons name="add-circle" size={24} color="#4CAF50" />
                </TouchableOpacity>
              ))}
            </ScrollView>
          )}
        </Animated.View>

        <View style={styles.itineraryContainer}>
          <View style={styles.itineraryHeader}>
            <Text style={styles.itineraryTitle}>Day {activeDay + 1} Itinerary</Text>
            <View style={styles.itineraryActions}>
              <TouchableOpacity style={styles.itineraryAction} onPress={() => setShowExpenses(!showExpenses)}>
                <Ionicons name="cash" size={20} color="#212121" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.itineraryAction} onPress={() => setShowNotes(!showNotes)}>
                <Ionicons name="document-text" size={20} color="#212121" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.itineraryAction} onPress={() => setShowCollaborators(!showCollaborators)}>
                <Ionicons name="people" size={20} color="#212121" />
              </TouchableOpacity>
            </View>
          </View>

          {showExpenses && (
            <View style={styles.expensesContainer}>
              <View style={styles.expensesHeader}>
                <Text style={styles.expensesTitle}>Expenses</Text>
                <Text style={styles.totalExpenses}>Total: ${totalExpenses.toFixed(2)}</Text>
              </View>
              <ScrollView style={styles.expensesList}>
                {expenses
                  .filter((expense) => expense.day === activeDay)
                  .map((expense) => (
                    <View key={expense.id} style={styles.expenseItem}>
                      <View style={styles.expenseInfo}>
                        <Text style={styles.expenseCategory}>{expense.category}</Text>
                      </View>
                      <Text style={styles.expenseAmount}>
                        {expense.currency} {expense.amount.toFixed(2)}
                      </Text>
                      <TouchableOpacity style={styles.removeExpenseButton} onPress={() => removeExpense(expense.id)}>
                        <Ionicons name="close-circle" size={20} color="#F44336" />
                      </TouchableOpacity>
                    </View>
                  ))}
                <TouchableOpacity style={styles.addExpenseButton} onPress={addExpense}>
                  <Ionicons name="add-circle" size={20} color="#4CAF50" />
                  <Text style={styles.addExpenseText}>Add Expense</Text>
                </TouchableOpacity>
              </ScrollView>
            </View>
          )}

          {showNotes && (
            <View style={styles.notesContainer}>
              <Text style={styles.notesTitle}>Notes</Text>
              {isEditing ? (
                <View style={styles.noteEditContainer}>
                  <TextInput
                    style={styles.noteInput}
                    multiline
                    placeholder="Enter your note here..."
                    value={currentNote.text}
                    onChangeText={(text) => setCurrentNote({ ...currentNote, text })}
                  />
                  <View style={styles.noteEditActions}>
                    <TouchableOpacity style={styles.noteEditAction} onPress={() => setIsEditing(false)}>
                      <Text style={styles.noteEditActionText}>Cancel</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.noteEditAction} onPress={saveNote}>
                      <Text style={[styles.noteEditActionText, { color: "#4CAF50" }]}>Save</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ) : (
                <ScrollView style={styles.notesList}>
                  {notes
                    .filter((note) => note.day === activeDay)
                    .map((note) => (
                      <View key={note.id} style={styles.noteItem}>
                        <Text style={styles.noteText}>{note.text}</Text>
                        <View style={styles.noteActions}>
                          <TouchableOpacity style={styles.noteAction} onPress={() => editNote(note)}>
                            <Ionicons name="create" size={20} color="#2196F3" />
                          </TouchableOpacity>
                          <TouchableOpacity style={styles.noteAction} onPress={() => removeNote(note.id)}>
                            <Ionicons name="trash" size={20} color="#F44336" />
                          </TouchableOpacity>
                        </View>
                      </View>
                    ))}
                  <TouchableOpacity style={styles.addNoteButton} onPress={addNote}>
                    <Ionicons name="add-circle" size={20} color="#4CAF50" />
                    <Text style={styles.addNoteText}>Add Note</Text>
                  </TouchableOpacity>
                </ScrollView>
              )}
            </View>
          )}

          {showCollaborators && (
            <View style={styles.collaboratorsContainer}>
              <Text style={styles.collaboratorsTitle}>Collaborators</Text>
              <ScrollView style={styles.collaboratorsList}>
                {collaborators.map((collaborator) => (
                  <View key={collaborator.id} style={styles.collaboratorItem}>
                    <Image source={{ uri: collaborator.avatar }} style={styles.collaboratorAvatar} />
                    <View style={styles.collaboratorInfo}>
                      <Text style={styles.collaboratorName}>{collaborator.name}</Text>
                      <Text style={styles.collaboratorStatus}>
                        {collaborator.status === "active" ? "Active" : "Pending"}
                      </Text>
                    </View>
                    <TouchableOpacity
                      style={styles.removeCollaboratorButton}
                      onPress={() => removeCollaborator(collaborator.id)}
                    >
                      <Ionicons name="close-circle" size={20} color="#F44336" />
                    </TouchableOpacity>
                  </View>
                ))}
                <TouchableOpacity style={styles.inviteButton} onPress={inviteCollaborator}>
                  <Ionicons name="person-add" size={20} color="#4CAF50" />
                  <Text style={styles.inviteButtonText}>Invite Collaborator</Text>
                </TouchableOpacity>
              </ScrollView>
            </View>
          )}

          {days[activeDay]?.places.length > 0 ? (
            <DraggableFlatList
              data={days[activeDay].places}
              renderItem={renderPlaceItem}
              keyExtractor={(item) => item.id}
              onDragEnd={handleDragEnd}
              contentContainerStyle={styles.placesList}
            />
          ) : (
            <View style={styles.emptyPlacesContainer}>
              <Ionicons name="map" size={64} color="#E0E0E0" />
              <Text style={styles.emptyPlacesText}>No places added yet</Text>
              <Text style={styles.emptyPlacesSubtext}>Search and add places to your itinerary</Text>
              <TouchableOpacity style={styles.searchPlacesButton} onPress={toggleSearch}>
                <Text style={styles.searchPlacesButtonText}>Search Places</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    padding: 8,
  },
  tripNameInput: {
    flex: 1,
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
    textAlign: "center",
  },
  headerActions: {
    flexDirection: "row",
  },
  headerAction: {
    padding: 8,
    marginLeft: 8,
  },
  progressContainer: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  progressBar: {
    height: 6,
    backgroundColor: "#f0f0f0",
    borderRadius: 3,
    marginBottom: 4,
  },
  progress: {
    height: 6,
    backgroundColor: "#4CAF50",
    borderRadius: 3,
  },
  progressInfo: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  progressText: {
    fontSize: 12,
    color: "#757575",
  },
  userLevel: {
    fontSize: 12,
    color: "#4CAF50",
    fontWeight: "bold",
  },
  daysContainer: {
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  dayTabs: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  dayTab: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: "#f5f5f5",
    marginRight: 8,
    minWidth: 80,
    alignItems: "center",
  },
  activeDayTab: {
    backgroundColor: "#4CAF50",
  },
  dayTabText: {
    fontSize: 14,
    color: "#757575",
    textAlign: "center",
  },
  activeDayTabText: {
    color: "#fff",
    fontWeight: "bold",
  },
  dayTabDate: {
    fontSize: 12,
  },
  removeDayButton: {
    position: "absolute",
    top: -4,
    right: -4,
    backgroundColor: "#fff",
    borderRadius: 10,
  },
  addDayButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: "#e8f5e9",
    marginRight: 8,
  },
  addDayText: {
    fontSize: 14,
    color: "#4CAF50",
    marginLeft: 4,
  },
  content: {
    flex: 1,
  },
  mapContainer: {
    height: 200,
    position: "relative",
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  markerContainer: {
    alignItems: "center",
  },
  marker: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "#2196F3",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#fff",
  },
  markerText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "bold",
  },
  routeInfo: {
    position: "absolute",
    bottom: 8,
    left: 8,
    right: 8,
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    borderRadius: 8,
    padding: 8,
    alignItems: "center",
  },
  routeInfoText: {
    fontSize: 12,
    color: "#212121",
  },
  mapActions: {
    position: "absolute",
    top: 8,
    right: 8,
    backgroundColor: "#fff",
    borderRadius: 8,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
  },
  mapAction: {
    padding: 8,
  },
  searchContainer: {
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
    overflow: "hidden",
  },
  searchInputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    borderRadius: 8,
    paddingHorizontal: 12,
    margin: 16,
    marginBottom: 8,
    height: 40,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: "#212121",
  },
  searchButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    alignSelf: "center",
    marginBottom: 8,
  },
  searchButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  searchLoadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  searchLoadingText: {
    marginTop: 8,
    color: "#757575",
  },
  searchResults: {
    flex: 1,
  },
  searchResultItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  searchResultImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  searchResultContent: {
    flex: 1,
  },
  searchResultName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  searchResultLocation: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  rating: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginLeft: 4,
  },
  reviewCount: {
    fontSize: 14,
    color: "#757575",
    marginLeft: 4,
  },
  itineraryContainer: {
    flex: 1,
  },
  itineraryHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  itineraryTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  itineraryActions: {
    flexDirection: "row",
  },
  itineraryAction: {
    padding: 8,
    marginLeft: 8,
  },
  placesList: {
    padding: 16,
  },
  placeItem: {
    flexDirection: "row",
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  placeItemDragging: {
    opacity: 0.7,
    backgroundColor: "#e8f5e9",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
  },
  placeImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  placeContent: {
    flex: 1,
  },
  placeName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  placeLocation: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 4,
  },
  placeDuration: {
    fontSize: 14,
    color: "#4CAF50",
  },
  placeActions: {
    justifyContent: "space-between",
  },
  placeAction: {
    padding: 8,
  },
  emptyPlacesContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  emptyPlacesText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#757575",
    marginTop: 16,
  },
  emptyPlacesSubtext: {
    fontSize: 14,
    color: "#9E9E9E",
    marginTop: 8,
    textAlign: "center",
  },
  searchPlacesButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginTop: 16,
  },
  searchPlacesButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  expensesContainer: {
    backgroundColor: "#f9f9f9",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  expensesHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  expensesTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
  },
  totalExpenses: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#4CAF50",
  },
  expensesList: {
    maxHeight: 150,
  },
  expenseItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  expenseInfo: {
    flex: 1,
  },
  expenseCategory: {
    fontSize: 14,
    color: "#212121",
  },
  expenseDay: {
    fontSize: 12,
    color: "#757575",
  },
  expenseAmount: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginRight: 8,
  },
  removeExpenseButton: {
    padding: 4,
  },
  addExpenseButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
    marginTop: 8,
  },
  addExpenseText: {
    fontSize: 14,
    color: "#4CAF50",
    marginLeft: 8,
  },
  notesContainer: {
    backgroundColor: "#f9f9f9",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  notesTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 8,
  },
  notesList: {
    maxHeight: 150,
  },
  noteItem: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    borderLeftWidth: 3,
    borderLeftColor: "#4CAF50",
  },
  noteText: {
    fontSize: 14,
    color: "#212121",
    marginBottom: 4,
  },
  noteDay: {
    fontSize: 12,
    color: "#757575",
  },
  noteActions: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: 8,
  },
  noteAction: {
    padding: 4,
    marginLeft: 8,
  },
  noteEditContainer: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },
  noteInput: {
    fontSize: 14,
    color: "#212121",
    minHeight: 80,
    textAlignVertical: "top",
  },
  noteEditActions: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: 8,
  },
  noteEditAction: {
    padding: 8,
    marginLeft: 8,
  },
  noteEditActionText: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#757575",
  },
  addNoteButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
  },
  addNoteText: {
    fontSize: 14,
    color: "#4CAF50",
    marginLeft: 8,
  },
  collaboratorsContainer: {
    backgroundColor: "#f9f9f9",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  collaboratorsTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 8,
  },
  collaboratorsList: {
    maxHeight: 150,
  },
  collaboratorItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  collaboratorAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  collaboratorInfo: {
    flex: 1,
  },
  collaboratorName: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
  },
  collaboratorStatus: {
    fontSize: 12,
    color: "#757575",
  },
  removeCollaboratorButton: {
    padding: 4,
  },
  inviteButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
    marginTop: 8,
  },
  inviteButtonText: {
    fontSize: 14,
    color: "#4CAF50",
    marginLeft: 8,
  },
})

export default ItineraryBuilderScreen
