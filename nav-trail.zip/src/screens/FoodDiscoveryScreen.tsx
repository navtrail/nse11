"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
  Image,
  TextInput,
  ActivityIndicator,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { getFoodRecommendations, getHiddenGems } from "../services/ai"

const FoodDiscoveryScreen = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState("")
  const [cuisine, setCuisine] = useState("")
  const [budget, setBudget] = useState("medium")
  const [restaurants, setRestaurants] = useState([])
  const [hiddenGems, setHiddenGems] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("all")
  const [dietaryFilters, setDietaryFilters] = useState([])
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    fetchRestaurants()
  }, [])

  const fetchRestaurants = async () => {
    setIsLoading(true)
    try {
      const location = "San Francisco" // In a real app, this would be the user's current location or selected city
      const restaurantsData = await getFoodRecommendations(location, cuisine, budget)
      setRestaurants(restaurantsData)

      // Get hidden gems for food
      const gemsData = await getHiddenGems(location, ["food"])
      setHiddenGems(gemsData.filter((gem) => gem.type === "food"))
    } catch (error) {
      console.error("Error fetching restaurants:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSearch = () => {
    fetchRestaurants()
  }

  const toggleDietaryFilter = (filter) => {
    if (dietaryFilters.includes(filter)) {
      setDietaryFilters(dietaryFilters.filter((f) => f !== filter))
    } else {
      setDietaryFilters([...dietaryFilters, filter])
    }
  }

  const filterRestaurants = (restaurants) => {
    let filtered = restaurants

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(
        (restaurant) =>
          restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          restaurant.cuisine.toLowerCase().includes(searchQuery.toLowerCase()) ||
          restaurant.description.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Filter by cuisine
    if (cuisine) {
      filtered = filtered.filter((restaurant) => restaurant.cuisine.toLowerCase() === cuisine.toLowerCase())
    }

    // Filter by dietary restrictions
    if (dietaryFilters.length > 0) {
      // In a real app, this would check against actual dietary attributes
      filtered = filtered.filter(
        (restaurant) => Math.random() > 0.5, // Randomly filter for demo purposes
      )
    }

    // Filter by tab
    if (activeTab === "trending") {
      filtered = filtered.filter((restaurant) => restaurant.rating >= 4.5)
    } else if (activeTab === "hidden") {
      return hiddenGems
    }

    return filtered
  }

  const renderCuisineItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.cuisineItem, cuisine === item.value && styles.cuisineItemSelected]}
      onPress={() => setCuisine(cuisine === item.value ? "" : item.value)}
    >
      <Ionicons name={item.icon} size={24} color={cuisine === item.value ? "#fff" : "#757575"} />
      <Text style={[styles.cuisineText, cuisine === item.value && styles.cuisineTextSelected]}>{item.label}</Text>
    </TouchableOpacity>
  )

  const renderRestaurantItem = ({ item }) => (
    <TouchableOpacity
      style={styles.restaurantItem}
      onPress={() => navigation.navigate("RestaurantDetail", { restaurant: item })}
    >
      <Image source={{ uri: item.image }} style={styles.restaurantImage} />
      <View style={styles.restaurantContent}>
        <Text style={styles.restaurantName}>{item.name}</Text>
        <View style={styles.restaurantInfo}>
          <Text style={styles.cuisineTag}>{item.cuisine}</Text>
          <Text style={styles.priceRange}>{item.priceRange}</Text>
        </View>
        <View style={styles.ratingContainer}>
          <Ionicons name="star" size={16} color="#FFC107" />
          <Text style={styles.rating}>{item.rating}</Text>
          <Text style={styles.reviewCount}>({item.reviewCount})</Text>
        </View>
        <Text style={styles.restaurantAddress} numberOfLines={1}>
          {item.address}
        </Text>
      </View>
    </TouchableOpacity>
  )

  const cuisines = [
    { label: "All", value: "", icon: "restaurant" },
    { label: "Italian", value: "Italian", icon: "pizza" },
    { label: "Chinese", value: "Chinese", icon: "restaurant" },
    { label: "Mexican", value: "Mexican", icon: "restaurant" },
    { label: "Japanese", value: "Japanese", icon: "restaurant" },
    { label: "Indian", value: "Indian", icon: "restaurant" },
    { label: "Thai", value: "Thai", icon: "restaurant" },
    { label: "French", value: "French", icon: "restaurant" },
  ]

  const dietaryOptions = [
    { label: "Vegetarian", value: "vegetarian" },
    { label: "Vegan", value: "vegan" },
    { label: "Gluten-Free", value: "gluten-free" },
    { label: "Nut-Free", value: "nut-free" },
    { label: "Dairy-Free", value: "dairy-free" },
  ]

  const filteredRestaurants = filterRestaurants(restaurants)

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Food Discovery</Text>
        <TouchableOpacity style={styles.mapButton} onPress={() => navigation.navigate("Map")}>
          <Ionicons name="map" size={24} color="#212121" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Ionicons name="search" size={20} color="#757575" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search restaurants, cuisines..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
          />
          {searchQuery ? (
            <TouchableOpacity onPress={() => setSearchQuery("")}>
              <Ionicons name="close-circle" size={20} color="#757575" />
            </TouchableOpacity>
          ) : null}
        </View>
        <TouchableOpacity style={styles.filterButton} onPress={() => setShowFilters(!showFilters)}>
          <Ionicons name="options" size={20} color="#4CAF50" />
        </TouchableOpacity>
      </View>

      {showFilters && (
        <View style={styles.filtersContainer}>
          <Text style={styles.filterTitle}>Dietary Restrictions</Text>
          <View style={styles.dietaryFilters}>
            {dietaryOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                style={[styles.dietaryFilter, dietaryFilters.includes(option.value) && styles.dietaryFilterSelected]}
                onPress={() => toggleDietaryFilter(option.value)}
              >
                <Text
                  style={[
                    styles.dietaryFilterText,
                    dietaryFilters.includes(option.value) && styles.dietaryFilterTextSelected,
                  ]}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.filterTitle}>Budget</Text>
          <View style={styles.budgetContainer}>
            <TouchableOpacity
              style={[styles.budgetButton, budget === "budget" && styles.budgetButtonSelected]}
              onPress={() => setBudget("budget")}
            >
              <Text style={[styles.budgetText, budget === "budget" && styles.budgetTextSelected]}>$</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.budgetButton, budget === "medium" && styles.budgetButtonSelected]}
              onPress={() => setBudget("medium")}
            >
              <Text style={[styles.budgetText, budget === "medium" && styles.budgetTextSelected]}>$$</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.budgetButton, budget === "luxury" && styles.budgetButtonSelected]}
              onPress={() => setBudget("luxury")}
            >
              <Text style={[styles.budgetText, budget === "luxury" && styles.budgetTextSelected]}>$$$</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={styles.applyButton}
            onPress={() => {
              setShowFilters(false)
              handleSearch()
            }}
          >
            <Text style={styles.applyButtonText}>Apply Filters</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.cuisinesContainer}>
        <FlatList
          data={cuisines}
          renderItem={renderCuisineItem}
          keyExtractor={(item) => item.value}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cuisinesList}
        />
      </View>

      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "all" && styles.activeTab]}
          onPress={() => setActiveTab("all")}
        >
          <Text style={[styles.tabText, activeTab === "all" && styles.activeTabText]}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === "trending" && styles.activeTab]}
          onPress={() => setActiveTab("trending")}
        >
          <Text style={[styles.tabText, activeTab === "trending" && styles.activeTabText]}>Trending</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === "hidden" && styles.activeTab]}
          onPress={() => setActiveTab("hidden")}
        >
          <Text style={[styles.tabText, activeTab === "hidden" && styles.activeTabText]}>Hidden Gems</Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4CAF50" />
          <Text style={styles.loadingText}>Finding delicious options...</Text>
        </View>
      ) : filteredRestaurants.length > 0 ? (
        <FlatList
          data={filteredRestaurants}
          renderItem={renderRestaurantItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.restaurantsList}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Ionicons name="restaurant" size={64} color="#E0E0E0" />
          <Text style={styles.emptyText}>No restaurants found</Text>
          <Text style={styles.emptySubtext}>Try adjusting your filters</Text>
        </View>
      )}
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  mapButton: {
    padding: 8,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 40,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: "#212121",
  },
  filterButton: {
    marginLeft: 12,
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: "#f5f5f5",
    justifyContent: "center",
    alignItems: "center",
  },
  filtersContainer: {
    backgroundColor: "#f9f9f9",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  filterTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 8,
  },
  dietaryFilters: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 16,
  },
  dietaryFilter: {
    borderWidth: 1,
    borderColor: "#e0e0e0",
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginRight: 8,
    marginBottom: 8,
  },
  dietaryFilterSelected: {
    backgroundColor: "#4CAF50",
    borderColor: "#4CAF50",
  },
  dietaryFilterText: {
    fontSize: 14,
    color: "#757575",
  },
  dietaryFilterTextSelected: {
    color: "#fff",
  },
  budgetContainer: {
    flexDirection: "row",
    marginBottom: 16,
  },
  budgetButton: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#e0e0e0",
    borderRadius: 8,
    padding: 12,
    marginHorizontal: 4,
  },
  budgetButtonSelected: {
    backgroundColor: "#4CAF50",
    borderColor: "#4CAF50",
  },
  budgetText: {
    fontSize: 16,
    color: "#212121",
    fontWeight: "600",
  },
  budgetTextSelected: {
    color: "#fff",
  },
  applyButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: "center",
  },
  applyButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
  cuisinesContainer: {
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  cuisinesList: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  cuisineItem: {
    alignItems: "center",
    justifyContent: "center",
    marginRight: 16,
    width: 80,
  },
  cuisineItemSelected: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    padding: 8,
  },
  cuisineText: {
    fontSize: 12,
    color: "#757575",
    marginTop: 4,
    textAlign: "center",
  },
  cuisineTextSelected: {
    color: "#fff",
  },
  tabsContainer: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: "center",
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: "#4CAF50",
  },
  tabText: {
    fontSize: 14,
    color: "#757575",
  },
  activeTabText: {
    color: "#4CAF50",
    fontWeight: "600",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: "#757575",
  },
  restaurantsList: {
    padding: 16,
  },
  restaurantItem: {
    flexDirection: "row",
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    marginBottom: 16,
    overflow: "hidden",
  },
  restaurantImage: {
    width: 120,
    height: 120,
  },
  restaurantContent: {
    flex: 1,
    padding: 12,
  },
  restaurantName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  restaurantInfo: {
    flexDirection: "row",
    marginBottom: 4,
  },
  cuisineTag: {
    fontSize: 14,
    color: "#757575",
    marginRight: 8,
  },
  priceRange: {
    fontSize: 14,
    color: "#4CAF50",
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4,
  },
  rating: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginLeft: 4,
  },
  reviewCount: {
    fontSize: 14,
    color: "#757575",
    marginLeft: 4,
  },
  restaurantAddress: {
    fontSize: 14,
    color: "#757575",
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#757575",
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: "#9E9E9E",
    marginTop: 8,
  },
})

export default FoodDiscoveryScreen
