"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  ScrollView, // Added ScrollView import
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import SearchInput from "../components/SearchInput"
import { getDifficultyColor } from "../utils/helpers"

const SearchScreen = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [results, setResults] = useState([])
  const [recentSearches, setRecentSearches] = useState([
    "Waterfall trails",
    "Mountain views",
    "Dog friendly",
    "Easy hikes",
  ])
  const [filters, setFilters] = useState({
    difficulty: null,
    distance: null,
    elevation: null,
    duration: null,
  })

  // Mock data for trails
  const mockTrails = [
    {
      id: "1",
      name: "Eagle Peak Trail",
      location: "Yosemite National Park, CA",
      distance: 8.2,
      difficulty: "Moderate",
      rating: 4.8,
      reviewCount: 124,
      image:
        "https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
    {
      id: "2",
      name: "Redwood Forest Loop",
      location: "Muir Woods, CA",
      distance: 5.4,
      difficulty: "Easy",
      rating: 4.6,
      reviewCount: 98,
      image:
        "https://images.unsplash.com/photo-1552521684-edc2a078660e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
    {
      id: "3",
      name: "Glacier Point",
      location: "Yosemite National Park, CA",
      distance: 12.7,
      difficulty: "Hard",
      rating: 4.9,
      reviewCount: 156,
      image:
        "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
    {
      id: "4",
      name: "Coastal Bluff Trail",
      location: "Point Reyes, CA",
      distance: 6.3,
      difficulty: "Moderate",
      rating: 4.5,
      reviewCount: 87,
      image:
        "https://images.unsplash.com/photo-1472396961693-142e6e269027?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
    {
      id: "5",
      name: "Mist Trail",
      location: "Yosemite National Park, CA",
      distance: 4.8,
      difficulty: "Moderate",
      rating: 4.7,
      reviewCount: 142,
      image:
        "https://images.unsplash.com/photo-1465311530779-5241f5a29892?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
  ]

  useEffect(() => {
    if (searchQuery) {
      handleSearch()
    }
  }, [searchQuery])

  const handleSearch = () => {
    setIsLoading(true)

    // Simulate API call delay
    setTimeout(() => {
      // Filter trails based on search query
      const filteredResults = mockTrails.filter(
        (trail) =>
          trail.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          trail.location.toLowerCase().includes(searchQuery.toLowerCase()),
      )

      setResults(filteredResults)
      setIsLoading(false)

      // Add to recent searches if not already there
      if (searchQuery && !recentSearches.includes(searchQuery)) {
        setRecentSearches((prev) => [searchQuery, ...prev.slice(0, 3)])
      }
    }, 1000)
  }

  const clearSearch = () => {
    setSearchQuery("")
    setResults([])
  }

  const renderTrailItem = ({ item }) => (
    <TouchableOpacity style={styles.trailItem} onPress={() => navigation.navigate("Map", { trailId: item.id })}>
      <Image source={{ uri: item.image }} style={styles.trailImage} />
      <View style={styles.trailContent}>
        <Text style={styles.trailName}>{item.name}</Text>
        <Text style={styles.trailLocation}>{item.location}</Text>

        <View style={styles.trailDetails}>
          <View style={styles.trailDetail}>
            <Ionicons name="trail-sign-outline" size={16} color="#757575" />
            <Text style={styles.trailDetailText}>{item.distance} km</Text>
          </View>

          <View style={styles.trailDetail}>
            <Ionicons name="stats-chart-outline" size={16} color="#757575" />
            <Text style={[styles.trailDetailText, { color: getDifficultyColor(item.difficulty) }]}>
              {item.difficulty}
            </Text>
          </View>

          <View style={styles.trailDetail}>
            <Ionicons name="star" size={16} color="#FFC107" />
            <Text style={styles.trailDetailText}>
              {item.rating} ({item.reviewCount})
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  )

  const renderFilterChip = (label, isActive, onPress) => (
    <TouchableOpacity style={[styles.filterChip, isActive && styles.activeFilterChip]} onPress={onPress}>
      <Text style={[styles.filterChipText, isActive && styles.activeFilterChipText]}>{label}</Text>
      {isActive && <Ionicons name="close-circle" size={16} color="#fff" style={styles.filterChipIcon} />}
    </TouchableOpacity>
  )

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>

        <View style={styles.searchContainer}>
          <SearchInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search trails, parks, cities..."
            editable={true}
          />
          {searchQuery ? (
            <TouchableOpacity style={styles.clearButton} onPress={clearSearch}>
              <Ionicons name="close-circle" size={20} color="#9E9E9E" />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      <View style={styles.filtersContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filtersScroll}>
          {renderFilterChip("Easy", filters.difficulty === "Easy", () =>
            setFilters((prev) => ({ ...prev, difficulty: prev.difficulty === "Easy" ? null : "Easy" })),
          )}
          {renderFilterChip("Moderate", filters.difficulty === "Moderate", () =>
            setFilters((prev) => ({ ...prev, difficulty: prev.difficulty === "Moderate" ? null : "Moderate" })),
          )}
          {renderFilterChip("Hard", filters.difficulty === "Hard", () =>
            setFilters((prev) => ({ ...prev, difficulty: prev.difficulty === "Hard" ? null : "Hard" })),
          )}
          {renderFilterChip("< 5 km", filters.distance === "short", () =>
            setFilters((prev) => ({ ...prev, distance: prev.distance === "short" ? null : "short" })),
          )}
          {renderFilterChip("5-10 km", filters.distance === "medium", () =>
            setFilters((prev) => ({ ...prev, distance: prev.distance === "medium" ? null : "medium" })),
          )}
          {renderFilterChip("> 10 km", filters.distance === "long", () =>
            setFilters((prev) => ({ ...prev, distance: prev.distance === "long" ? null : "long" })),
          )}

          <TouchableOpacity style={styles.moreFiltersButton}>
            <Ionicons name="options-outline" size={20} color="#4CAF50" />
            <Text style={styles.moreFiltersText}>More Filters</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4CAF50" />
          <Text style={styles.loadingText}>Searching trails...</Text>
        </View>
      ) : results.length > 0 ? (
        <FlatList
          data={results}
          renderItem={renderTrailItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.resultsList}
        />
      ) : (
        <View style={styles.content}>
          {searchQuery ? (
            <View style={styles.noResultsContainer}>
              <Ionicons name="search-outline" size={64} color="#E0E0E0" />
              <Text style={styles.noResultsText}>No trails found</Text>
              <Text style={styles.noResultsSubtext}>Try adjusting your search or filters</Text>
            </View>
          ) : (
            <>
              <View style={styles.recentSearchesContainer}>
                <Text style={styles.sectionTitle}>Recent Searches</Text>
                {recentSearches.map((search, index) => (
                  <TouchableOpacity key={index} style={styles.recentSearchItem} onPress={() => setSearchQuery(search)}>
                    <Ionicons name="time-outline" size={20} color="#9E9E9E" />
                    <Text style={styles.recentSearchText}>{search}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <View style={styles.popularContainer}>
                <Text style={styles.sectionTitle}>Popular Trails Nearby</Text>
                {mockTrails.slice(0, 3).map((trail) => renderTrailItem({ item: trail }))}
              </View>
            </>
          )}
        </View>
      )}
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    marginRight: 12,
  },
  searchContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  clearButton: {
    position: "absolute",
    right: 12,
  },
  filtersContainer: {
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  filtersScroll: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  filterChip: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: "#F5F5F5",
    marginRight: 8,
  },
  activeFilterChip: {
    backgroundColor: "#4CAF50",
  },
  filterChipText: {
    fontSize: 14,
    color: "#757575",
  },
  activeFilterChipText: {
    color: "#fff",
  },
  filterChipIcon: {
    marginLeft: 4,
  },
  moreFiltersButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#4CAF50",
  },
  moreFiltersText: {
    fontSize: 14,
    color: "#4CAF50",
    marginLeft: 4,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: "#757575",
  },
  resultsList: {
    padding: 16,
  },
  trailItem: {
    flexDirection: "row",
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    marginBottom: 16,
    overflow: "hidden",
  },
  trailImage: {
    width: 120,
    height: 120,
  },
  trailContent: {
    flex: 1,
    padding: 12,
  },
  trailName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  trailLocation: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 8,
  },
  trailDetails: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  trailDetail: {
    flexDirection: "row",
    alignItems: "center",
  },
  trailDetailText: {
    fontSize: 14,
    color: "#757575",
    marginLeft: 4,
  },
  noResultsContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  noResultsText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#757575",
    marginTop: 16,
  },
  noResultsSubtext: {
    fontSize: 14,
    color: "#9E9E9E",
    marginTop: 8,
  },
  recentSearchesContainer: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 16,
  },
  recentSearchItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  recentSearchText: {
    fontSize: 16,
    color: "#212121",
    marginLeft: 12,
  },
  popularContainer: {
    flex: 1,
  },
})

export default SearchScreen
