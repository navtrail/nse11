"use client"

import { useState, useEffect, useRef } from "react"
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Dimensions, Animated } from "react-native"
import MapView, { PROVIDER_GOOGLE, Marker, Polyline } from "react-native-maps"
import { Ionicons } from "@expo/vector-icons"
import SearchInput from "../components/SearchInput"

const { width, height } = Dimensions.get("window")
const ASPECT_RATIO = width / height
const LATITUDE_DELTA = 0.0922
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO

const MapScreen = ({ navigation, route }) => {
  const mapRef = useRef(null)
  const [region, setRegion] = useState({
    latitude: 37.78825,
    longitude: -122.4324,
    latitudeDelta: LATITUDE_DELTA,
    longitudeDelta: LONGITUDE_DELTA,
  })
  const [markers, setMarkers] = useState([])
  const [routeCoordinates, setRouteCoordinates] = useState([])
  const [showDirections, setShowDirections] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [steps, setSteps] = useState([])
  const bottomSheetHeight = useRef(new Animated.Value(0)).current

  useEffect(() => {
    // Check if we have route params with coordinates
    if (route.params?.coordinates) {
      setRouteCoordinates(route.params.coordinates)

      // Set markers for start and end points
      const startPoint = route.params.coordinates[0]
      const endPoint = route.params.coordinates[route.params.coordinates.length - 1]

      setMarkers([
        { id: "start", coordinate: startPoint, title: "Start" },
        { id: "end", coordinate: endPoint, title: "Destination" },
      ])

      // Fit map to show the entire route
      if (mapRef.current) {
        mapRef.current.fitToCoordinates(route.params.coordinates, {
          edgePadding: { top: 50, right: 50, bottom: 50, left: 50 },
          animated: true,
        })
      }

      // Set navigation steps if available
      if (route.params?.steps) {
        setSteps(route.params.steps)
        setShowDirections(true)

        // Animate bottom sheet up
        Animated.timing(bottomSheetHeight, {
          toValue: 150,
          duration: 300,
          useNativeDriver: false,
        }).start()
      }
    }
  }, [route.params])

  const handleMapPress = (event) => {
    const { coordinate } = event.nativeEvent

    // If we have less than 2 markers, add a new one
    if (markers.length < 2) {
      setMarkers([
        ...markers,
        {
          id: markers.length === 0 ? "start" : "end",
          coordinate,
          title: markers.length === 0 ? "Start" : "Destination",
        },
      ])
    }

    // If we now have 2 markers, we can calculate a route
    if (markers.length === 1) {
      // In a real app, you would call a routing API here
      // For this example, we'll just create a straight line
      const startPoint = markers[0].coordinate
      setRouteCoordinates([startPoint, coordinate])
    }
  }

  const toggleDirections = () => {
    setShowDirections(!showDirections)

    Animated.timing(bottomSheetHeight, {
      toValue: showDirections ? 0 : 150,
      duration: 300,
      useNativeDriver: false,
    }).start()
  }

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <SearchInput placeholder="Search destination" onPress={() => navigation.navigate("Search")} />
      </View>

      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          provider={PROVIDER_GOOGLE}
          style={styles.map}
          initialRegion={region}
          onPress={handleMapPress}
          showsUserLocation
          showsMyLocationButton
          showsCompass
          showsTraffic
        >
          {markers.map((marker) => (
            <Marker
              key={marker.id}
              coordinate={marker.coordinate}
              title={marker.title}
              pinColor={marker.id === "start" ? "#4CAF50" : "#F44336"}
            />
          ))}

          {routeCoordinates.length > 0 && (
            <Polyline coordinates={routeCoordinates} strokeWidth={4} strokeColor="#4CAF50" />
          )}
        </MapView>

        {/* Map Controls */}
        <View style={styles.mapControls}>
          <TouchableOpacity style={styles.mapButton} onPress={() => mapRef.current?.animateToRegion(region)}>
            <Ionicons name="locate" size={24} color="#212121" />
          </TouchableOpacity>

          {routeCoordinates.length > 0 && (
            <TouchableOpacity style={styles.mapButton} onPress={toggleDirections}>
              <Ionicons name={showDirections ? "chevron-down" : "list"} size={24} color="#212121" />
            </TouchableOpacity>
          )}
        </View>

        {/* Navigation Info */}
        {routeCoordinates.length > 0 && (
          <View style={styles.navInfo}>
            <Text style={styles.etaText}>ETA: 25 min</Text>
            <Text style={styles.distanceText}>5.2 km</Text>
          </View>
        )}

        {/* Bottom Sheet for Directions */}
        <Animated.View style={[styles.directionsSheet, { height: bottomSheetHeight }]}>
          {steps.length > 0 && currentStep < steps.length && (
            <>
              <View style={styles.stepIndicator}>
                <TouchableOpacity style={styles.stepButton} onPress={prevStep} disabled={currentStep === 0}>
                  <Ionicons name="chevron-back" size={24} color={currentStep === 0 ? "#bdbdbd" : "#212121"} />
                </TouchableOpacity>

                <Text style={styles.stepText}>{steps[currentStep]?.maneuver?.instruction || "Follow the route"}</Text>

                <TouchableOpacity
                  style={styles.stepButton}
                  onPress={nextStep}
                  disabled={currentStep === steps.length - 1}
                >
                  <Ionicons
                    name="chevron-forward"
                    size={24}
                    color={currentStep === steps.length - 1 ? "#bdbdbd" : "#212121"}
                  />
                </TouchableOpacity>
              </View>

              <View style={styles.progressBar}>
                <View style={[styles.progress, { width: `${((currentStep + 1) / steps.length) * 100}%` }]} />
              </View>
            </>
          )}
        </Animated.View>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
    zIndex: 10,
  },
  backButton: {
    marginRight: 12,
    padding: 8,
  },
  mapContainer: {
    flex: 1,
    position: "relative",
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapControls: {
    position: "absolute",
    right: 16,
    top: 16,
    backgroundColor: "#fff",
    borderRadius: 8,
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  mapButton: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  navInfo: {
    position: "absolute",
    top: 16,
    left: 16,
    right: 70,
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 12,
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  etaText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  distanceText: {
    fontSize: 14,
    color: "#757575",
    marginTop: 4,
  },
  directionsSheet: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "#fff",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    padding: 16,
    elevation: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  stepIndicator: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  stepButton: {
    padding: 8,
  },
  stepText: {
    flex: 1,
    fontSize: 16,
    color: "#212121",
    textAlign: "center",
    paddingHorizontal: 8,
  },
  progressBar: {
    height: 4,
    backgroundColor: "#e0e0e0",
    borderRadius: 2,
    marginTop: 16,
  },
  progress: {
    height: 4,
    backgroundColor: "#4CAF50",
    borderRadius: 2,
  },
})

export default MapScreen
