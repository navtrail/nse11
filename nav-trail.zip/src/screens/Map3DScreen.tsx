"use client"

import { useState, useEffect, useRef } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
  Platform,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { WebView } from "react-native-webview"
import * as Location from "expo-location"

const { width, height } = Dimensions.get("window")

const Map3DScreen = ({ navigation, route }) => {
  const webViewRef = useRef(null)
  const [isLoading, setIsLoading] = useState(true)
  const [userLocation, setUserLocation] = useState(null)
  const [viewMode, setViewMode] = useState("3d") // '3d', 'satellite', 'street'
  const [tilt, setTilt] = useState(45)
  const [zoom, setZoom] = useState(18)
  const [showBuildings, setShowBuildings] = useState(true)
  const [showTerrain, setShowTerrain] = useState(true)
  const [showLabels, setShowLabels] = useState(true)
  const [selectedPOI, setSelectedPOI] = useState(null)

  useEffect(() => {
    const getLocationPermission = async () => {
      const { status } = await Location.requestForegroundPermissionsAsync()
      if (status !== "granted") {
        console.error("Location permission denied")
        return
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Highest,
      })
      setUserLocation({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      })

      // Send location to WebView when it's ready
      if (webViewRef.current && userLocation) {
        sendMessageToWebView({
          type: "setLocation",
          latitude: userLocation.latitude,
          longitude: userLocation.longitude,
        })
      }
    }

    getLocationPermission()
  }, [])

  const sendMessageToWebView = (message) => {
    if (webViewRef.current) {
      webViewRef.current.postMessage(JSON.stringify(message))
    }
  }

  const handleWebViewMessage = (event) => {
    try {
      const message = JSON.parse(event.nativeEvent.data)

      switch (message.type) {
        case "mapLoaded":
          setIsLoading(false)
          if (userLocation) {
            sendMessageToWebView({
              type: "setLocation",
              latitude: userLocation.latitude,
              longitude: userLocation.longitude,
            })
          }
          break
        case "poiSelected":
          setSelectedPOI(message.poi)
          break
        case "error":
          console.error("WebView error:", message.error)
          break
      }
    } catch (error) {
      console.error("Error parsing WebView message:", error)
    }
  }

  const changeViewMode = (mode) => {
    setViewMode(mode)
    sendMessageToWebView({
      type: "setViewMode",
      mode,
    })
  }

  const changeTilt = (newTilt) => {
    setTilt(newTilt)
    sendMessageToWebView({
      type: "setTilt",
      tilt: newTilt,
    })
  }

  const changeZoom = (newZoom) => {
    setZoom(newZoom)
    sendMessageToWebView({
      type: "setZoom",
      zoom: newZoom,
    })
  }

  const toggleBuildings = () => {
    const newValue = !showBuildings
    setShowBuildings(newValue)
    sendMessageToWebView({
      type: "toggleBuildings",
      show: newValue,
    })
  }

  const toggleTerrain = () => {
    const newValue = !showTerrain
    setShowTerrain(newValue)
    sendMessageToWebView({
      type: "toggleTerrain",
      show: newValue,
    })
  }

  const toggleLabels = () => {
    const newValue = !showLabels
    setShowLabels(newValue)
    sendMessageToWebView({
      type: "toggleLabels",
      show: newValue,
    })
  }

  const flyToLocation = (location) => {
    sendMessageToWebView({
      type: "flyTo",
      latitude: location.latitude,
      longitude: location.longitude,
    })
  }

  const startNavigation = () => {
    if (selectedPOI) {
      navigation.navigate("RealTimeNavigation", {
        destination: {
          latitude: selectedPOI.latitude,
          longitude: selectedPOI.longitude,
          name: selectedPOI.name,
        },
      })
    }
  }

  // HTML content for the WebView with CesiumJS
  const cesiumHtml = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <title>3D Map</title>
      <script src="https://cesium.com/downloads/cesiumjs/releases/1.95/Build/Cesium/Cesium.js"></script>
      <link href="https://cesium.com/downloads/cesiumjs/releases/1.95/Build/Cesium/Widgets/widgets.css" rel="stylesheet">
      <style>
        html, body, #cesiumContainer {
          width: 100%;
          height: 100%;
          margin: 0;
          padding: 0;
          overflow: hidden;
        }
      </style>
    </head>
    <body>
      <div id="cesiumContainer"></div>
      <script>
        // Your Cesium ion access token
        Cesium.Ion.defaultAccessToken = 'YOUR_CESIUM_ION_TOKEN';
        
        // Initialize the Cesium Viewer
        const viewer = new Cesium.Viewer('cesiumContainer', {
          terrainProvider: Cesium.createWorldTerrain(),
          animation: false,
          baseLayerPicker: false,
          fullscreenButton: false,
          geocoder: false,
          homeButton: false,
          infoBox: false,
          sceneModePicker: false,
          selectionIndicator: false,
          timeline: false,
          navigationHelpButton: false,
          navigationInstructionsInitiallyVisible: false,
        });
        
        // Enable lighting based on sun/moon positions
        viewer.scene.globe.enableLighting = true;
        
        // Enable depth testing for better 3D experience
        viewer.scene.globe.depthTestAgainstTerrain = true;
        
        // Add Cesium OSM Buildings
        const buildingsTileset = viewer.scene.primitives.add(Cesium.createOsmBuildings());
        
        // Create entity collection for POIs
        const pois = viewer.entities.add(new Cesium.EntityCollection());
        
        // Add some sample POIs
        const addPOI = (name, latitude, longitude, description, type) => {
          const poi = pois.add({
            name: name,
            position: Cesium.Cartesian3.fromDegrees(longitude, latitude),
            point: {
              pixelSize: 15,
              color: Cesium.Color.fromCssColorString(
                type === 'restaurant' ? '#FF5722' : 
                type === 'attraction' ? '#2196F3' : 
                type === 'hotel' ? '#9C27B0' : '#4CAF50'
              ),
              outlineColor: Cesium.Color.WHITE,
              outlineWidth: 2,
            },
            billboard: {
              image: type === 'restaurant' ? 'https://cdn.icon-icons.com/icons2/2104/PNG/512/restaurant_icon_129104.png' :
                     type === 'attraction' ? 'https://cdn.icon-icons.com/icons2/2104/PNG/512/attraction_icon_129045.png' :
                     type === 'hotel' ? 'https://cdn.icon-icons.com/icons2/2104/PNG/512/hotel_icon_129081.png' :
                     'https://cdn.icon-icons.com/icons2/2104/PNG/512/pin_icon_129086.png',
              width: 32,
              height: 32,
            },
            description: description,
            properties: {
              type: type,
              latitude: latitude,
              longitude: longitude,
            }
          });
          
          return poi;
        };
        
        // Add sample POIs
        addPOI('Golden Gate Bridge', 37.8199, -122.4783, 'Iconic suspension bridge', 'attraction');
        addPOI('Fisherman\'s Wharf', 37.8080, -122.4177, 'Popular waterfront area', 'attraction');
        addPOI('Alcatraz Island', 37.8270, -122.4230, 'Historic federal prison', 'attraction');
        addPOI('Waterbar Restaurant', 37.7908, -122.3889, 'Seafood restaurant with bay views', 'restaurant');
        addPOI('Fairmont Hotel', 37.7924, -122.4096, 'Luxury hotel in Nob Hill', 'hotel');
        
        // Handle clicks on entities
        viewer.selectedEntityChanged.addEventListener(function(selectedEntity) {
          if (selectedEntity && selectedEntity.properties) {
            const properties = selectedEntity.properties;
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: 'poiSelected',
              poi: {
                name: selectedEntity.name,
                latitude: properties.getValue('latitude'),
                longitude: properties.getValue('longitude'),
                type: properties.getValue('type'),
                description: selectedEntity.description
              }
            }));
          }
        });
        
        // Handle messages from React Native
        window.addEventListener('message', function(event) {
          try {
            const message = JSON.parse(event.data);
            
            switch (message.type) {
              case 'setLocation':
                // Fly to the user's location
                viewer.camera.flyTo({
                  destination: Cesium.Cartesian3.fromDegrees(
                    message.longitude,
                    message.latitude,
                    1000 // altitude in meters
                  ),
                  orientation: {
                    heading: Cesium.Math.toRadians(0),
                    pitch: Cesium.Math.toRadians(-45),
                    roll: 0.0
                  }
                });
                
                // Add a marker for the user's location
                viewer.entities.add({
                  name: 'User Location',
                  position: Cesium.Cartesian3.fromDegrees(message.longitude, message.latitude),
                  billboard: {
                    image: 'https://cdn.icon-icons.com/icons2/2104/PNG/512/location_icon_129083.png',
                    width: 32,
                    height: 32,
                  }
                });
                break;
                
              case 'setViewMode':
                if (message.mode === '3d') {
                  viewer.scene.morphTo3D();
                } else if (message.mode === 'satellite') {
                  viewer.scene.morphTo2D();
                  viewer.imageryLayers.addImageryProvider(
                    new Cesium.IonImageryProvider({ assetId: 3 })
                  );
                } else if (message.mode === 'street') {
                  viewer.scene.morphTo2D();
                  viewer.imageryLayers.addImageryProvider(
                    new Cesium.OpenStreetMapImageryProvider()
                  );
                }
                break;
                
              case 'setTilt':
                viewer.camera.setView({
                  pitch: Cesium.Math.toRadians(message.tilt)
                });
                break;
                
              case 'setZoom':
                // Adjust camera height based on zoom level
                const currentPosition = viewer.camera.positionCartographic;
                viewer.camera.flyTo({
                  destination: Cesium.Cartesian3.fromRadians(
                    currentPosition.longitude,
                    currentPosition.latitude,
                    30000 / message.zoom
                  )
                });
                break;
                
              case 'toggleBuildings':
                buildingsTileset.show = message.show;
                break;
                
              case 'toggleTerrain':
                if (message.show) {
                  viewer.terrainProvider = Cesium.createWorldTerrain();
                } else {
                  viewer.terrainProvider = new Cesium.EllipsoidTerrainProvider();
                }
                break;
                
              case 'toggleLabels':
                viewer.scene.globe.showGroundAtmosphere = message.show;
                break;
                
              case 'flyTo':
                viewer.camera.flyTo({
                  destination: Cesium.Cartesian3.fromDegrees(
                    message.longitude,
                    message.latitude,
                    1000
                  ),
                  orientation: {
                    heading: Cesium.Math.toRadians(0),
                    pitch: Cesium.Math.toRadians(-45),
                    roll: 0.0
                  }
                });
                break;
            }
          } catch (error) {
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: 'error',
              error: error.message
            }));
          }
        });
        
        // Notify React Native when the map is loaded
        viewer.scene.globe.tileLoadProgressEvent.addEventListener(function(progress) {
          if (progress === 0) {
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: 'mapLoaded'
            }));
          }
        });
      </script>
    </body>
    </html>
  `

  return (
    <SafeAreaView style={styles.container}>
      <WebView
        ref={webViewRef}
        source={{ html: cesiumHtml }}
        style={styles.webView}
        onMessage={handleWebViewMessage}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        renderLoading={() => (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#4CAF50" />
            <Text style={styles.loadingText}>Loading 3D Map...</Text>
          </View>
        )}
      />

      {/* Top Bar */}
      <View style={styles.topBar}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.title}>3D Map</Text>
        <TouchableOpacity style={styles.searchButton} onPress={() => navigation.navigate("Search")}>
          <Ionicons name="search" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* View Mode Controls */}
      <View style={styles.viewModeControls}>
        <TouchableOpacity
          style={[styles.viewModeButton, viewMode === "3d" && styles.activeViewModeButton]}
          onPress={() => changeViewMode("3d")}
        >
          <Ionicons name="cube" size={20} color={viewMode === "3d" ? "#4CAF50" : "#fff"} />
          <Text style={[styles.viewModeText, viewMode === "3d" && styles.activeViewModeText]}>3D</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.viewModeButton, viewMode === "satellite" && styles.activeViewModeButton]}
          onPress={() => changeViewMode("satellite")}
        >
          <Ionicons name="earth" size={20} color={viewMode === "satellite" ? "#4CAF50" : "#fff"} />
          <Text style={[styles.viewModeText, viewMode === "satellite" && styles.activeViewModeText]}>Satellite</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.viewModeButton, viewMode === "street" && styles.activeViewModeButton]}
          onPress={() => changeViewMode("street")}
        >
          <Ionicons name="map" size={20} color={viewMode === "street" ? "#4CAF50" : "#fff"} />
          <Text style={[styles.viewModeText, viewMode === "street" && styles.activeViewModeText]}>Street</Text>
        </TouchableOpacity>
      </View>

      {/* Map Controls */}
      <View style={styles.mapControls}>
        <TouchableOpacity style={styles.mapControlButton} onPress={() => changeZoom(zoom + 1)}>
          <Ionicons name="add" size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.mapControlButton} onPress={() => changeZoom(zoom - 1)}>
          <Ionicons name="remove" size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.mapControlButton, showBuildings && styles.activeMapControlButton]}
          onPress={toggleBuildings}
        >
          <Ionicons name="business" size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.mapControlButton, showTerrain && styles.activeMapControlButton]}
          onPress={toggleTerrain}
        >
          <Ionicons name="landscape" size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.mapControlButton, showLabels && styles.activeMapControlButton]}
          onPress={toggleLabels}
        >
          <Ionicons name="text" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Tilt Controls */}
      <View style={styles.tiltControls}>
        <TouchableOpacity style={styles.tiltButton} onPress={() => changeTilt(0)}>
          <Ionicons name="compass" size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.tiltButton} onPress={() => changeTilt(45)}>
          <Ionicons name="compass" size={24} color="#fff" style={{ transform: [{ rotate: "45deg" }] }} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.tiltButton} onPress={() => changeTilt(90)}>
          <Ionicons name="compass" size={24} color="#fff" style={{ transform: [{ rotate: "90deg" }] }} />
        </TouchableOpacity>
      </View>

      {/* POI Info Card */}
      {selectedPOI && (
        <View style={styles.poiCard}>
          <View style={styles.poiHeader}>
            <Text style={styles.poiName}>{selectedPOI.name}</Text>
            <TouchableOpacity onPress={() => setSelectedPOI(null)}>
              <Ionicons name="close" size={24} color="#757575" />
            </TouchableOpacity>
          </View>
          <Text style={styles.poiDescription}>{selectedPOI.description}</Text>
          <Text style={styles.poiType}>{selectedPOI.type.charAt(0).toUpperCase() + selectedPOI.type.slice(1)}</Text>
          <View style={styles.poiActions}>
            <TouchableOpacity style={styles.poiButton} onPress={startNavigation}>
              <Ionicons name="navigate" size={20} color="#fff" />
              <Text style={styles.poiButtonText}>Navigate</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.poiButton, styles.poiButtonSecondary]}>
              <Ionicons name="information-circle" size={20} color="#4CAF50" />
              <Text style={styles.poiButtonTextSecondary}>Details</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Loading Overlay */}
      {isLoading && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color="#4CAF50" />
          <Text style={styles.loadingText}>Loading 3D Map...</Text>
        </View>
      )}
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
  },
  webView: {
    flex: 1,
  },
  loadingContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#000",
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.7)",
  },
  loadingText: {
    color: "#fff",
    marginTop: 16,
    fontSize: 16,
  },
  topBar: {
    position: "absolute",
    top: Platform.OS === "ios" ? 50 : 30,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
    textShadowColor: "rgba(0, 0, 0, 0.75)",
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  searchButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  viewModeControls: {
    position: "absolute",
    top: Platform.OS === "ios" ? 100 : 80,
    left: 16,
    right: 16,
    flexDirection: "row",
    justifyContent: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    borderRadius: 20,
    padding: 4,
  },
  viewModeButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 16,
  },
  activeViewModeButton: {
    backgroundColor: "rgba(255, 255, 255, 0.2)",
  },
  viewModeText: {
    color: "#fff",
    marginLeft: 4,
    fontSize: 14,
  },
  activeViewModeText: {
    color: "#4CAF50",
    fontWeight: "bold",
  },
  mapControls: {
    position: "absolute",
    right: 16,
    top: Platform.OS === "ios" ? 150 : 130,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    borderRadius: 20,
    padding: 8,
  },
  mapControlButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 8,
  },
  activeMapControlButton: {
    backgroundColor: "rgba(76, 175, 80, 0.3)",
  },
  tiltControls: {
    position: "absolute",
    left: 16,
    top: Platform.OS === "ios" ? 150 : 130,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    borderRadius: 20,
    padding: 8,
  },
  tiltButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 8,
  },
  poiCard: {
    position: "absolute",
    bottom: 24,
    left: 16,
    right: 16,
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 16,
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  poiHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  poiName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  poiDescription: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 8,
  },
  poiType: {
    fontSize: 14,
    color: "#4CAF50",
    marginBottom: 16,
  },
  poiActions: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  poiButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#4CAF50",
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 16,
    flex: 1,
    marginHorizontal: 4,
  },
  poiButtonSecondary: {
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#4CAF50",
  },
  poiButtonText: {
    color: "#fff",
    marginLeft: 8,
    fontWeight: "600",
  },
  poiButtonTextSecondary: {
    color: "#4CAF50",
    marginLeft: 8,
    fontWeight: "600",
  },
})

export default Map3DScreen
