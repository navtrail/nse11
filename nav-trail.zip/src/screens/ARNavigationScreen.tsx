"use client"

import { useState, useEffect } from "react"
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Dimensions, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { Camera } from "expo-camera"
import * as Location from "expo-location"
import { Magnetometer } from "expo-sensors"

const { width, height } = Dimensions.get("window")

const ARNavigationScreen = ({ navigation, route }) => {
  const [hasPermission, setHasPermission] = useState(null)
  const [cameraRef, setCameraRef] = useState(null)
  const [isRecording, setIsRecording] = useState(false)
  const [compassHeading, setCompassHeading] = useState(0)
  const [userLocation, setUserLocation] = useState(null)
  const [arElements, setArElements] = useState([])
  const [showInfo, setShowInfo] = useState(true)
  const [zoomLevel, setZoomLevel] = useState(0)
  const [flashMode, setFlashMode] = useState(Camera.Constants.FlashMode.off)

  // Mock trail waypoints
  const trailWaypoints = [
    { id: 1, name: "Trailhead", distance: 0, bearing: 45 },
    { id: 2, name: "Creek Crossing", distance: 0.8, bearing: 90 },
    { id: 3, name: "Viewpoint", distance: 1.5, bearing: 180 },
    { id: 4, name: "Summit", distance: 2.3, bearing: 270 },
  ]

  // Mock points of interest
  const pointsOfInterest = [
    { id: 1, name: "Waterfall", distance: 0.5, bearing: 60, type: "natural" },
    { id: 2, name: "Historic Cabin", distance: 1.2, bearing: 120, type: "historical" },
    { id: 3, name: "Wildlife Viewing Area", distance: 1.8, bearing: 210, type: "wildlife" },
  ]

  useEffect(() => {
    ;(async () => {
      // Request camera and location permissions
      const { status: cameraStatus } = await Camera.requestPermissionsAsync()
      const { status: locationStatus } = await Location.requestPermissionsAsync()

      setHasPermission(cameraStatus === "granted" && locationStatus === "granted")

      if (cameraStatus !== "granted" || locationStatus !== "granted") {
        Alert.alert("Permission Required", "Camera and location access are required for AR navigation", [
          { text: "OK", onPress: () => navigation.goBack() },
        ])
        return
      }

      // Start location tracking
      const locationSubscription = Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.BestForNavigation,
          distanceInterval: 5,
        },
        (location) => {
          setUserLocation(location.coords)
          updateARElements(location.coords, compassHeading)
        },
      )

      // Start compass tracking
      const magnetometerSubscription = Magnetometer.addListener((data) => {
        const angle = Math.atan2(data.y, data.x) * (180 / Math.PI)
        const heading = (angle + 360) % 360
        setCompassHeading(heading)
        if (userLocation) {
          updateARElements(userLocation, heading)
        }
      })

      return () => {
        locationSubscription.then((sub) => sub.remove())
        magnetometerSubscription.remove()
      }
    })()
  }, [])

  const updateARElements = (location, heading) => {
    // In a real app, this would calculate actual positions based on GPS and compass
    // For this mock, we'll just place elements at fixed positions in the camera view

    // Combine waypoints and POIs
    const allPoints = [...trailWaypoints.map((wp) => ({ ...wp, type: "waypoint" })), ...pointsOfInterest]

    // Calculate screen positions based on bearing relative to compass heading
    const elements = allPoints.map((point) => {
      // Calculate relative angle
      const relativeBearing = (point.bearing - heading + 360) % 360

      // Only show points that are in front of the user (within 120 degree field of view)
      const isVisible = relativeBearing < 60 || relativeBearing > 300

      // Calculate horizontal position
      let xPosition
      if (relativeBearing < 60) {
        // Right side of screen
        xPosition = width * (0.5 + relativeBearing / 120)
      } else {
        // Left side of screen
        xPosition = (width * (relativeBearing - 300)) / 120
      }

      // Calculate vertical position (higher for closer objects)
      const yPosition = height * 0.4 - (1 / point.distance) * 50

      return {
        ...point,
        isVisible,
        position: { x: xPosition, y: yPosition },
      }
    })

    setArElements(elements)
  }

  const toggleFlash = () => {
    setFlashMode(
      flashMode === Camera.Constants.FlashMode.off ? Camera.Constants.FlashMode.torch : Camera.Constants.FlashMode.off,
    )
  }

  const toggleZoom = () => {
    // Cycle through zoom levels: 0, 0.5, 1
    setZoomLevel((zoomLevel + 0.5) % 1.5)
  }

  const renderARElements = () => {
    return arElements
      .filter((element) => element.isVisible)
      .map((element) => (
        <View
          key={`${element.type}-${element.id}`}
          style={[
            styles.arElement,
            {
              left: element.position.x,
              top: element.position.y,
              backgroundColor: getElementColor(element.type),
            },
          ]}
        >
          <Text style={styles.arElementText}>{element.name}</Text>
          <Text style={styles.arElementDistance}>{element.distance} km</Text>
        </View>
      ))
  }

  const getElementColor = (type) => {
    switch (type) {
      case "waypoint":
        return "rgba(76, 175, 80, 0.8)" // Green
      case "natural":
        return "rgba(33, 150, 243, 0.8)" // Blue
      case "historical":
        return "rgba(255, 152, 0, 0.8)" // Orange
      case "wildlife":
        return "rgba(156, 39, 176, 0.8)" // Purple
      default:
        return "rgba(158, 158, 158, 0.8)" // Grey
    }
  }

  if (hasPermission === null) {
    return <View style={styles.container} />
  }

  if (hasPermission === false) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.permissionContainer}>
          <Ionicons name="alert-circle-outline" size={64} color="#F44336" />
          <Text style={styles.permissionText}>Camera and location access are required</Text>
          <TouchableOpacity style={styles.permissionButton} onPress={() => navigation.goBack()}>
            <Text style={styles.permissionButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    )
  }

  return (
    <View style={styles.container}>
      <Camera
        ref={(ref) => setCameraRef(ref)}
        style={styles.camera}
        type={Camera.Constants.Type.back}
        flashMode={flashMode}
        zoom={zoomLevel}
      >
        <SafeAreaView style={styles.overlay}>
          {/* AR Elements */}
          {renderARElements()}

          {/* Compass */}
          <View style={styles.compass}>
            <Ionicons name="navigate" size={24} color="#fff" />
            <Text style={styles.compassText}>{Math.round(compassHeading)}°</Text>
          </View>

          {/* Info Panel */}
          {showInfo && (
            <View style={styles.infoPanel}>
              <View style={styles.infoHeader}>
                <Text style={styles.infoTitle}>Eagle Peak Trail</Text>
                <TouchableOpacity onPress={() => setShowInfo(false)}>
                  <Ionicons name="close" size={24} color="#fff" />
                </TouchableOpacity>
              </View>
              <View style={styles.infoContent}>
                <View style={styles.infoItem}>
                  <Ionicons name="location" size={20} color="#4CAF50" />
                  <Text style={styles.infoText}>Next: Viewpoint (1.5 km)</Text>
                </View>
                <View style={styles.infoItem}>
                  <Ionicons name="time" size={20} color="#4CAF50" />
                  <Text style={styles.infoText}>ETA: 25 min</Text>
                </View>
                <View style={styles.infoItem}>
                  <Ionicons name="trending-up" size={20} color="#4CAF50" />
                  <Text style={styles.infoText}>Elevation: 320m</Text>
                </View>
              </View>
            </View>
          )}

          {/* Controls */}
          <View style={styles.controls}>
            <TouchableOpacity style={styles.controlButton} onPress={() => navigation.goBack()}>
              <Ionicons name="close" size={28} color="#fff" />
            </TouchableOpacity>

            <View style={styles.controlsRight}>
              <TouchableOpacity style={styles.controlButton} onPress={toggleFlash}>
                <Ionicons
                  name={flashMode === Camera.Constants.FlashMode.off ? "flash-off" : "flash"}
                  size={28}
                  color="#fff"
                />
              </TouchableOpacity>

              <TouchableOpacity style={styles.controlButton} onPress={toggleZoom}>
                <Ionicons name="search" size={28} color="#fff" />
                <Text style={styles.zoomText}>{zoomLevel === 0 ? "1x" : zoomLevel === 0.5 ? "2x" : "4x"}</Text>
              </TouchableOpacity>

              {!showInfo && (
                <TouchableOpacity style={styles.controlButton} onPress={() => setShowInfo(true)}>
                  <Ionicons name="information-circle" size={28} color="#fff" />
                </TouchableOpacity>
              )}
            </View>
          </View>

          {/* Legend */}
          <View style={styles.legend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: "rgba(76, 175, 80, 0.8)" }]} />
              <Text style={styles.legendText}>Trail Waypoints</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: "rgba(33, 150, 243, 0.8)" }]} />
              <Text style={styles.legendText}>Natural Features</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: "rgba(255, 152, 0, 0.8)" }]} />
              <Text style={styles.legendText}>Historical Sites</Text>
            </View>
          </View>
        </SafeAreaView>
      </Camera>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
  },
  camera: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    position: "relative",
  },
  arElement: {
    position: "absolute",
    padding: 8,
    borderRadius: 8,
    alignItems: "center",
  },
  arElementText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 14,
    textShadowColor: "rgba(0, 0, 0, 0.75)",
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  arElementDistance: {
    color: "#fff",
    fontSize: 12,
    textShadowColor: "rgba(0, 0, 0, 0.75)",
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  compass: {
    position: "absolute",
    top: 16,
    right: 16,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    borderRadius: 20,
    padding: 8,
    flexDirection: "row",
    alignItems: "center",
  },
  compassText: {
    color: "#fff",
    marginLeft: 4,
    fontWeight: "bold",
  },
  infoPanel: {
    position: "absolute",
    top: 60,
    left: 16,
    right: 16,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    borderRadius: 12,
    padding: 12,
  },
  infoHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  infoTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  infoContent: {
    gap: 8,
  },
  infoItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  infoText: {
    color: "#fff",
    fontSize: 14,
  },
  controls: {
    position: "absolute",
    bottom: 24,
    left: 16,
    right: 16,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  controlsRight: {
    flexDirection: "row",
    gap: 16,
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  zoomText: {
    color: "#fff",
    fontSize: 10,
    position: "absolute",
    bottom: 8,
  },
  legend: {
    position: "absolute",
    bottom: 90,
    left: 16,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    borderRadius: 8,
    padding: 8,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4,
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  legendText: {
    color: "#fff",
    fontSize: 12,
  },
  permissionContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  permissionText: {
    fontSize: 18,
    color: "#212121",
    textAlign: "center",
    marginTop: 16,
    marginBottom: 24,
  },
  permissionButton: {
    backgroundColor: "#4CAF50",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
  },
  permissionButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
})

export default ARNavigationScreen
