"use client"

import { useState } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  ActivityIndicator,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { useAuth } from "../context/AuthContext"
import BottomTabBar from "../components/BottomTabBar"

const ProfileScreen = ({ navigation }) => {
  const { user, logout, updateProfile } = useAuth()
  const [isLoading, setIsLoading] = useState(false)

  const handleLogout = async () => {
    try {
      setIsLoading(true)
      await logout()
      // Navigation will be handled by the AuthContext
    } catch (error) {
      Alert.alert("Error", "Failed to log out. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const confirmLogout = () => {
    Alert.alert("Log Out", "Are you sure you want to log out?", [
      { text: "Cancel", style: "cancel" },
      { text: "Log Out", onPress: handleLogout, style: "destructive" },
    ])
  }

  const stats = [
    { label: "Trails Completed", value: 24 },
    { label: "Total Distance", value: "156 km" },
    { label: "Elevation Gain", value: "4,320 m" },
    { label: "Hours Active", value: "48.5" },
  ]

  const achievements = [
    { id: 1, title: "Early Bird", description: "Complete 5 trails before 8 AM", icon: "sunrise", completed: true },
    { id: 2, title: "Mountain Goat", description: "Climb 5,000m in elevation", icon: "trending-up", completed: true },
    { id: 3, title: "Explorer", description: "Visit 10 different trail regions", icon: "compass", completed: false },
    { id: 4, title: "Photographer", description: "Share 20 trail photos", icon: "camera", completed: false },
  ]

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Profile</Text>
        <TouchableOpacity style={styles.settingsButton} onPress={() => navigation.navigate("Settings")}>
          <Ionicons name="settings-outline" size={24} color="#212121" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        <View style={styles.profileSection}>
          <Image source={{ uri: user?.photoURL }} style={styles.profileImage} />
          <Text style={styles.profileName}>{user?.displayName}</Text>
          <Text style={styles.profileEmail}>{user?.email}</Text>
          <TouchableOpacity style={styles.editProfileButton}>
            <Text style={styles.editProfileText}>Edit Profile</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.statsContainer}>
          {stats.map((stat, index) => (
            <View key={index} style={styles.statItem}>
              <Text style={styles.statValue}>{stat.value}</Text>
              <Text style={styles.statLabel}>{stat.label}</Text>
            </View>
          ))}
        </View>

        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Achievements</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.achievementsContainer}>
            {achievements.map((achievement) => (
              <View key={achievement.id} style={styles.achievementItem}>
                <View style={[styles.achievementIcon, !achievement.completed && styles.achievementIconLocked]}>
                  <Ionicons name={achievement.icon} size={24} color={achievement.completed ? "#fff" : "#9E9E9E"} />
                </View>
                <View style={styles.achievementInfo}>
                  <Text style={styles.achievementTitle}>{achievement.title}</Text>
                  <Text style={styles.achievementDescription}>{achievement.description}</Text>
                </View>
                {achievement.completed ? (
                  <Ionicons name="checkmark-circle" size={24} color="#4CAF50" />
                ) : (
                  <Ionicons name="lock-closed" size={24} color="#9E9E9E" />
                )}
              </View>
            ))}
          </View>
        </View>

        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Trails</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.trailsContainer}>
            <TouchableOpacity style={styles.trailItem}>
              <Image
                source={{
                  uri: "https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
                }}
                style={styles.trailImage}
              />
              <View style={styles.trailInfo}>
                <Text style={styles.trailName}>Eagle Peak Trail</Text>
                <Text style={styles.trailDetails}>8.2 km • Moderate</Text>
                <Text style={styles.trailDate}>Hiked on May 15, 2023</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.trailItem}>
              <Image
                source={{
                  uri: "https://images.unsplash.com/photo-1552521684-edc2a078660e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
                }}
                style={styles.trailImage}
              />
              <View style={styles.trailInfo}>
                <Text style={styles.trailName}>Redwood Forest Loop</Text>
                <Text style={styles.trailDetails}>5.4 km • Easy</Text>
                <Text style={styles.trailDate}>Hiked on April 30, 2023</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity style={styles.logoutButton} onPress={confirmLogout} disabled={isLoading}>
          {isLoading ? (
            <ActivityIndicator color="#F44336" />
          ) : (
            <>
              <Ionicons name="log-out-outline" size={20} color="#F44336" />
              <Text style={styles.logoutText}>Log Out</Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>

      <BottomTabBar
        activeTab="Profile"
        onTabPress={(tab) => {
          if (tab !== "Profile") {
            navigation.navigate(tab)
          }
        }}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
    position: "relative",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  settingsButton: {
    position: "absolute",
    right: 16,
    padding: 8,
  },
  content: {
    flex: 1,
  },
  profileSection: {
    alignItems: "center",
    paddingVertical: 24,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  profileName: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 16,
    color: "#757575",
    marginBottom: 16,
  },
  editProfileButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "#4CAF50",
  },
  editProfileText: {
    color: "#4CAF50",
    fontWeight: "600",
  },
  statsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  statItem: {
    width: "50%",
    alignItems: "center",
    marginBottom: 16,
  },
  statValue: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: "#757575",
  },
  sectionContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  seeAllText: {
    color: "#4CAF50",
    fontWeight: "600",
  },
  achievementsContainer: {
    gap: 12,
  },
  achievementItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    padding: 12,
  },
  achievementIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: "#4CAF50",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  achievementIconLocked: {
    backgroundColor: "#E0E0E0",
  },
  achievementInfo: {
    flex: 1,
  },
  achievementTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  achievementDescription: {
    fontSize: 14,
    color: "#757575",
  },
  trailsContainer: {
    gap: 16,
  },
  trailItem: {
    flexDirection: "row",
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    overflow: "hidden",
  },
  trailImage: {
    width: 100,
    height: 100,
  },
  trailInfo: {
    flex: 1,
    padding: 12,
    justifyContent: "center",
  },
  trailName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  trailDetails: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 4,
  },
  trailDate: {
    fontSize: 12,
    color: "#9E9E9E",
  },
  logoutButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginVertical: 24,
    marginHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#F44336",
  },
  logoutText: {
    color: "#F44336",
    fontWeight: "600",
    marginLeft: 8,
  },
})

export default ProfileScreen
