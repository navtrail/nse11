"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
  StatusBar,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { useAuth } from "../context/AuthContext"

const { width } = Dimensions.get("window")

const HomeScreen = ({ navigation }) => {
  const { user } = useAuth()
  const [recentTrips, setRecentTrips] = useState([])
  const [nearbyTrails, setNearbyTrails] = useState([])
  const [weatherInfo, setWeatherInfo] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading data
    const loadData = async () => {
      setIsLoading(true)
      try {
        // In a real app, these would be API calls
        await new Promise((resolve) => setTimeout(resolve, 1000))

        setRecentTrips([
          {
            id: "1",
            name: "Yosemite Weekend",
            image: "https://images.unsplash.com/photo-1472396961693-142e6e269027",
            date: "2 days ago",
          },
          {
            id: "2",
            name: "San Francisco Trip",
            image: "https://images.unsplash.com/photo-1501594907352-04cda38ebc29",
            date: "Last week",
          },
        ])

        setNearbyTrails([
          {
            id: "1",
            name: "Eagle Peak Trail",
            distance: "8.2 km",
            difficulty: "Moderate",
            image: "https://images.unsplash.com/photo-1551632811-561732d1e306",
          },
          {
            id: "2",
            name: "Coastal Bluff Trail",
            distance: "6.3 km",
            difficulty: "Easy",
            image: "https://images.unsplash.com/photo-1472396961693-142e6e269027",
          },
          {
            id: "3",
            name: "Redwood Forest Loop",
            distance: "5.4 km",
            difficulty: "Easy",
            image: "https://images.unsplash.com/photo-1552521684-edc2a078660e",
          },
        ])

        setWeatherInfo({
          temperature: 22,
          condition: "Sunny",
          forecast: [
            { day: "Today", temp: 22, condition: "sunny" },
            { day: "Tue", temp: 24, condition: "partly-cloudy" },
            { day: "Wed", temp: 21, condition: "cloudy" },
          ],
        })
      } catch (error) {
        console.error("Error loading data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  const renderFeatureButton = (icon, title, screen, params = {}) => (
    <TouchableOpacity style={styles.featureButton} onPress={() => navigation.navigate(screen, params)}>
      <View style={styles.featureIconContainer}>
        <Ionicons name={icon} size={24} color="#4CAF50" />
      </View>
      <Text style={styles.featureButtonText}>{title}</Text>
    </TouchableOpacity>
  )

  const getWeatherIcon = (condition) => {
    switch (condition) {
      case "sunny":
        return "sunny"
      case "partly-cloudy":
        return "partly-sunny"
      case "cloudy":
        return "cloudy"
      case "rainy":
        return "rainy"
      default:
        return "help-circle"
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />

      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Hello, {user?.displayName || "Explorer"}</Text>
          <Text style={styles.subGreeting}>Ready for your next adventure?</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate("Profile")}>
          <Image source={{ uri: user?.photoURL || "https://via.placeholder.com/40" }} style={styles.profileImage} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {weatherInfo && (
          <View style={styles.weatherCard}>
            <View style={styles.currentWeather}>
              <Ionicons name={getWeatherIcon(weatherInfo.condition)} size={36} color="#FFC107" />
              <Text style={styles.temperature}>{weatherInfo.temperature}°C</Text>
              <Text style={styles.weatherCondition}>{weatherInfo.condition}</Text>
            </View>
            <View style={styles.weatherForecast}>
              {weatherInfo.forecast.map((day, index) => (
                <View key={index} style={styles.forecastDay}>
                  <Text style={styles.forecastDayText}>{day.day}</Text>
                  <Ionicons name={getWeatherIcon(day.condition)} size={20} color="#757575" />
                  <Text style={styles.forecastTemp}>{day.temp}°</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        <Text style={styles.sectionTitle}>Plan Your Trip</Text>
        <View style={styles.featureGrid}>
          {renderFeatureButton("map", "Explore Map", "Map")}
          {renderFeatureButton("search", "Search", "Search")}
          {renderFeatureButton("document-text", "Itinerary Builder", "ItineraryBuilder")}
          {renderFeatureButton("list", "Trip Lists", "TripLists")}
          {renderFeatureButton("navigate", "Real-time Navigation", "RealTimeNavigation")}
          {renderFeatureButton("cube", "Map 3D View", "Map3D")}
          {renderFeatureButton("glasses", "AR Navigation", "ARNavigation")}
          {renderFeatureButton("cloud-download", "Offline Maps", "OfflineMaps")}
          {renderFeatureButton("sparkles", "AI Trip Planner", "AIPlanner")}
          {renderFeatureButton("restaurant", "Food Discovery", "FoodDiscovery")}
          {renderFeatureButton("analytics", "Data Explorer", "DataExplorer")}
          {renderFeatureButton("bar-chart", "Data Insights", "DataVisualization")}
        </View>

        {recentTrips.length > 0 && (
          <>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Recent Trips</Text>
              <TouchableOpacity onPress={() => navigation.navigate("TripLists")}>
                <Text style={styles.seeAllText}>See All</Text>
              </TouchableOpacity>
            </View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.recentTripsContainer}>
              {recentTrips.map((trip) => (
                <TouchableOpacity
                  key={trip.id}
                  style={styles.tripCard}
                  onPress={() => navigation.navigate("ItineraryBuilder", { tripId: trip.id })}
                >
                  <Image source={{ uri: trip.image }} style={styles.tripImage} />
                  <View style={styles.tripInfo}>
                    <Text style={styles.tripName}>{trip.name}</Text>
                    <Text style={styles.tripDate}>{trip.date}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </>
        )}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Nearby Trails</Text>
          <TouchableOpacity onPress={() => navigation.navigate("Search")}>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>

        {nearbyTrails.map((trail) => (
          <TouchableOpacity
            key={trail.id}
            style={styles.trailCard}
            onPress={() => navigation.navigate("Map", { trailId: trail.id })}
          >
            <Image source={{ uri: trail.image }} style={styles.trailImage} />
            <View style={styles.trailInfo}>
              <Text style={styles.trailName}>{trail.name}</Text>
              <View style={styles.trailDetails}>
                <View style={styles.trailDetail}>
                  <Ionicons name="trail-sign-outline" size={16} color="#757575" />
                  <Text style={styles.trailDetailText}>{trail.distance}</Text>
                </View>
                <View style={styles.trailDetail}>
                  <Ionicons name="stats-chart-outline" size={16} color="#757575" />
                  <Text style={styles.trailDetailText}>{trail.difficulty}</Text>
                </View>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={24} color="#757575" />
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  greeting: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#212121",
  },
  subGreeting: {
    fontSize: 14,
    color: "#757575",
    marginTop: 4,
  },
  profileImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  weatherCard: {
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  currentWeather: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  temperature: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#212121",
    marginLeft: 16,
  },
  weatherCondition: {
    fontSize: 16,
    color: "#757575",
    marginLeft: 8,
  },
  weatherForecast: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  forecastDay: {
    alignItems: "center",
  },
  forecastDayText: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 4,
  },
  forecastTemp: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginTop: 4,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 16,
  },
  seeAllText: {
    fontSize: 14,
    color: "#4CAF50",
  },
  featureGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginBottom: 24,
  },
  featureButton: {
    width: (width - 48) / 3,
    alignItems: "center",
    marginBottom: 16,
  },
  featureIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: "#e8f5e9",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 8,
  },
  featureButtonText: {
    fontSize: 12,
    color: "#212121",
    textAlign: "center",
  },
  recentTripsContainer: {
    marginBottom: 24,
  },
  tripCard: {
    width: 200,
    borderRadius: 12,
    backgroundColor: "#f9f9f9",
    overflow: "hidden",
    marginRight: 16,
  },
  tripImage: {
    width: "100%",
    height: 120,
  },
  tripInfo: {
    padding: 12,
  },
  tripName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  tripDate: {
    fontSize: 14,
    color: "#757575",
  },
  trailCard: {
    flexDirection: "row",
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    marginBottom: 16,
    overflow: "hidden",
  },
  trailImage: {
    width: 80,
    height: 80,
  },
  trailInfo: {
    flex: 1,
    padding: 12,
  },
  trailName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 8,
  },
  trailDetails: {
    flexDirection: "row",
  },
  trailDetail: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 16,
  },
  trailDetailText: {
    fontSize: 14,
    color: "#757575",
    marginLeft: 4,
  },
})

export default HomeScreen
