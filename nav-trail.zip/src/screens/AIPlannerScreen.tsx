"use client"

import { useState, useEffect, useRef } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Image,
  ActivityIndicator,
  Animated,
  FlatList,
  Alert,
  Platform,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import DraggableFlatList from "react-native-draggable-flatlist"
import DateTimePicker from "@react-native-community/datetimepicker"
import { generateTripPlan, getWeatherForecast, getTravelPackages } from "../services/ai"

const AIPlannerScreen = ({ navigation, route }) => {
  const [destination, setDestination] = useState("")
  const [startDate, setStartDate] = useState(new Date())
  const [endDate, setEndDate] = useState(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000))
  const [budget, setBudget] = useState("medium")
  const [interests, setInterests] = useState([])
  const [showDatePicker, setShowDatePicker] = useState(false)
  const [datePickerMode, setDatePickerMode] = useState("start")
  const [isGenerating, setIsGenerating] = useState(false)
  const [tripPlan, setTripPlan] = useState(null)
  const [weatherForecast, setWeatherForecast] = useState(null)
  const [travelPackages, setTravelPackages] = useState([])
  const [showPackages, setShowPackages] = useState(false)
  const [currentDay, setCurrentDay] = useState(0)
  const [showPromptInput, setShowPromptInput] = useState(false)
  const [customPrompt, setCustomPrompt] = useState("")

  const scrollViewRef = useRef(null)
  const fadeAnim = useRef(new Animated.Value(0)).current

  const availableInterests = [
    { id: "nature", label: "Nature", icon: "leaf" },
    { id: "history", label: "History", icon: "time" },
    { id: "food", label: "Food", icon: "restaurant" },
    { id: "adventure", label: "Adventure", icon: "compass" },
    { id: "art", label: "Art & Culture", icon: "color-palette" },
    { id: "shopping", label: "Shopping", icon: "cart" },
    { id: "nightlife", label: "Nightlife", icon: "moon" },
    { id: "relaxation", label: "Relaxation", icon: "sunny" },
    { id: "family", label: "Family", icon: "people" },
  ]

  useEffect(() => {
    if (tripPlan) {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }).start()

      // Get weather forecast for the destination
      const fetchWeather = async () => {
        try {
          const forecast = await getWeatherForecast(destination, startDate, endDate)
          setWeatherForecast(forecast)
        } catch (error) {
          console.error("Error fetching weather:", error)
        }
      }

      fetchWeather()

      // Get travel packages
      const fetchPackages = async () => {
        try {
          const packages = await getTravelPackages(destination, startDate, endDate, budget)
          setTravelPackages(packages)
        } catch (error) {
          console.error("Error fetching packages:", error)
        }
      }

      fetchPackages()
    }
  }, [tripPlan])

  const toggleInterest = (interestId) => {
    if (interests.includes(interestId)) {
      setInterests(interests.filter((id) => id !== interestId))
    } else {
      setInterests([...interests, interestId])
    }
  }

  const handleDateChange = (event, selectedDate) => {
    if (Platform.OS === "android") {
      setShowDatePicker(false)
    }

    if (selectedDate) {
      if (datePickerMode === "start") {
        setStartDate(selectedDate)
        // Ensure end date is not before start date
        if (selectedDate > endDate) {
          setEndDate(new Date(selectedDate.getTime() + 24 * 60 * 60 * 1000))
        }
      } else {
        setEndDate(selectedDate)
      }
    }
  }

  const showDatePickerModal = (mode) => {
    setDatePickerMode(mode)
    setShowDatePicker(true)
  }

  const generatePlan = async () => {
    if (!destination) {
      Alert.alert("Missing Information", "Please enter a destination")
      return
    }

    setIsGenerating(true)
    try {
      const plan = await generateTripPlan(destination, startDate, endDate, budget, interests, customPrompt)
      setTripPlan(plan)
      setCurrentDay(0)
    } catch (error) {
      Alert.alert("Error", "Failed to generate trip plan. Please try again.")
      console.error("Error generating plan:", error)
    } finally {
      setIsGenerating(false)
      setShowPromptInput(false)
    }
  }

  const regenerateDay = async (dayIndex) => {
    if (!tripPlan) return

    setIsGenerating(true)
    try {
      const updatedPlan = { ...tripPlan }
      const newDayPlan = await generateTripPlan(
        destination,
        new Date(startDate.getTime() + dayIndex * 24 * 60 * 60 * 1000),
        new Date(startDate.getTime() + dayIndex * 24 * 60 * 60 * 1000),
        budget,
        interests,
        `Regenerate only day ${dayIndex + 1} of my trip`,
      )
      updatedPlan.days[dayIndex] = newDayPlan.days[0]
      setTripPlan(updatedPlan)
    } catch (error) {
      Alert.alert("Error", "Failed to regenerate day plan. Please try again.")
      console.error("Error regenerating day:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleDragEnd = ({ data }) => {
    if (!tripPlan) return

    const updatedPlan = { ...tripPlan }
    updatedPlan.days[currentDay].activities = data
    setTripPlan(updatedPlan)
  }

  const removeActivity = (activityId) => {
    if (!tripPlan) return

    Alert.alert("Remove Activity", "Are you sure you want to remove this activity?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove",
        style: "destructive",
        onPress: () => {
          const updatedPlan = { ...tripPlan }
          updatedPlan.days[currentDay].activities = updatedPlan.days[currentDay].activities.filter(
            (activity) => activity.id !== activityId,
          )
          setTripPlan(updatedPlan)
        },
      },
    ])
  }

  const addCustomActivity = () => {
    Alert.prompt("Add Custom Activity", "Enter activity name", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Add",
        onPress: (name) => {
          if (!name) return

          Alert.prompt("Activity Time", "Enter time (e.g., 10:00 AM)", [
            { text: "Cancel", style: "cancel" },
            {
              text: "Add",
              onPress: (time) => {
                if (!time) return

                const updatedPlan = { ...tripPlan }
                const newActivity = {
                  id: `custom-${Date.now()}`,
                  name,
                  time,
                  duration: 60,
                  location: "Custom location",
                  cost: 0,
                  description: "Custom activity",
                  type: "custom",
                }
                updatedPlan.days[currentDay].activities.push(newActivity)
                setTripPlan(updatedPlan)
              },
            },
          ])
        },
      },
    ])
  }

  const viewOnMap = (activity) => {
    navigation.navigate("Map3D", {
      location: {
        latitude: activity.coordinates?.latitude || 0,
        longitude: activity.coordinates?.longitude || 0,
        name: activity.name,
      },
    })
  }

  const startNavigation = (activity) => {
    navigation.navigate("RealTimeNavigation", {
      destination: {
        latitude: activity.coordinates?.latitude || 0,
        longitude: activity.coordinates?.longitude || 0,
        name: activity.name,
      },
    })
  }

  const viewPackageDetails = (packageId) => {
    const selectedPackage = travelPackages.find((pkg) => pkg.id === packageId)
    if (selectedPackage) {
      Alert.alert(
        selectedPackage.name,
        `${selectedPackage.description}\n\nPrice: $${selectedPackage.price}\nIncludes: ${selectedPackage.includes.join(
          ", ",
        )}`,
        [
          { text: "Close", style: "cancel" },
          {
            text: "Book Now",
            onPress: () => {
              Alert.alert("Success", "Booking request sent! A confirmation email will be sent shortly.")
            },
          },
        ],
      )
    }
  }

  const renderInterestItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.interestItem, interests.includes(item.id) && styles.interestItemSelected]}
      onPress={() => toggleInterest(item.id)}
    >
      <Ionicons name={item.icon} size={24} color={interests.includes(item.id) ? "#fff" : "#757575"} />
      <Text style={[styles.interestText, interests.includes(item.id) && styles.interestTextSelected]}>
        {item.label}
      </Text>
    </TouchableOpacity>
  )

  const renderActivityItem = ({ item, drag, isActive }) => (
    <TouchableOpacity
      style={[styles.activityItem, isActive && styles.activityItemDragging]}
      onLongPress={drag}
      delayLongPress={200}
      activeOpacity={0.7}
    >
      <View style={styles.activityTimeContainer}>
        <Text style={styles.activityTime}>{item.time}</Text>
        <Text style={styles.activityDuration}>{item.duration} min</Text>
      </View>
      <View style={styles.activityContent}>
        <Text style={styles.activityName}>{item.name}</Text>
        <Text style={styles.activityLocation}>{item.location}</Text>
        <Text style={styles.activityCost}>{item.cost > 0 ? `$${item.cost}` : "Free"}</Text>
      </View>
      <View style={styles.activityActions}>
        <TouchableOpacity style={styles.activityAction} onPress={() => viewOnMap(item)}>
          <Ionicons name="map" size={20} color="#4CAF50" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.activityAction} onPress={() => startNavigation(item)}>
          <Ionicons name="navigate" size={20} color="#2196F3" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.activityAction} onPress={() => removeActivity(item.id)}>
          <Ionicons name="trash" size={20} color="#F44336" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  )

  const renderPackageItem = ({ item }) => (
    <TouchableOpacity style={styles.packageItem} onPress={() => viewPackageDetails(item.id)}>
      <Image source={{ uri: item.image }} style={styles.packageImage} />
      <View style={styles.packageContent}>
        <Text style={styles.packageName}>{item.name}</Text>
        <Text style={styles.packagePrice}>${item.price}</Text>
        <View style={styles.packageRating}>
          <Ionicons name="star" size={16} color="#FFC107" />
          <Text style={styles.packageRatingText}>
            {item.rating} ({item.reviewCount})
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  )

  const renderWeatherDay = (day, index) => (
    <View key={index} style={styles.weatherDay}>
      <Text style={styles.weatherDate}>
        {new Date(startDate.getTime() + index * 24 * 60 * 60 * 1000).toLocaleDateString([], {
          month: "short",
          day: "numeric",
        })}
      </Text>
      <Ionicons name={getWeatherIcon(day.condition)} size={24} color="#757575" />
      <Text style={styles.weatherTemp}>{day.temperature}°</Text>
    </View>
  )

  const getWeatherIcon = (condition) => {
    const icons = {
      sunny: "sunny",
      cloudy: "cloudy",
      "partly-cloudy": "partly-sunny",
      rainy: "rainy",
      stormy: "thunderstorm",
      snowy: "snow",
    }
    return icons[condition] || "help-circle"
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>AI Trip Planner</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView ref={scrollViewRef} style={styles.content} contentContainerStyle={styles.contentContainer}>
        {!tripPlan ? (
          <View style={styles.plannerForm}>
            <Text style={styles.sectionTitle}>Where do you want to go?</Text>
            <TextInput
              style={styles.destinationInput}
              placeholder="Enter destination (city, country)"
              value={destination}
              onChangeText={setDestination}
            />

            <Text style={styles.sectionTitle}>When are you traveling?</Text>
            <View style={styles.dateContainer}>
              <TouchableOpacity style={styles.dateButton} onPress={() => showDatePickerModal("start")}>
                <Ionicons name="calendar" size={20} color="#4CAF50" />
                <Text style={styles.dateText}>
                  {startDate.toLocaleDateString([], {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })}
                </Text>
              </TouchableOpacity>
              <Text style={styles.dateToText}>to</Text>
              <TouchableOpacity style={styles.dateButton} onPress={() => showDatePickerModal("end")}>
                <Ionicons name="calendar" size={20} color="#4CAF50" />
                <Text style={styles.dateText}>
                  {endDate.toLocaleDateString([], {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })}
                </Text>
              </TouchableOpacity>
            </View>

            {showDatePicker && (
              <DateTimePicker
                value={datePickerMode === "start" ? startDate : endDate}
                mode="date"
                display={Platform.OS === "ios" ? "spinner" : "default"}
                onChange={handleDateChange}
                minimumDate={datePickerMode === "start" ? new Date() : startDate}
              />
            )}

            <Text style={styles.sectionTitle}>What's your budget?</Text>
            <View style={styles.budgetContainer}>
              <TouchableOpacity
                style={[styles.budgetButton, budget === "budget" && styles.budgetButtonSelected]}
                onPress={() => setBudget("budget")}
              >
                <Text style={[styles.budgetText, budget === "budget" && styles.budgetTextSelected]}>Budget</Text>
                <Text style={[styles.budgetSubtext, budget === "budget" && styles.budgetSubtextSelected]}>$</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.budgetButton, budget === "medium" && styles.budgetButtonSelected]}
                onPress={() => setBudget("medium")}
              >
                <Text style={[styles.budgetText, budget === "medium" && styles.budgetTextSelected]}>Medium</Text>
                <Text style={[styles.budgetSubtext, budget === "medium" && styles.budgetSubtextSelected]}>$$</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.budgetButton, budget === "luxury" && styles.budgetButtonSelected]}
                onPress={() => setBudget("luxury")}
              >
                <Text style={[styles.budgetText, budget === "luxury" && styles.budgetTextSelected]}>Luxury</Text>
                <Text style={[styles.budgetSubtext, budget === "luxury" && styles.budgetSubtextSelected]}>$$$</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.sectionTitle}>What are your interests?</Text>
            <FlatList
              data={availableInterests}
              renderItem={renderInterestItem}
              keyExtractor={(item) => item.id}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.interestsList}
            />

            <View style={styles.advancedOptions}>
              <TouchableOpacity style={styles.advancedButton} onPress={() => setShowPromptInput(!showPromptInput)}>
                <Ionicons name={showPromptInput ? "chevron-up" : "chevron-down"} size={20} color="#4CAF50" />
                <Text style={styles.advancedButtonText}>Advanced Options</Text>
              </TouchableOpacity>

              {showPromptInput && (
                <TextInput
                  style={styles.promptInput}
                  placeholder="Add specific requirements (e.g., 'Include a museum visit on day 2')"
                  value={customPrompt}
                  onChangeText={setCustomPrompt}
                  multiline
                />
              )}
            </View>

            <TouchableOpacity style={styles.generateButton} onPress={generatePlan} disabled={isGenerating}>
              {isGenerating ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="sparkles" size={20} color="#fff" />
                  <Text style={styles.generateButtonText}>Generate AI Trip Plan</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        ) : (
          <Animated.View style={[styles.tripPlanContainer, { opacity: fadeAnim }]}>
            <View style={styles.tripHeader}>
              <View>
                <Text style={styles.tripDestination}>{destination}</Text>
                <Text style={styles.tripDates}>
                  {startDate.toLocaleDateString([], {
                    month: "short",
                    day: "numeric",
                  })}{" "}
                  -{" "}
                  {endDate.toLocaleDateString([], {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })}
                </Text>
              </View>
              <TouchableOpacity
                style={styles.editButton}
                onPress={() => {
                  setTripPlan(null)
                  fadeAnim.setValue(0)
                }}
              >
                <Ionicons name="create" size={20} color="#4CAF50" />
              </TouchableOpacity>
            </View>

            {weatherForecast && (
              <View style={styles.weatherContainer}>
                <Text style={styles.weatherTitle}>Weather Forecast</Text>
                <View style={styles.weatherDays}>
                  {weatherForecast.days.map((day, index) => renderWeatherDay(day, index))}
                </View>
              </View>
            )}

            <View style={styles.tripSummary}>
              <View style={styles.summaryItem}>
                <Ionicons name="calendar" size={20} color="#4CAF50" />
                <Text style={styles.summaryText}>{tripPlan.days.length} Days</Text>
              </View>
              <View style={styles.summaryItem}>
                <Ionicons name="cash" size={20} color="#4CAF50" />
                <Text style={styles.summaryText}>${tripPlan.totalCost}</Text>
              </View>
              <View style={styles.summaryItem}>
                <Ionicons name="map" size={20} color="#4CAF50" />
                <Text style={styles.summaryText}>{tripPlan.totalActivities} Activities</Text>
              </View>
            </View>

            <View style={styles.daySelector}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {tripPlan.days.map((day, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[styles.dayButton, currentDay === index && styles.dayButtonSelected]}
                    onPress={() => setCurrentDay(index)}
                  >
                    <Text style={[styles.dayButtonText, currentDay === index && styles.dayButtonTextSelected]}>
                      Day {index + 1}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>

            <View style={styles.dayPlanHeader}>
              <Text style={styles.dayPlanTitle}>
                Day {currentDay + 1}: {tripPlan.days[currentDay].title}
              </Text>
              <TouchableOpacity style={styles.regenerateButton} onPress={() => regenerateDay(currentDay)}>
                <Ionicons name="refresh" size={20} color="#4CAF50" />
              </TouchableOpacity>
            </View>

            <DraggableFlatList
              data={tripPlan.days[currentDay].activities}
              renderItem={renderActivityItem}
              keyExtractor={(item) => item.id}
              onDragEnd={handleDragEnd}
              contentContainerStyle={styles.activitiesList}
              scrollEnabled={false}
            />

            <TouchableOpacity style={styles.addActivityButton} onPress={addCustomActivity}>
              <Ionicons name="add" size={20} color="#4CAF50" />
              <Text style={styles.addActivityText}>Add Custom Activity</Text>
            </TouchableOpacity>

            <View style={styles.packageHeader}>
              <Text style={styles.packageTitle}>Recommended Travel Packages</Text>
              <TouchableOpacity onPress={() => setShowPackages(!showPackages)}>
                <Text style={styles.packageToggle}>{showPackages ? "Hide" : "Show"}</Text>
              </TouchableOpacity>
            </View>

            {showPackages && travelPackages.length > 0 && (
              <FlatList
                data={travelPackages}
                renderItem={renderPackageItem}
                keyExtractor={(item) => item.id}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.packagesList}
              />
            )}

            <TouchableOpacity
              style={styles.exportButton}
              onPress={() => {
                Alert.alert("Success", "Trip plan exported to your calendar and email!")
              }}
            >
              <Ionicons name="share" size={20} color="#fff" />
              <Text style={styles.exportButtonText}>Export Trip Plan</Text>
            </TouchableOpacity>
          </Animated.View>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  placeholder: {
    width: 40,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingBottom: 24,
  },
  plannerForm: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginTop: 16,
    marginBottom: 8,
  },
  destinationInput: {
    borderWidth: 1,
    borderColor: "#e0e0e0",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  dateContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  dateButton: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#e0e0e0",
    borderRadius: 8,
    padding: 12,
    flex: 1,
  },
  dateText: {
    fontSize: 14,
    color: "#212121",
    marginLeft: 8,
  },
  dateToText: {
    marginHorizontal: 8,
    color: "#757575",
  },
  budgetContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  budgetButton: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#e0e0e0",
    borderRadius: 8,
    padding: 12,
    marginHorizontal: 4,
  },
  budgetButtonSelected: {
    backgroundColor: "#4CAF50",
    borderColor: "#4CAF50",
  },
  budgetText: {
    fontSize: 14,
    color: "#212121",
    fontWeight: "600",
  },
  budgetTextSelected: {
    color: "#fff",
  },
  budgetSubtext: {
    fontSize: 12,
    color: "#757575",
    marginTop: 4,
  },
  budgetSubtextSelected: {
    color: "#fff",
  },
  interestsList: {
    paddingVertical: 8,
  },
  interestItem: {
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#e0e0e0",
    borderRadius: 8,
    padding: 12,
    marginRight: 8,
    width: 100,
  },
  interestItemSelected: {
    backgroundColor: "#4CAF50",
    borderColor: "#4CAF50",
  },
  interestText: {
    fontSize: 12,
    color: "#212121",
    marginTop: 4,
    textAlign: "center",
  },
  interestTextSelected: {
    color: "#fff",
  },
  advancedOptions: {
    marginTop: 16,
  },
  advancedButton: {
    flexDirection: "row",
    alignItems: "center",
  },
  advancedButtonText: {
    color: "#4CAF50",
    marginLeft: 8,
  },
  promptInput: {
    borderWidth: 1,
    borderColor: "#e0e0e0",
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    marginTop: 8,
    height: 80,
    textAlignVertical: "top",
  },
  generateButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 14,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 24,
  },
  generateButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
    marginLeft: 8,
  },
  tripPlanContainer: {
    padding: 16,
  },
  tripHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  tripDestination: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#212121",
  },
  tripDates: {
    fontSize: 14,
    color: "#757575",
  },
  editButton: {
    padding: 8,
  },
  weatherContainer: {
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  weatherTitle: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 8,
  },
  weatherDays: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  weatherDay: {
    alignItems: "center",
  },
  weatherDate: {
    fontSize: 12,
    color: "#757575",
  },
  weatherTemp: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginTop: 4,
  },
  tripSummary: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#e8f5e9",
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  summaryItem: {
    flexDirection: "row",
    alignItems: "center",
  },
  summaryText: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginLeft: 8,
  },
  daySelector: {
    marginBottom: 16,
  },
  dayButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    marginRight: 8,
    backgroundColor: "#f5f5f5",
  },
  dayButtonSelected: {
    backgroundColor: "#4CAF50",
  },
  dayButtonText: {
    fontSize: 14,
    color: "#757575",
  },
  dayButtonTextSelected: {
    color: "#fff",
    fontWeight: "bold",
  },
  dayPlanHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  dayPlanTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  regenerateButton: {
    padding: 8,
  },
  activitiesList: {
    paddingBottom: 8,
  },
  activityItem: {
    flexDirection: "row",
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  activityItemDragging: {
    opacity: 0.7,
    backgroundColor: "#e8f5e9",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
  },
  activityTimeContainer: {
    width: 60,
    alignItems: "center",
  },
  activityTime: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
  },
  activityDuration: {
    fontSize: 12,
    color: "#757575",
  },
  activityContent: {
    flex: 1,
    marginHorizontal: 12,
  },
  activityName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  activityLocation: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 4,
  },
  activityCost: {
    fontSize: 14,
    color: "#4CAF50",
    fontWeight: "bold",
  },
  activityActions: {
    justifyContent: "space-between",
  },
  activityAction: {
    padding: 8,
  },
  addActivityButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 12,
    marginBottom: 24,
  },
  addActivityText: {
    color: "#4CAF50",
    fontWeight: "bold",
    marginLeft: 8,
  },
  packageHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  packageTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  packageToggle: {
    color: "#4CAF50",
  },
  packagesList: {
    paddingBottom: 16,
  },
  packageItem: {
    width: 250,
    marginRight: 16,
    borderRadius: 8,
    backgroundColor: "#f9f9f9",
    overflow: "hidden",
  },
  packageImage: {
    width: "100%",
    height: 150,
  },
  packageContent: {
    padding: 12,
  },
  packageName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  packagePrice: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#4CAF50",
    marginBottom: 4,
  },
  packageRating: {
    flexDirection: "row",
    alignItems: "center",
  },
  packageRatingText: {
    fontSize: 14,
    color: "#757575",
    marginLeft: 4,
  },
  exportButton: {
    backgroundColor: "#2196F3",
    borderRadius: 8,
    paddingVertical: 14,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  exportButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
    marginLeft: 8,
  },
})

export default AIPlannerScreen
