"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  TextInput,
  Image,
  Alert,
  Modal,
  ActivityIndicator,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { searchTrails } from "../services/map"
import { getHiddenGems } from "../services/ai"

const TripListsScreen = ({ navigation }) => {
  const [lists, setLists] = useState([])
  const [activeList, setActiveList] = useState(null)
  const [showCreateList, setShowCreateList] = useState(false)
  const [newListName, setNewListName] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [showSearch, setShowSearch] = useState(false)
  const [isSearching, setIsSearching] = useState(false)

  useEffect(() => {
    // Load sample lists
    const sampleLists = [
      {
        id: "1",
        name: "Must Visit in San Francisco",
        places: [
          {
            id: "place-1",
            name: "Golden Gate Bridge",
            location: "San Francisco, CA",
            image: "https://via.placeholder.com/100",
            notes: "Visit during sunset for the best views",
            rating: 4.8,
            reviewCount: 1245,
            coordinates: {
              latitude: 37.8199,
              longitude: -122.4783,
            },
          },
          {
            id: "place-2",
            name: "Alcatraz Island",
            location: "San Francisco, CA",
            image: "https://via.placeholder.com/100",
            notes: "Book tickets in advance",
            rating: 4.7,
            reviewCount: 982,
            coordinates: {
              latitude: 37.8267,
              longitude: -122.4233,
            },
          },
        ],
      },
      {
        id: "2",
        name: "Best Restaurants",
        places: [
          {
            id: "place-3",
            name: "Tartine Bakery",
            location: "San Francisco, CA",
            image: "https://via.placeholder.com/100",
            notes: "Try the morning buns",
            rating: 4.9,
            reviewCount: 1876,
            coordinates: {
              latitude: 37.7614,
              longitude: -122.4241,
            },
          },
        ],
      },
      {
        id: "3",
        name: "Hiking Trails",
        places: [],
      },
    ]
    setLists(sampleLists)
    setActiveList(sampleLists[0])
  }, [])

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    setIsSearching(true)
    try {
      // Search for places
      const results = await searchTrails(searchQuery)

      // Also get hidden gems
      const gems = await getHiddenGems("San Francisco", ["nature", "food"])

      // Combine results
      const combinedResults = [...results, ...gems]
      setSearchResults(combinedResults)
    } catch (error) {
      console.error("Error searching:", error)
      Alert.alert("Search Error", "Failed to search for places. Please try again.")
    } finally {
      setIsSearching(false)
    }
  }

  const createNewList = () => {
    if (!newListName.trim()) {
      Alert.alert("Error", "Please enter a list name")
      return
    }

    const newList = {
      id: `list-${Date.now()}`,
      name: newListName,
      places: [],
    }

    setLists([...lists, newList])
    setActiveList(newList)
    setShowCreateList(false)
    setNewListName("")
  }

  const deleteList = (listId) => {
    Alert.alert("Delete List", "Are you sure you want to delete this list?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => {
          const updatedLists = lists.filter((list) => list.id !== listId)
          setLists(updatedLists)
          if (activeList && activeList.id === listId) {
            setActiveList(updatedLists.length > 0 ? updatedLists[0] : null)
          }
        },
      },
    ])
  }

  const addPlaceToList = (place) => {
    if (!activeList) return

    // Check if place already exists in the list
    const placeExists = activeList.places.some((p) => p.id === place.id)
    if (placeExists) {
      Alert.alert("Already Added", "This place is already in your list.")
      return
    }

    const updatedLists = lists.map((list) => {
      if (list.id === activeList.id) {
        return {
          ...list,
          places: [...list.places, place],
        }
      }
      return list
    })

    setLists(updatedLists)
    setActiveList(updatedLists.find((list) => list.id === activeList.id))
    setShowSearch(false)
  }

  const removePlaceFromList = (placeId) => {
    if (!activeList) return

    Alert.alert("Remove Place", "Are you sure you want to remove this place from the list?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove",
        style: "destructive",
        onPress: () => {
          const updatedLists = lists.map((list) => {
            if (list.id === activeList.id) {
              return {
                ...list,
                places: list.places.filter((place) => place.id !== placeId),
              }
            }
            return list
          })

          setLists(updatedLists)
          setActiveList(updatedLists.find((list) => list.id === activeList.id))
        },
      },
    ])
  }

  const addNoteToPlace = (placeId) => {
    if (!activeList) return

    const place = activeList.places.find((p) => p.id === placeId)
    if (!place) return

    Alert.prompt(
      "Add Note",
      "Enter a note for this place:",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Save",
          onPress: (note) => {
            if (!note) return

            const updatedLists = lists.map((list) => {
              if (list.id === activeList.id) {
                return {
                  ...list,
                  places: list.places.map((p) => (p.id === placeId ? { ...p, notes: note } : p)),
                }
              }
              return list
            })

            setLists(updatedLists)
            setActiveList(updatedLists.find((list) => list.id === activeList.id))
          },
        },
      ],
      "plain-text",
      place.notes,
    )
  }

  const renderListItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.listItem, activeList && activeList.id === item.id && styles.activeListItem]}
      onPress={() => setActiveList(item)}
    >
      <Text style={[styles.listName, activeList && activeList.id === item.id && styles.activeListName]}>
        {item.name}
      </Text>
      <Text style={styles.placeCount}>{item.places.length} places</Text>
      {activeList && activeList.id === item.id && (
        <TouchableOpacity style={styles.deleteListButton} onPress={() => deleteList(item.id)}>
          <Ionicons name="trash" size={20} color="#F44336" />
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  )

  const renderPlaceItem = ({ item }) => (
    <View style={styles.placeItem}>
      <Image source={{ uri: item.image }} style={styles.placeImage} />
      <View style={styles.placeContent}>
        <Text style={styles.placeName}>{item.name}</Text>
        <Text style={styles.placeLocation}>{item.location}</Text>
        {item.rating && (
          <View style={styles.ratingContainer}>
            <Ionicons name="star" size={16} color="#FFC107" />
            <Text style={styles.rating}>{item.rating}</Text>
            {item.reviewCount && <Text style={styles.reviewCount}>({item.reviewCount})</Text>}
          </View>
        )}
        {item.notes && <Text style={styles.placeNotes}>{item.notes}</Text>}
      </View>
      <View style={styles.placeActions}>
        <TouchableOpacity style={styles.placeAction} onPress={() => navigation.navigate("Map", { place: item })}>
          <Ionicons name="map" size={20} color="#4CAF50" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.placeAction} onPress={() => addNoteToPlace(item.id)}>
          <Ionicons name="create" size={20} color="#2196F3" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.placeAction} onPress={() => removePlaceFromList(item.id)}>
          <Ionicons name="trash" size={20} color="#F44336" />
        </TouchableOpacity>
      </View>
    </View>
  )

  const renderSearchResult = ({ item }) => (
    <TouchableOpacity style={styles.searchResultItem} onPress={() => addPlaceToList(item)}>
      <Image source={{ uri: item.image || "https://via.placeholder.com/60" }} style={styles.searchResultImage} />
      <View style={styles.searchResultContent}>
        <Text style={styles.searchResultName}>{item.name}</Text>
        <Text style={styles.searchResultLocation}>{item.location}</Text>
        {item.rating && (
          <View style={styles.ratingContainer}>
            <Ionicons name="star" size={16} color="#FFC107" />
            <Text style={styles.rating}>{item.rating}</Text>
            {item.reviewCount && <Text style={styles.reviewCount}>({item.reviewCount})</Text>}
          </View>
        )}
      </View>
      <Ionicons name="add-circle" size={24} color="#4CAF50" />
    </TouchableOpacity>
  )

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My Lists</Text>
        <TouchableOpacity style={styles.addButton} onPress={() => setShowCreateList(true)}>
          <Ionicons name="add" size={24} color="#212121" />
        </TouchableOpacity>
      </View>

      <View style={styles.listsContainer}>
        <FlatList
          data={lists}
          renderItem={renderListItem}
          keyExtractor={(item) => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.listsList}
        />
      </View>

      <View style={styles.content}>
        {activeList ? (
          <>
            <View style={styles.listHeader}>
              <Text style={styles.listTitle}>{activeList.name}</Text>
              <TouchableOpacity style={styles.searchButton} onPress={() => setShowSearch(true)}>
                <Ionicons name="add" size={20} color="#fff" />
                <Text style={styles.searchButtonText}>Add Place</Text>
              </TouchableOpacity>
            </View>

            {activeList.places.length > 0 ? (
              <FlatList
                data={activeList.places}
                renderItem={renderPlaceItem}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.placesList}
              />
            ) : (
              <View style={styles.emptyListContainer}>
                <Ionicons name="location" size={64} color="#E0E0E0" />
                <Text style={styles.emptyListText}>No places in this list yet</Text>
                <Text style={styles.emptyListSubtext}>Tap "Add Place" to start building your list</Text>
              </View>
            )}
          </>
        ) : (
          <View style={styles.noListContainer}>
            <Ionicons name="list" size={64} color="#E0E0E0" />
            <Text style={styles.noListText}>No lists created yet</Text>
            <Text style={styles.noListSubtext}>Create a list to start saving places</Text>
            <TouchableOpacity style={styles.createListButton} onPress={() => setShowCreateList(true)}>
              <Text style={styles.createListButtonText}>Create List</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Create List Modal */}
      <Modal visible={showCreateList} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Create New List</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="List Name"
              value={newListName}
              onChangeText={setNewListName}
            />
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.modalCancel} onPress={() => setShowCreateList(false)}>
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalCreate} onPress={createNewList}>
                <Text style={styles.modalCreateText}>Create</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Search Modal */}
      <Modal visible={showSearch} animationType="slide" transparent>
        <View style={styles.searchModalOverlay}>
          <View style={styles.searchModalContent}>
            <View style={styles.searchModalHeader}>
              <Text style={styles.searchModalTitle}>Add to {activeList?.name}</Text>
              <TouchableOpacity onPress={() => setShowSearch(false)}>
                <Ionicons name="close" size={24} color="#212121" />
              </TouchableOpacity>
            </View>

            <View style={styles.searchInputContainer}>
              <Ionicons name="search" size={20} color="#757575" style={styles.searchIcon} />
              <TextInput
                style={styles.searchInput}
                placeholder="Search for places, attractions, restaurants..."
                value={searchQuery}
                onChangeText={setSearchQuery}
                onSubmitEditing={handleSearch}
              />
              {searchQuery ? (
                <TouchableOpacity onPress={() => setSearchQuery("")}>
                  <Ionicons name="close-circle" size={20} color="#757575" />
                </TouchableOpacity>
              ) : null}
            </View>

            <TouchableOpacity style={styles.searchActionButton} onPress={handleSearch}>
              <Text style={styles.searchActionButtonText}>Search</Text>
            </TouchableOpacity>

            {isSearching ? (
              <View style={styles.searchLoadingContainer}>
                <ActivityIndicator size="large" color="#4CAF50" />
                <Text style={styles.searchLoadingText}>Searching...</Text>
              </View>
            ) : (
              <FlatList
                data={searchResults}
                renderItem={renderSearchResult}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.searchResultsList}
              />
            )}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  addButton: {
    padding: 8,
  },
  listsContainer: {
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  listsList: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  listItem: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: "#f5f5f5",
    marginRight: 8,
    minWidth: 120,
  },
  activeListItem: {
    backgroundColor: "#4CAF50",
  },
  listName: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  activeListName: {
    color: "#fff",
  },
  placeCount: {
    fontSize: 12,
    color: "#757575",
  },
  deleteListButton: {
    position: "absolute",
    top: 8,
    right: 8,
  },
  content: {
    flex: 1,
  },
  listHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  listTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  searchButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#4CAF50",
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  searchButtonText: {
    color: "#fff",
    fontWeight: "bold",
    marginLeft: 4,
  },
  placesList: {
    padding: 16,
  },
  placeItem: {
    flexDirection: "row",
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  placeImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  placeContent: {
    flex: 1,
  },
  placeName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  placeLocation: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4,
  },
  rating: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginLeft: 4,
  },
  reviewCount: {
    fontSize: 14,
    color: "#757575",
    marginLeft: 4,
  },
  placeNotes: {
    fontSize: 14,
    color: "#4CAF50",
    fontStyle: "italic",
  },
  placeActions: {
    justifyContent: "space-between",
  },
  placeAction: {
    padding: 8,
  },
  emptyListContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  emptyListText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#757575",
    marginTop: 16,
  },
  emptyListSubtext: {
    fontSize: 14,
    color: "#9E9E9E",
    marginTop: 8,
    textAlign: "center",
  },
  noListContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  noListText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#757575",
    marginTop: 16,
  },
  noListSubtext: {
    fontSize: 14,
    color: "#9E9E9E",
    marginTop: 8,
    textAlign: "center",
  },
  createListButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginTop: 16,
  },
  createListButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 24,
    width: "80%",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 16,
  },
  modalInput: {
    borderWidth: 1,
    borderColor: "#e0e0e0",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
  },
  modalActions: {
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  modalCancel: {
    padding: 8,
    marginRight: 16,
  },
  modalCancelText: {
    fontSize: 16,
    color: "#757575",
  },
  modalCreate: {
    padding: 8,
  },
  modalCreateText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#4CAF50",
  },
  searchModalOverlay: {
    flex: 1,
    backgroundColor: "#fff",
  },
  searchModalContent: {
    flex: 1,
    padding: 16,
  },
  searchModalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  searchModalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  searchInputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 40,
    marginBottom: 16,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: "#212121",
  },
  searchActionButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: "center",
    marginBottom: 16,
  },
  searchActionButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  searchLoadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  searchLoadingText: {
    marginTop: 16,
    fontSize: 16,
    color: "#757575",
  },
  searchResultsList: {
    flex: 1,
  },
  searchResultItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  searchResultImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  searchResultContent: {
    flex: 1,
  },
  searchResultName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  searchResultLocation: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 4,
  },
})

export default TripListsScreen
