"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  Image,
  Alert,
  ActivityIndicator,
  ProgressBarAndroid,
  ProgressViewIOS,
  Platform,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"

const OfflineMapsScreen = ({ navigation }) => {
  const [downloadedMaps, setDownloadedMaps] = useState([])
  const [availableMaps, setAvailableMaps] = useState([])
  const [activeDownloads, setActiveDownloads] = useState({})
  const [activeTab, setActiveTab] = useState("downloaded")

  // Mock data
  useEffect(() => {
    setDownloadedMaps([
      {
        id: "1",
        name: "Yosemite National Park",
        region: "California",
        size: "245 MB",
        lastUpdated: "2 weeks ago",
        image:
          "https://images.unsplash.com/photo-1472396961693-142e6e269027?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      },
      {
        id: "2",
        name: "Muir Woods",
        region: "California",
        size: "78 MB",
        lastUpdated: "1 month ago",
        image:
          "https://images.unsplash.com/photo-1552521684-edc2a078660e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      },
    ])

    setAvailableMaps([
      {
        id: "3",
        name: "Grand Canyon",
        region: "Arizona",
        size: "312 MB",
        image:
          "https://images.unsplash.com/photo-1474044159687-1ee9f3a51722?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      },
      {
        id: "4",
        name: "Zion National Park",
        region: "Utah",
        size: "186 MB",
        image:
          "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      },
      {
        id: "5",
        name: "Yellowstone",
        region: "Wyoming",
        size: "420 MB",
        image:
          "https://images.unsplash.com/photo-1535752385016-16aa049b6a8d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      },
      {
        id: "6",
        name: "Olympic National Park",
        region: "Washington",
        size: "265 MB",
        image:
          "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      },
    ])
  }, [])

  const startDownload = (mapId) => {
    // Simulate download progress
    setActiveDownloads((prev) => ({
      ...prev,
      [mapId]: { progress: 0, status: "downloading" },
    }))

    const interval = setInterval(() => {
      setActiveDownloads((prev) => {
        const currentProgress = prev[mapId]?.progress || 0
        const newProgress = currentProgress + 0.05

        if (newProgress >= 1) {
          clearInterval(interval)

          // Move from available to downloaded
          const mapToMove = availableMaps.find((map) => map.id === mapId)
          if (mapToMove) {
            setDownloadedMaps((prev) => [
              ...prev,
              {
                ...mapToMove,
                lastUpdated: "Just now",
              },
            ])
            setAvailableMaps((prev) => prev.filter((map) => map.id !== mapId))
          }

          // Clear download after a delay
          setTimeout(() => {
            setActiveDownloads((prev) => {
              const newDownloads = { ...prev }
              delete newDownloads[mapId]
              return newDownloads
            })
          }, 1000)

          return {
            ...prev,
            [mapId]: { progress: 1, status: "completed" },
          }
        }

        return {
          ...prev,
          [mapId]: { progress: newProgress, status: "downloading" },
        }
      })
    }, 300)
  }

  const pauseDownload = (mapId) => {
    setActiveDownloads((prev) => ({
      ...prev,
      [mapId]: { ...prev[mapId], status: "paused" },
    }))
  }

  const resumeDownload = (mapId) => {
    setActiveDownloads((prev) => ({
      ...prev,
      [mapId]: { ...prev[mapId], status: "downloading" },
    }))
    // In a real app, you would resume the actual download
  }

  const cancelDownload = (mapId) => {
    Alert.alert("Cancel Download", "Are you sure you want to cancel this download?", [
      { text: "No", style: "cancel" },
      {
        text: "Yes",
        style: "destructive",
        onPress: () => {
          setActiveDownloads((prev) => {
            const newDownloads = { ...prev }
            delete newDownloads[mapId]
            return newDownloads
          })
        },
      },
    ])
  }

  const deleteMap = (mapId) => {
    Alert.alert("Delete Offline Map", "Are you sure you want to delete this offline map?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => {
          const mapToDelete = downloadedMaps.find((map) => map.id === mapId)
          if (mapToDelete) {
            setDownloadedMaps((prev) => prev.filter((map) => map.id !== mapId))
            setAvailableMaps((prev) => [
              ...prev,
              {
                ...mapToDelete,
                lastUpdated: undefined,
              },
            ])
          }
        },
      },
    ])
  }

  const renderProgressBar = (mapId) => {
    const download = activeDownloads[mapId]
    if (!download) return null

    return (
      <View style={styles.progressContainer}>
        {Platform.OS === "ios" ? (
          <ProgressViewIOS progress={download.progress} progressTintColor="#4CAF50" />
        ) : (
          <ProgressBarAndroid
            styleAttr="Horizontal"
            indeterminate={false}
            progress={download.progress}
            progressTintColor="#4CAF50"
          />
        )}
        <View style={styles.progressActions}>
          <Text style={styles.progressText}>
            {download.status === "completed" ? "Download Complete" : `${Math.round(download.progress * 100)}%`}
          </Text>
          {download.status === "downloading" && (
            <TouchableOpacity onPress={() => pauseDownload(mapId)}>
              <Ionicons name="pause" size={20} color="#4CAF50" />
            </TouchableOpacity>
          )}
          {download.status === "paused" && (
            <TouchableOpacity onPress={() => resumeDownload(mapId)}>
              <Ionicons name="play" size={20} color="#4CAF50" />
            </TouchableOpacity>
          )}
          {download.status !== "completed" && (
            <TouchableOpacity onPress={() => cancelDownload(mapId)}>
              <Ionicons name="close" size={20} color="#F44336" />
            </TouchableOpacity>
          )}
        </View>
      </View>
    )
  }

  const renderMapItem = ({ item, type }) => (
    <View style={styles.mapItem}>
      <Image source={{ uri: item.image }} style={styles.mapImage} />
      <View style={styles.mapContent}>
        <Text style={styles.mapName}>{item.name}</Text>
        <Text style={styles.mapRegion}>{item.region}</Text>
        <View style={styles.mapDetails}>
          <Text style={styles.mapSize}>{item.size}</Text>
          {item.lastUpdated && <Text style={styles.mapUpdated}>Updated: {item.lastUpdated}</Text>}
        </View>
        {renderProgressBar(item.id)}
      </View>
      {type === "downloaded" ? (
        <TouchableOpacity style={styles.mapAction} onPress={() => deleteMap(item.id)}>
          <Ionicons name="trash-outline" size={24} color="#F44336" />
        </TouchableOpacity>
      ) : activeDownloads[item.id] ? (
        <View style={styles.mapAction}>
          <ActivityIndicator color="#4CAF50" />
        </View>
      ) : (
        <TouchableOpacity style={styles.mapAction} onPress={() => startDownload(item.id)}>
          <Ionicons name="download-outline" size={24} color="#4CAF50" />
        </TouchableOpacity>
      )}
    </View>
  )

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Offline Maps</Text>
        <View style={styles.placeholder} />
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "downloaded" && styles.activeTab]}
          onPress={() => setActiveTab("downloaded")}
        >
          <Text style={[styles.tabText, activeTab === "downloaded" && styles.activeTabText]}>Downloaded</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === "available" && styles.activeTab]}
          onPress={() => setActiveTab("available")}
        >
          <Text style={[styles.tabText, activeTab === "available" && styles.activeTabText]}>Available</Text>
        </TouchableOpacity>
      </View>

      {activeTab === "downloaded" ? (
        downloadedMaps.length > 0 ? (
          <FlatList
            data={downloadedMaps}
            renderItem={({ item }) => renderMapItem({ item, type: "downloaded" })}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.mapsList}
          />
        ) : (
          <View style={styles.emptyContainer}>
            <Ionicons name="map-outline" size={64} color="#E0E0E0" />
            <Text style={styles.emptyText}>No offline maps downloaded</Text>
            <Text style={styles.emptySubtext}>Download maps to use when you don't have internet connection</Text>
            <TouchableOpacity style={styles.emptyButton} onPress={() => setActiveTab("available")}>
              <Text style={styles.emptyButtonText}>Browse Available Maps</Text>
            </TouchableOpacity>
          </View>
        )
      ) : (
        <FlatList
          data={availableMaps}
          renderItem={({ item }) => renderMapItem({ item, type: "available" })}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.mapsList}
        />
      )}
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  placeholder: {
    width: 40,
  },
  tabs: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: "center",
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: "#4CAF50",
  },
  tabText: {
    fontSize: 16,
    color: "#757575",
  },
  activeTabText: {
    color: "#4CAF50",
    fontWeight: "600",
  },
  mapsList: {
    padding: 16,
  },
  mapItem: {
    flexDirection: "row",
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    marginBottom: 16,
    overflow: "hidden",
  },
  mapImage: {
    width: 100,
    height: 100,
  },
  mapContent: {
    flex: 1,
    padding: 12,
  },
  mapName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 4,
  },
  mapRegion: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 8,
  },
  mapDetails: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  mapSize: {
    fontSize: 14,
    color: "#9E9E9E",
  },
  mapUpdated: {
    fontSize: 14,
    color: "#9E9E9E",
  },
  mapAction: {
    width: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  progressContainer: {
    marginTop: 8,
  },
  progressActions: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 4,
  },
  progressText: {
    fontSize: 12,
    color: "#757575",
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#757575",
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: "#9E9E9E",
    marginTop: 8,
    textAlign: "center",
  },
  emptyButton: {
    marginTop: 24,
    paddingHorizontal: 24,
    paddingVertical: 12,
    backgroundColor: "#4CAF50",
    borderRadius: 24,
  },
  emptyButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
})

export default OfflineMapsScreen
