"use client"

import { useState } from "react"
import { View, Text, StyleSheet, SafeAreaView, ScrollView, TextInput, TouchableOpacity, FlatList } from "react-native"
import { Ionicons } from "@expo/vector-icons"

interface DayPlan {
  id: string
  time: string
  activity: string
  location: string
  cost: number
}

interface TripDay {
  id: string
  date: string
  plans: DayPlan[]
}

const TripPlannerScreen = ({ navigation }) => {
  const [prompt, setPrompt] = useState("")
  const [tripDays, setTripDays] = useState<TripDay[]>([])
  const [totalBudget, setTotalBudget] = useState(0)
  const [isGenerating, setIsGenerating] = useState(false)

  // Mock function to generate AI trip plan
  const generateTripPlan = () => {
    setIsGenerating(true)

    // Simulate API call delay
    setTimeout(() => {
      const mockTripDays: TripDay[] = [
        {
          id: "1",
          date: "Day 1",
          plans: [
            {
              id: "1-1",
              time: "09:00 AM",
              activity: "Morning hike",
              location: "Twin Peaks",
              cost: 0,
            },
            {
              id: "1-2",
              time: "12:30 PM",
              activity: "Lunch",
              location: "Zazie Restaurant",
              cost: 25,
            },
            {
              id: "1-3",
              time: "03:00 PM",
              activity: "Visit Museum",
              location: "de Young Museum",
              cost: 15,
            },
            {
              id: "1-4",
              time: "07:00 PM",
              activity: "Dinner",
              location: "Nopa Restaurant",
              cost: 45,
            },
          ],
        },
        {
          id: "2",
          date: "Day 2",
          plans: [
            {
              id: "2-1",
              time: "10:00 AM",
              activity: "Beach walk",
              location: "Baker Beach",
              cost: 0,
            },
            {
              id: "2-2",
              time: "01:00 PM",
              activity: "Lunch",
              location: "Woodhouse Fish Co.",
              cost: 30,
            },
            {
              id: "2-3",
              time: "04:00 PM",
              activity: "Shopping",
              location: "Union Square",
              cost: 100,
            },
            {
              id: "2-4",
              time: "08:00 PM",
              activity: "Dinner",
              location: "Foreign Cinema",
              cost: 55,
            },
          ],
        },
      ]

      setTripDays(mockTripDays)

      // Calculate total budget
      const total = mockTripDays.reduce(
        (sum, day) => sum + day.plans.reduce((daySum, plan) => daySum + plan.cost, 0),
        0,
      )
      setTotalBudget(total)

      setIsGenerating(false)
    }, 2000)
  }

  const renderDayPlan = ({ item }: { item: TripDay }) => {
    return (
      <View style={styles.dayContainer}>
        <Text style={styles.dayTitle}>{item.date}</Text>
        {item.plans.map((plan) => (
          <View key={plan.id} style={styles.planItem}>
            <View style={styles.timeContainer}>
              <Text style={styles.timeText}>{plan.time}</Text>
            </View>
            <View style={styles.planContent}>
              <Text style={styles.activityText}>{plan.activity}</Text>
              <Text style={styles.locationText}>{plan.location}</Text>
              {plan.cost > 0 && <Text style={styles.costText}>${plan.cost}</Text>}
            </View>
          </View>
        ))}
      </View>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#212121" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Trip Planner</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content}>
        <View style={styles.promptContainer}>
          <Text style={styles.promptLabel}>Describe your trip:</Text>
          <TextInput
            style={styles.promptInput}
            placeholder="e.g., '2-day beach vacation in San Francisco'"
            placeholderTextColor="#9e9e9e"
            value={prompt}
            onChangeText={setPrompt}
            multiline
          />
          <TouchableOpacity
            style={[styles.generateButton, (!prompt || isGenerating) && styles.disabledButton]}
            onPress={generateTripPlan}
            disabled={!prompt || isGenerating}
          >
            {isGenerating ? (
              <Text style={styles.generateButtonText}>Generating...</Text>
            ) : (
              <>
                <Ionicons name="sparkles-outline" size={20} color="#fff" />
                <Text style={styles.generateButtonText}>Generate AI Plan</Text>
              </>
            )}
          </TouchableOpacity>
        </View>

        {tripDays.length > 0 && (
          <View style={styles.planContainer}>
            <View style={styles.budgetContainer}>
              <Text style={styles.budgetLabel}>Estimated Budget:</Text>
              <Text style={styles.budgetAmount}>${totalBudget}</Text>
            </View>

            <FlatList
              data={tripDays}
              renderItem={renderDayPlan}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
            />

            <TouchableOpacity style={styles.viewMapButton} onPress={() => navigation.navigate("Map")}>
              <Ionicons name="map-outline" size={20} color="#fff" />
              <Text style={styles.viewMapButtonText}>View on Map</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  placeholder: {
    width: 40,
  },
  content: {
    flex: 1,
  },
  promptContainer: {
    padding: 16,
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    margin: 16,
  },
  promptLabel: {
    fontSize: 16,
    fontWeight: "600",
    color: "#212121",
    marginBottom: 8,
  },
  promptInput: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: "#212121",
    minHeight: 80,
    textAlignVertical: "top",
    borderWidth: 1,
    borderColor: "#e0e0e0",
  },
  generateButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 12,
    marginTop: 16,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  disabledButton: {
    backgroundColor: "#a5d6a7",
  },
  generateButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
    marginLeft: 8,
  },
  planContainer: {
    padding: 16,
  },
  budgetContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#e8f5e9",
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
  },
  budgetLabel: {
    fontSize: 16,
    fontWeight: "600",
    color: "#2e7d32",
  },
  budgetAmount: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#2e7d32",
  },
  dayContainer: {
    marginBottom: 24,
  },
  dayTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 12,
    backgroundColor: "#f5f5f5",
    padding: 8,
    borderRadius: 4,
  },
  planItem: {
    flexDirection: "row",
    marginBottom: 16,
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
  },
  timeContainer: {
    backgroundColor: "#e0e0e0",
    borderRadius: 4,
    padding: 8,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
    minWidth: 80,
  },
  timeText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#424242",
  },
  planContent: {
    flex: 1,
  },
  activityText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#212121",
    marginBottom: 4,
  },
  locationText: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 4,
  },
  costText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#4CAF50",
  },
  viewMapButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 12,
    marginTop: 16,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  viewMapButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
    marginLeft: 8,
  },
})

export default TripPlannerScreen
