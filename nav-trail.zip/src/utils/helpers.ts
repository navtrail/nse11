export const formatDistance = (meters: number): string => {
  if (meters < 1000) {
    return `${Math.round(meters)} m`
  }
  return `${(meters / 1000).toFixed(1)} km`
}

export const formatDuration = (seconds: number): string => {
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)

  if (hours > 0) {
    return `${hours} hr ${minutes} min`
  }
  return `${minutes} min`
}

export const generateRandomAvatar = (name: string): string => {
  // Generate a consistent color based on the name
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash)
  }

  // Convert to hex color
  const color = Math.abs(hash).toString(16).substring(0, 6)

  // Use a placeholder service that accepts initials and background color
  const initials = name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .toUpperCase()
    .substring(0, 2)

  return `https://ui-avatars.com/api/?name=${initials}&background=${color}&color=fff`
}

export const getWeatherIcon = (condition: string): string => {
  const conditions = {
    clear: "sunny-outline",
    sunny: "sunny-outline",
    "partly-cloudy": "partly-sunny-outline",
    cloudy: "cloudy-outline",
    rain: "rainy-outline",
    thunderstorm: "thunderstorm-outline",
    snow: "snow-outline",
    fog: "cloud-outline",
  }

  return conditions[condition.toLowerCase()] || "help-outline"
}

export const getDifficultyColor = (difficulty: string): string => {
  const colors = {
    easy: "#4CAF50",
    moderate: "#FF9800",
    hard: "#F44336",
    extreme: "#9C27B0",
  }

  return colors[difficulty.toLowerCase()] || "#757575"
}
