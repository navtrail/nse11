import type React from "react"
import { View, Text, StyleSheet, TouchableOpacity } from "react-native"
import { Ionicons } from "@expo/vector-icons"

interface RouteSummaryProps {
  distance: number // in meters
  duration: number // in seconds
  steps: Array<{
    maneuver: {
      instruction: string
    }
  }>
  onViewMap: () => void
}

const RouteSummary: React.FC<RouteSummaryProps> = ({ distance, duration, steps, onViewMap }) => {
  const formatDistance = (meters: number) => {
    if (meters < 1000) {
      return `${Math.round(meters)} m`
    }
    return `${(meters / 1000).toFixed(1)} km`
  }

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)

    if (hours > 0) {
      return `${hours} hr ${minutes} min`
    }
    return `${minutes} min`
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Route Summary</Text>
        <TouchableOpacity onPress={onViewMap} style={styles.viewMapButton}>
          <Text style={styles.viewMapText}>View on Map</Text>
          <Ionicons name="chevron-forward" size={16} color="#4CAF50" />
        </TouchableOpacity>
      </View>

      <View style={styles.stats}>
        <View style={styles.statItem}>
          <Ionicons name="time-outline" size={24} color="#4CAF50" />
          <Text style={styles.statValue}>{formatDuration(duration)}</Text>
          <Text style={styles.statLabel}>Duration</Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.statItem}>
          <Ionicons name="navigate-outline" size={24} color="#4CAF50" />
          <Text style={styles.statValue}>{formatDistance(distance)}</Text>
          <Text style={styles.statLabel}>Distance</Text>
        </View>
      </View>

      <View style={styles.directions}>
        <Text style={styles.directionsTitle}>Directions:</Text>
        {steps.slice(0, 3).map((step, index) => (
          <View key={index} style={styles.step}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>{index + 1}</Text>
            </View>
            <Text style={styles.stepText}>{step.maneuver.instruction}</Text>
          </View>
        ))}
        {steps.length > 3 && (
          <TouchableOpacity style={styles.moreSteps}>
            <Text style={styles.moreStepsText}>+{steps.length - 3} more steps</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 16,
    margin: 16,
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#212121",
  },
  viewMapButton: {
    flexDirection: "row",
    alignItems: "center",
  },
  viewMapText: {
    color: "#4CAF50",
    fontWeight: "600",
    marginRight: 4,
  },
  stats: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 16,
    paddingVertical: 8,
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
  },
  statItem: {
    alignItems: "center",
    flex: 1,
  },
  statValue: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#212121",
    marginTop: 4,
  },
  statLabel: {
    fontSize: 12,
    color: "#757575",
    marginTop: 2,
  },
  divider: {
    width: 1,
    backgroundColor: "#e0e0e0",
  },
  directions: {
    marginTop: 8,
  },
  directionsTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#212121",
    marginBottom: 12,
  },
  step: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 12,
  },
  stepNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "#4CAF50",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
    marginTop: 2,
  },
  stepNumberText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "bold",
  },
  stepText: {
    flex: 1,
    fontSize: 14,
    color: "#424242",
    lineHeight: 20,
  },
  moreSteps: {
    alignItems: "center",
    marginTop: 8,
  },
  moreStepsText: {
    color: "#4CAF50",
    fontWeight: "600",
  },
})

export default RouteSummary
