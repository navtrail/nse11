import type React from "react"
import { View, Text, StyleSheet, TouchableOpacity } from "react-native"
import { Ionicons } from "@expo/vector-icons"

type TabName = "Home" | "Search" | "TripPlanner" | "Saved" | "Settings"

interface BottomTabBarProps {
  activeTab: TabName
  onTabPress: (tab: TabName) => void
}

const BottomTabBar: React.FC<BottomTabBarProps> = ({ activeTab, onTabPress }) => {
  const tabs: { name: TabName; icon: string }[] = [
    { name: "Home", icon: "home" },
    { name: "Search", icon: "search" },
    { name: "TripPlanner", icon: "map" },
    { name: "Saved", icon: "bookmark" },
    { name: "Settings", icon: "settings" },
  ]

  return (
    <View style={styles.container}>
      {tabs.map((tab) => (
        <TouchableOpacity
          key={tab.name}
          style={[styles.tabButton, activeTab === tab.name && styles.activeTabButton]}
          onPress={() => onTabPress(tab.name)}
        >
          <Ionicons name={tab.icon as any} size={24} color={activeTab === tab.name ? "#4CAF50" : "#757575"} />
          <Text style={[styles.tabLabel, activeTab === tab.name && styles.activeTabLabel]}>
            {tab.name === "TripPlanner" ? "Plan" : tab.name}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    height: 60,
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderTopColor: "#f0f0f0",
    paddingBottom: 5,
  },
  tabButton: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 5,
  },
  activeTabButton: {
    borderTopWidth: 3,
    borderTopColor: "#4CAF50",
    paddingTop: 2,
  },
  tabLabel: {
    fontSize: 12,
    color: "#757575",
    marginTop: 2,
  },
  activeTabLabel: {
    color: "#4CAF50",
    fontWeight: "bold",
  },
})

export default BottomTabBar
