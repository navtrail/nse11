import type React from "react"
import { View, Text, StyleSheet, TouchableOpacity, TextInput } from "react-native"
import { Ionicons } from "@expo/vector-icons"

interface SearchInputProps {
  placeholder?: string
  value?: string
  onChangeText?: (text: string) => void
  onPress?: () => void
  editable?: boolean
}

const SearchInput: React.FC<SearchInputProps> = ({
  placeholder = "Search...",
  value,
  onChangeText,
  onPress,
  editable = true,
}) => {
  if (onPress) {
    return (
      <TouchableOpacity style={[styles.container, styles.pressable]} onPress={onPress} activeOpacity={0.7}>
        <Ionicons name="search" size={20} color="#757575" style={styles.icon} />
        <Text style={styles.placeholder}>{placeholder}</Text>
      </TouchableOpacity>
    )
  }

  return (
    <View style={styles.container}>
      <Ionicons name="search" size={20} color="#757575" style={styles.icon} />
      <TextInput
        style={styles.input}
        placeholder={placeholder}
        placeholderTextColor="#757575"
        value={value}
        onChangeText={onChangeText}
        editable={editable}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: 46,
    backgroundColor: "#f5f5f5",
    borderRadius: 23,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
  },
  pressable: {
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
  },
  icon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#212121",
  },
  placeholder: {
    fontSize: 16,
    color: "#757575",
  },
})

export default SearchInput
