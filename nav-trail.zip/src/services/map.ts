import AsyncStorage from "@react-native-async-storage/async-storage"

// Mock delay to simulate network request
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Mock trail data
const trails = [
  {
    id: "1",
    name: "Eagle Peak Trail",
    description: "A beautiful trail with panoramic views of the valley.",
    location: "Yosemite National Park, CA",
    coordinates: {
      latitude: 37.7749,
      longitude: -119.5501,
    },
    length: 8.2,
    difficulty: "Moderate",
    elevation: 850,
    duration: 240, // minutes
    rating: 4.8,
    reviewCount: 124,
    features: ["Waterfall", "Forest", "Mountain Views"],
    image: "https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    waypoints: [
      { id: 1, name: "Trailhead", coordinates: { latitude: 37.7749, longitude: -119.5501 } },
      { id: 2, name: "Creek Crossing", coordinates: { latitude: 37.7769, longitude: -119.5481 } },
      { id: 3, name: "Viewpoint", coordinates: { latitude: 37.7789, longitude: -119.5461 } },
      { id: 4, name: "Summit", coordinates: { latitude: 37.7809, longitude: -119.5441 } },
    ],
    route: [
      { latitude: 37.7749, longitude: -119.5501 },
      { latitude: 37.7759, longitude: -119.5491 },
      { latitude: 37.7769, longitude: -119.5481 },
      { latitude: 37.7779, longitude: -119.5471 },
      { latitude: 37.7789, longitude: -119.5461 },
      { latitude: 37.7799, longitude: -119.5451 },
      { latitude: 37.7809, longitude: -119.5441 },
    ],
  },
  // More trails...
]

// Get trail details
export const getTrailDetails = async (trailId: string) => {
  // Simulate API call
  await delay(1000)

  // Check if offline maps are enabled and if we have cached data
  const offlineMapsEnabled = await AsyncStorage.getItem("settings:offlineMaps")
  if (offlineMapsEnabled === "true") {
    const cachedTrail = await AsyncStorage.getItem(`trail:${trailId}`)
    if (cachedTrail) {
      return JSON.parse(cachedTrail)
    }
  }

  // Fallback to "online" data
  const trail = trails.find((t) => t.id === trailId)
  if (!trail) {
    throw new Error("Trail not found")
  }

  return trail
}

// Search trails
export const searchTrails = async (query: string, filters: any = {}) => {
  // Simulate API call
  await delay(1500)

  let filteredTrails = [...trails]

  // Apply search query
  if (query) {
    filteredTrails = filteredTrails.filter(
      (trail) =>
        trail.name.toLowerCase().includes(query.toLowerCase()) ||
        trail.location.toLowerCase().includes(query.toLowerCase()) ||
        trail.features.some((feature) => feature.toLowerCase().includes(query.toLowerCase())),
    )
  }

  // Apply filters
  if (filters.difficulty) {
    filteredTrails = filteredTrails.filter((trail) => trail.difficulty === filters.difficulty)
  }

  if (filters.minLength && filters.maxLength) {
    filteredTrails = filteredTrails.filter(
      (trail) => trail.length >= filters.minLength && trail.length <= filters.maxLength,
    )
  }

  return filteredTrails
}

// Get nearby trails
export const getNearbyTrails = async (latitude: number, longitude: number, radius = 50) => {
  // Simulate API call
  await delay(1000)

  // In a real app, this would calculate distance and filter based on radius
  return trails
}

// Download map for offline use
export const downloadOfflineMap = async (mapId: string, progressCallback?: (progress: number) => void) => {
  // Simulate download with progress
  const totalChunks = 20
  for (let i = 0; i < totalChunks; i++) {
    await delay(300)
    if (progressCallback) {
      progressCallback((i + 1) / totalChunks)
    }
  }

  // Save to AsyncStorage
  const trail = trails.find((t) => t.id === mapId)
  if (trail) {
    await AsyncStorage.setItem(`trail:${mapId}`, JSON.stringify(trail))

    // Update downloaded maps list
    const downloadedMaps = await getDownloadedMaps()
    if (!downloadedMaps.includes(mapId)) {
      downloadedMaps.push(mapId)
      await AsyncStorage.setItem("downloadedMaps", JSON.stringify(downloadedMaps))
    }

    return true
  }

  throw new Error("Map not found")
}

// Delete offline map
export const deleteOfflineMap = async (mapId: string) => {
  // Remove from AsyncStorage
  await AsyncStorage.removeItem(`trail:${mapId}`)

  // Update downloaded maps list
  const downloadedMaps = await getDownloadedMaps()
  const updatedMaps = downloadedMaps.filter((id) => id !== mapId)
  await AsyncStorage.setItem("downloadedMaps", JSON.stringify(updatedMaps))

  return true
}

// Get downloaded maps
export const getDownloadedMaps = async () => {
  const maps = await AsyncStorage.getItem("downloadedMaps")
  return maps ? JSON.parse(maps) : []
}

// Get map size (in MB)
export const getMapSize = (mapId: string) => {
  // Mock sizes
  const sizes = {
    "1": 245,
    "2": 78,
    "3": 312,
    "4": 186,
    "5": 420,
  }

  return sizes[mapId] || 100
}
