import AsyncStorage from "@react-native-async-storage/async-storage"

// Mock delay to simulate network request
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Dataset types
export type StravlDataPoint = {
  id: string
  userId: string
  activityType: string
  distance: number
  duration: number
  elevationGain: number
  startPoint: {
    latitude: number
    longitude: number
  }
  endPoint: {
    latitude: number
    longitude: number
  }
  routePoints: Array<{
    latitude: number
    longitude: number
    elevation?: number
    timestamp?: number
  }>
  averageSpeed: number
  maxSpeed: number
  timestamp: number
  weather?: {
    temperature: number
    conditions: string
    windSpeed: number
  }
  photos?: string[]
  rating?: number
  difficulty?: string
}

export type BookingDestination = {
  id: string
  name: string
  type: "city" | "landmark" | "area" | "airport"
  country: string
  countryCode: string
  coordinates: {
    latitude: number
    longitude: number
  }
  popularity: number
  accommodations: number
  averagePrice: number
  seasonality: {
    highSeason: string[]
    lowSeason: string[]
  }
  tags: string[]
  image?: string
}

export type BookingTrip = {
  id: string
  userId: string
  destinations: BookingDestination[]
  startDate: string
  endDate: string
  totalPrice: number
  accommodations: Array<{
    id: string
    name: string
    type: string
    price: number
    rating: number
    location: {
      latitude: number
      longitude: number
    }
    checkIn: string
    checkOut: string
    amenities: string[]
    image?: string
  }>
  transportation: Array<{
    type: string
    from: string
    to: string
    departureTime: string
    arrivalTime: string
    price: number
    provider: string
  }>
  activities?: Array<{
    id: string
    name: string
    type: string
    price: number
    date: string
    duration: number
    location: {
      latitude: number
      longitude: number
    }
    rating?: number
    image?: string
  }>
}

export type OPTDLocation = {
  iataCode: string
  name: string
  city: string
  countryCode: string
  countryName: string
  coordinates: {
    latitude: number
    longitude: number
  }
  timezone: string
  type: "airport" | "railway_station" | "bus_station" | "port"
  popularity: number
  facilities: string[]
}

export type IndiaTourismData = {
  year: number
  month: string
  state: string
  domesticVisitors: number
  foreignVisitors: number
  totalVisitors: number
  topAttractions: string[]
  averageStay: number
  seasonality: string
  revenue: number
}

export type TravelRecommendation = {
  id: string
  destination: string
  country: string
  coordinates: {
    latitude: number
    longitude: number
  }
  recommendationType: "destination" | "activity" | "accommodation" | "restaurant"
  category: string[]
  rating: number
  priceLevel: number
  bestTimeToVisit: string[]
  description: string
  tags: string[]
  similarPlaces: string[]
  image?: string
}

// Cache keys
const CACHE_KEYS = {
  STRAVL_DATA: "cache:stravl-data",
  BOOKING_DESTINATIONS: "cache:booking-destinations",
  BOOKING_TRIPS: "cache:booking-trips",
  OPTD_LOCATIONS: "cache:optd-locations",
  INDIA_TOURISM: "cache:india-tourism",
  TRAVEL_RECOMMENDATIONS: "cache:travel-recommendations",
}

// Cache expiration in milliseconds (24 hours)
const CACHE_EXPIRATION = 24 * 60 * 60 * 1000

// Mock data for Stravl-Data
const mockStravlData: StravlDataPoint[] = [
  {
    id: "stravl-1",
    userId: "user-1",
    activityType: "hiking",
    distance: 8.5,
    duration: 10800, // 3 hours in seconds
    elevationGain: 450,
    startPoint: {
      latitude: 37.7749,
      longitude: -122.4194,
    },
    endPoint: {
      latitude: 37.8049,
      longitude: -122.4514,
    },
    routePoints: [
      { latitude: 37.7749, longitude: -122.4194, elevation: 10, timestamp: 1625097600000 },
      { latitude: 37.7849, longitude: -122.4294, elevation: 150, timestamp: 1625101200000 },
      { latitude: 37.7949, longitude: -122.4394, elevation: 300, timestamp: 1625104800000 },
      { latitude: 37.8049, longitude: -122.4514, elevation: 460, timestamp: 1625108400000 },
    ],
    averageSpeed: 2.8,
    maxSpeed: 4.2,
    timestamp: 1625097600000, // July 1, 2021
    weather: {
      temperature: 22,
      conditions: "Sunny",
      windSpeed: 5,
    },
    photos: [
      "https://images.unsplash.com/photo-1551632811-561732d1e306",
      "https://images.unsplash.com/photo-1552521684-edc2a078660e",
    ],
    rating: 4.8,
    difficulty: "Moderate",
  },
  {
    id: "stravl-2",
    userId: "user-1",
    activityType: "cycling",
    distance: 25.3,
    duration: 5400, // 1.5 hours in seconds
    elevationGain: 320,
    startPoint: {
      latitude: 37.7749,
      longitude: -122.4194,
    },
    endPoint: {
      latitude: 37.8288,
      longitude: -122.4814,
    },
    routePoints: [
      { latitude: 37.7749, longitude: -122.4194, elevation: 10, timestamp: 1625184000000 },
      { latitude: 37.7949, longitude: -122.4394, elevation: 100, timestamp: 1625185800000 },
      { latitude: 37.8149, longitude: -122.4594, elevation: 200, timestamp: 1625187600000 },
      { latitude: 37.8288, longitude: -122.4814, elevation: 330, timestamp: 1625189400000 },
    ],
    averageSpeed: 16.8,
    maxSpeed: 28.5,
    timestamp: 1625184000000, // July 2, 2021
    weather: {
      temperature: 20,
      conditions: "Partly Cloudy",
      windSpeed: 8,
    },
    photos: ["https://images.unsplash.com/photo-1541625602330-2277a4c46182"],
    rating: 4.5,
    difficulty: "Moderate",
  },
  // More mock data...
]

// Mock data for Booking.com Multi-Destination Trips
const mockBookingDestinations: BookingDestination[] = [
  {
    id: "dest-1",
    name: "San Francisco",
    type: "city",
    country: "United States",
    countryCode: "US",
    coordinates: {
      latitude: 37.7749,
      longitude: -122.4194,
    },
    popularity: 9.2,
    accommodations: 1245,
    averagePrice: 250,
    seasonality: {
      highSeason: ["Jun", "Jul", "Aug", "Sep"],
      lowSeason: ["Jan", "Feb", "Nov", "Dec"],
    },
    tags: ["urban", "coastal", "food", "culture"],
    image: "https://images.unsplash.com/photo-1501594907352-04cda38ebc29",
  },
  {
    id: "dest-2",
    name: "Yosemite National Park",
    type: "landmark",
    country: "United States",
    countryCode: "US",
    coordinates: {
      latitude: 37.8651,
      longitude: -119.5383,
    },
    popularity: 8.9,
    accommodations: 87,
    averagePrice: 180,
    seasonality: {
      highSeason: ["Jun", "Jul", "Aug"],
      lowSeason: ["Nov", "Dec", "Jan", "Feb"],
    },
    tags: ["nature", "hiking", "outdoor", "scenic"],
    image: "https://images.unsplash.com/photo-1472396961693-142e6e269027",
  },
  // More destinations...
]

const mockBookingTrips: BookingTrip[] = [
  {
    id: "trip-1",
    userId: "user-1",
    destinations: [mockBookingDestinations[0], mockBookingDestinations[1]],
    startDate: "2023-07-10",
    endDate: "2023-07-17",
    totalPrice: 1850,
    accommodations: [
      {
        id: "acc-1",
        name: "Urban Hotel SF",
        type: "hotel",
        price: 220,
        rating: 4.3,
        location: {
          latitude: 37.7833,
          longitude: -122.4167,
        },
        checkIn: "2023-07-10",
        checkOut: "2023-07-13",
        amenities: ["wifi", "breakfast", "pool", "fitness center"],
        image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
      },
      {
        id: "acc-2",
        name: "Yosemite Lodge",
        type: "lodge",
        price: 180,
        rating: 4.5,
        location: {
          latitude: 37.8651,
          longitude: -119.5383,
        },
        checkIn: "2023-07-13",
        checkOut: "2023-07-17",
        amenities: ["wifi", "parking", "restaurant"],
        image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4",
      },
    ],
    transportation: [
      {
        type: "flight",
        from: "JFK",
        to: "SFO",
        departureTime: "2023-07-10T08:00:00",
        arrivalTime: "2023-07-10T11:30:00",
        price: 450,
        provider: "Delta Airlines",
      },
      {
        type: "car_rental",
        from: "San Francisco",
        to: "Yosemite",
        departureTime: "2023-07-13T10:00:00",
        arrivalTime: "2023-07-13T13:00:00",
        price: 200,
        provider: "Hertz",
      },
      {
        type: "flight",
        from: "SFO",
        to: "JFK",
        departureTime: "2023-07-17T18:00:00",
        arrivalTime: "2023-07-18T02:30:00",
        price: 480,
        provider: "United Airlines",
      },
    ],
    activities: [
      {
        id: "act-1",
        name: "Alcatraz Tour",
        type: "sightseeing",
        price: 40,
        date: "2023-07-11",
        duration: 180,
        location: {
          latitude: 37.8267,
          longitude: -122.4233,
        },
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1541943869728-4bd4f450c8f5",
      },
      {
        id: "act-2",
        name: "Yosemite Valley Hike",
        type: "outdoor",
        price: 0,
        date: "2023-07-14",
        duration: 300,
        location: {
          latitude: 37.7465,
          longitude: -119.5332,
        },
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1551632811-561732d1e306",
      },
    ],
  },
  // More trips...
]

// Mock data for OpenTravelData
const mockOPTDLocations: OPTDLocation[] = [
  {
    iataCode: "SFO",
    name: "San Francisco International Airport",
    city: "San Francisco",
    countryCode: "US",
    countryName: "United States",
    coordinates: {
      latitude: 37.6213,
      longitude: -122.379,
    },
    timezone: "America/Los_Angeles",
    type: "airport",
    popularity: 9.5,
    facilities: ["restaurants", "shops", "lounges", "wifi", "charging_stations"],
  },
  {
    iataCode: "JFK",
    name: "John F. Kennedy International Airport",
    city: "New York",
    countryCode: "US",
    countryName: "United States",
    coordinates: {
      latitude: 40.6413,
      longitude: -73.7781,
    },
    timezone: "America/New_York",
    type: "airport",
    popularity: 9.7,
    facilities: ["restaurants", "shops", "lounges", "wifi", "charging_stations", "spa"],
  },
  // More locations...
]

// Mock data for India Tourism
const mockIndiaTourismData: IndiaTourismData[] = [
  {
    year: 2019,
    month: "January",
    state: "Rajasthan",
    domesticVisitors: 1250000,
    foreignVisitors: 180000,
    totalVisitors: 1430000,
    topAttractions: ["Jaipur", "Udaipur", "Jaisalmer", "Jodhpur"],
    averageStay: 4.5,
    seasonality: "High",
    revenue: 320000000,
  },
  {
    year: 2019,
    month: "February",
    state: "Rajasthan",
    domesticVisitors: 1180000,
    foreignVisitors: 165000,
    totalVisitors: 1345000,
    topAttractions: ["Jaipur", "Udaipur", "Jaisalmer", "Jodhpur"],
    averageStay: 4.3,
    seasonality: "High",
    revenue: 305000000,
  },
  // More tourism data...
]

// Mock data for Travel Recommendations
const mockTravelRecommendations: TravelRecommendation[] = [
  {
    id: "rec-1",
    destination: "San Francisco",
    country: "United States",
    coordinates: {
      latitude: 37.7749,
      longitude: -122.4194,
    },
    recommendationType: "destination",
    category: ["urban", "coastal", "cultural"],
    rating: 4.8,
    priceLevel: 3,
    bestTimeToVisit: ["Sep", "Oct"],
    description:
      "San Francisco, officially the City and County of San Francisco, is a cultural, commercial, and financial center in Northern California.",
    tags: ["Golden Gate Bridge", "Alcatraz", "Fisherman's Wharf", "Cable Cars"],
    similarPlaces: ["Seattle", "Portland", "Vancouver"],
    image: "https://images.unsplash.com/photo-1501594907352-04cda38ebc29",
  },
  {
    id: "rec-2",
    destination: "Yosemite National Park",
    country: "United States",
    coordinates: {
      latitude: 37.8651,
      longitude: -119.5383,
    },
    recommendationType: "destination",
    category: ["nature", "outdoor", "hiking"],
    rating: 4.9,
    priceLevel: 2,
    bestTimeToVisit: ["May", "Jun", "Sep"],
    description:
      "Yosemite National Park is in California's Sierra Nevada mountains. It's famed for its giant, ancient sequoia trees, and for Tunnel View, the iconic vista of towering Bridalveil Fall and the granite cliffs of El Capitan and Half Dome.",
    tags: ["Hiking", "Waterfalls", "Rock Climbing", "Camping"],
    similarPlaces: ["Yellowstone", "Grand Canyon", "Zion"],
    image: "https://images.unsplash.com/photo-1472396961693-142e6e269027",
  },
  // More recommendations...
]

// Function to check if cache is expired
const isCacheExpired = async (key: string): Promise<boolean> => {
  try {
    const timestamp = await AsyncStorage.getItem(`${key}:timestamp`)
    if (!timestamp) return true

    const cachedTime = Number.parseInt(timestamp, 10)
    const currentTime = Date.now()
    return currentTime - cachedTime > CACHE_EXPIRATION
  } catch (error) {
    console.error(`Error checking cache expiration for ${key}:`, error)
    return true
  }
}

// Function to set cache with timestamp
const setCache = async (key: string, data: any): Promise<void> => {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(data))
    await AsyncStorage.setItem(`${key}:timestamp`, Date.now().toString())
  } catch (error) {
    console.error(`Error setting cache for ${key}:`, error)
  }
}

// Function to get cache\
const getCache = async <T>(key: string)
: Promise<T | null> =>
{
  try {
    const isExpired = await isCacheExpired(key)
    if (isExpired) return null

    const data = await AsyncStorage.getItem(key)
    return data ? JSON.parse(data) : null
  } catch (error) {
    console.error(`Error getting cache for ${key}:`, error)
    return null
  }
}

// Stravl-Data API
export const getStravlData = async (userId: string): Promise<StravlDataPoint[]> => {
  try {
    // Check cache first
    const cachedData = await getCache<StravlDataPoint[]>(CACHE_KEYS.STRAVL_DATA)
    if (cachedData) {
      return cachedData.filter((data) => data.userId === userId)
    }

    // Simulate API call
    await delay(1500)

    // In a real app, this would be an API call to fetch Stravl data
    const filteredData = mockStravlData.filter((data) => data.userId === userId)

    // Cache the data
    await setCache(CACHE_KEYS.STRAVL_DATA, mockStravlData)

    return filteredData
  } catch (error) {
    console.error("Error fetching Stravl data:", error)
    throw error
  }
}

export const getStravlDataByActivity = async (activityType: string): Promise<StravlDataPoint[]> => {
  try {
    // Check cache first
    const cachedData = await getCache<StravlDataPoint[]>(CACHE_KEYS.STRAVL_DATA)
    if (cachedData) {
      return cachedData.filter((data) => data.activityType === activityType)
    }

    // Simulate API call
    await delay(1500)

    // In a real app, this would be an API call to fetch Stravl data
    const filteredData = mockStravlData.filter((data) => data.activityType === activityType)

    // Cache the data
    await setCache(CACHE_KEYS.STRAVL_DATA, mockStravlData)

    return filteredData
  } catch (error) {
    console.error("Error fetching Stravl data by activity:", error)
    throw error
  }
}

// Booking.com Multi-Destination Trips API
export const getBookingDestinations = async (query?: string): Promise<BookingDestination[]> => {
  try {
    // Check cache first
    const cachedData = await getCache<BookingDestination[]>(CACHE_KEYS.BOOKING_DESTINATIONS)
    if (cachedData) {
      if (!query) return cachedData
      return cachedData.filter(
        (dest) =>
          dest.name.toLowerCase().includes(query.toLowerCase()) ||
          dest.country.toLowerCase().includes(query.toLowerCase()) ||
          dest.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase())),
      )
    }

    // Simulate API call
    await delay(1800)

    // In a real app, this would be an API call to fetch Booking.com destinations
    let filteredData = mockBookingDestinations
    if (query) {
      filteredData = mockBookingDestinations.filter(
        (dest) =>
          dest.name.toLowerCase().includes(query.toLowerCase()) ||
          dest.country.toLowerCase().includes(query.toLowerCase()) ||
          dest.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase())),
      )
    }

    // Cache the data
    await setCache(CACHE_KEYS.BOOKING_DESTINATIONS, mockBookingDestinations)

    return filteredData
  } catch (error) {
    console.error("Error fetching Booking.com destinations:", error)
    throw error
  }
}

export const getBookingTrips = async (userId: string): Promise<BookingTrip[]> => {
  try {
    // Check cache first
    const cachedData = await getCache<BookingTrip[]>(CACHE_KEYS.BOOKING_TRIPS)
    if (cachedData) {
      return cachedData.filter((trip) => trip.userId === userId)
    }

    // Simulate API call
    await delay(1500)

    // In a real app, this would be an API call to fetch Booking.com trips
    const filteredData = mockBookingTrips.filter((trip) => trip.userId === userId)

    // Cache the data
    await setCache(CACHE_KEYS.BOOKING_TRIPS, mockBookingTrips)

    return filteredData
  } catch (error) {
    console.error("Error fetching Booking.com trips:", error)
    throw error
  }
}

// OpenTravelData API
export const getOPTDLocations = async (query?: string): Promise<OPTDLocation[]> => {
  try {
    // Check cache first
    const cachedData = await getCache<OPTDLocation[]>(CACHE_KEYS.OPTD_LOCATIONS)
    if (cachedData) {
      if (!query) return cachedData
      return cachedData.filter(
        (loc) =>
          loc.name.toLowerCase().includes(query.toLowerCase()) ||
          loc.city.toLowerCase().includes(query.toLowerCase()) ||
          loc.iataCode.toLowerCase().includes(query.toLowerCase()),
      )
    }

    // Simulate API call
    await delay(1200)

    // In a real app, this would be an API call to fetch OPTD locations
    let filteredData = mockOPTDLocations
    if (query) {
      filteredData = mockOPTDLocations.filter(
        (loc) =>
          loc.name.toLowerCase().includes(query.toLowerCase()) ||
          loc.city.toLowerCase().includes(query.toLowerCase()) ||
          loc.iataCode.toLowerCase().includes(query.toLowerCase()),
      )
    }

    // Cache the data
    await setCache(CACHE_KEYS.OPTD_LOCATIONS, mockOPTDLocations)

    return filteredData
  } catch (error) {
    console.error("Error fetching OPTD locations:", error)
    throw error
  }
}

// India Tourism API
export const getIndiaTourismData = async (
  year?: number,
  month?: string,
  state?: string,
): Promise<IndiaTourismData[]> => {
  try {
    // Check cache first
    const cachedData = await getCache<IndiaTourismData[]>(CACHE_KEYS.INDIA_TOURISM)
    if (cachedData) {
      let filteredData = cachedData
      if (year) filteredData = filteredData.filter((data) => data.year === year)
      if (month) filteredData = filteredData.filter((data) => data.month === month)
      if (state) filteredData = filteredData.filter((data) => data.state === state)
      return filteredData
    }

    // Simulate API call
    await delay(2000)

    // In a real app, this would be an API call to fetch India Tourism data
    let filteredData = mockIndiaTourismData
    if (year) filteredData = filteredData.filter((data) => data.year === year)
    if (month) filteredData = filteredData.filter((data) => data.month === month)
    if (state) filteredData = filteredData.filter((data) => data.state === state)

    // Cache the data
    await setCache(CACHE_KEYS.INDIA_TOURISM, mockIndiaTourismData)

    return filteredData
  } catch (error) {
    console.error("Error fetching India Tourism data:", error)
    throw error
  }
}

// Travel Recommendation API
export const getTravelRecommendations = async (
  preferences?: string[],
  budget?: number,
): Promise<TravelRecommendation[]> => {
  try {
    // Check cache first
    const cachedData = await getCache<TravelRecommendation[]>(CACHE_KEYS.TRAVEL_RECOMMENDATIONS)
    if (cachedData) {
      let filteredData = cachedData
      if (preferences && preferences.length > 0) {
        filteredData = filteredData.filter(
          (rec) =>
            rec.category.some((cat) => preferences.includes(cat)) || rec.tags.some((tag) => preferences.includes(tag)),
        )
      }
      if (budget) {
        filteredData = filteredData.filter((rec) => rec.priceLevel <= budget)
      }
      return filteredData
    }

    // Simulate API call
    await delay(1700)

    // In a real app, this would be an API call to fetch travel recommendations
    let filteredData = mockTravelRecommendations
    if (preferences && preferences.length > 0) {
      filteredData = filteredData.filter(
        (rec) =>
          rec.category.some((cat) => preferences.includes(cat)) || rec.tags.some((tag) => preferences.includes(tag)),
      )
    }
    if (budget) {
      filteredData = filteredData.filter((rec) => rec.priceLevel <= budget)
    }

    // Cache the data
    await setCache(CACHE_KEYS.TRAVEL_RECOMMENDATIONS, mockTravelRecommendations)

    return filteredData
  } catch (error) {
    console.error("Error fetching travel recommendations:", error)
    throw error
  }
}

// Combined data functions
export const getDestinationDetails = async (
  destinationName: string,
): Promise<{
  bookingData?: BookingDestination
  recommendations?: TravelRecommendation[]
  indiaTourism?: IndiaTourismData[]
}> => {
  try {
    // Fetch data from multiple sources in parallel
    const [bookingData, recommendations, indiaTourism] = await Promise.all([
      getBookingDestinations(destinationName),
      getTravelRecommendations([destinationName]),
      getIndiaTourismData(undefined, undefined, destinationName),
    ])

    return {
      bookingData: bookingData.length > 0 ? bookingData[0] : undefined,
      recommendations,
      indiaTourism,
    }
  } catch (error) {
    console.error("Error fetching destination details:", error)
    throw error
  }
}

export const getRouteRecommendations = async (
  startLocation: string,
  endLocation: string,
): Promise<{
  stravlRoutes?: StravlDataPoint[]
  bookingTrips?: BookingTrip[]
}> => {
  try {
    // Fetch data from multiple sources in parallel
    const [stravlData, bookingTrips] = await Promise.all([
      getStravlDataByActivity("hiking"), // Assuming we're looking for hiking routes
      getBookingTrips("user-1"), // Using a mock user ID
    ])

    // Filter Stravl routes that might be relevant
    // In a real app, this would use more sophisticated matching
    const relevantStravlRoutes = stravlData.filter(
      (route) =>
        route.startPoint.latitude.toFixed(1) === Number.parseFloat(startLocation.split(",")[0]).toFixed(1) ||
        route.endPoint.latitude.toFixed(1) === Number.parseFloat(endLocation.split(",")[0]).toFixed(1),
    )

    // Filter booking trips that might be relevant
    // In a real app, this would use more sophisticated matching
    const relevantBookingTrips = bookingTrips.filter((trip) =>
      trip.destinations.some(
        (dest) =>
          dest.name.toLowerCase().includes(startLocation.toLowerCase()) ||
          dest.name.toLowerCase().includes(endLocation.toLowerCase()),
      ),
    )

    return {
      stravlRoutes: relevantStravlRoutes,
      bookingTrips: relevantBookingTrips,
    }
  } catch (error) {
    console.error("Error fetching route recommendations:", error)
    throw error
  }
}

export const searchAcrossDatasets = async (
  query: string,
): Promise<{
  bookingDestinations: BookingDestination[]
  optdLocations: OPTDLocation[]
  travelRecommendations: TravelRecommendation[]
}> => {
  try {
    // Fetch data from multiple sources in parallel
    const [bookingDestinations, optdLocations, travelRecommendations] = await Promise.all([
      getBookingDestinations(query),
      getOPTDLocations(query),
      getTravelRecommendations([query]),
    ])

    return {
      bookingDestinations,
      optdLocations,
      travelRecommendations,
    }
  } catch (error) {
    console.error("Error searching across datasets:", error)
    throw error
  }
}

// Export all mock data for testing purposes
export const getMockData = () => ({
  stravlData: mockStravlData,
  bookingDestinations: mockBookingDestinations,
  bookingTrips: mockBookingTrips,
  optdLocations: mockOPTDLocations,
  indiaTourismData: mockIndiaTourismData,
  travelRecommendations: mockTravelRecommendations,
})
