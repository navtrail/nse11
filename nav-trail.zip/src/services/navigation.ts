import AsyncStorage from "@react-native-async-storage/async-storage"

// Mock delay to simulate network request
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Mock directions data
const mockDirectionsData = {
  origin: { latitude: 37.7749, longitude: -122.4194 },
  destination: { latitude: 37.7917, longitude: -122.4091 },
  distance: 5.2, // km
  duration: 1200, // seconds
  route: [
    { latitude: 37.7749, longitude: -122.4194 },
    { latitude: 37.7753, longitude: -122.4181 },
    { latitude: 37.7775, longitude: -122.4179 },
    { latitude: 37.7791, longitude: -122.4164 },
    { latitude: 37.7812, longitude: -122.4148 },
    { latitude: 37.7835, longitude: -122.4131 },
    { latitude: 37.7851, longitude: -122.4119 },
    { latitude: 37.7874, longitude: -122.4105 },
    { latitude: 37.7891, longitude: -122.4097 },
    { latitude: 37.7917, longitude: -122.4091 },
  ],
  steps: [
    {
      distance: 0.3,
      duration: 60,
      instruction: "Head north on Market Street",
      maneuver: "straight",
      startLocation: { latitude: 37.7749, longitude: -122.4194 },
    },
    {
      distance: 0.8,
      duration: 180,
      instruction: "Turn right onto California Street",
      maneuver: "turn-right",
      startLocation: { latitude: 37.7775, longitude: -122.4179 },
    },
    {
      distance: 1.2,
      duration: 240,
      instruction: "Turn left onto Montgomery Street",
      maneuver: "turn-left",
      startLocation: { latitude: 37.7812, longitude: -122.4148 },
    },
    {
      distance: 1.5,
      duration: 300,
      instruction: "Continue onto Columbus Avenue",
      maneuver: "straight",
      startLocation: { latitude: 37.7851, longitude: -122.4119 },
    },
    {
      distance: 1.4,
      duration: 420,
      instruction: "Your destination will be on the right",
      maneuver: "arrive",
      startLocation: { latitude: 37.7891, longitude: -122.4097 },
    },
  ],
  alternateRoutes: [
    {
      distance: 5.8,
      duration: 1320,
      route: [
        { latitude: 37.7749, longitude: -122.4194 },
        { latitude: 37.7753, longitude: -122.4181 },
        { latitude: 37.7775, longitude: -122.4179 },
        { latitude: 37.7791, longitude: -122.4164 },
        { latitude: 37.7812, longitude: -122.4148 },
        { latitude: 37.7835, longitude: -122.4131 },
        { latitude: 37.7851, longitude: -122.4119 },
        { latitude: 37.7874, longitude: -122.4105 },
        { latitude: 37.7891, longitude: -122.4097 },
        { latitude: 37.7917, longitude: -122.4091 },
      ],
    },
    {
      distance: 6.1,
      duration: 1380,
      route: [
        { latitude: 37.7749, longitude: -122.4194 },
        { latitude: 37.7753, longitude: -122.4181 },
        { latitude: 37.7775, longitude: -122.4179 },
        { latitude: 37.7791, longitude: -122.4164 },
        { latitude: 37.7812, longitude: -122.4148 },
        { latitude: 37.7835, longitude: -122.4131 },
        { latitude: 37.7851, longitude: -122.4119 },
        { latitude: 37.7874, longitude: -122.4105 },
        { latitude: 37.7891, longitude: -122.4097 },
        { latitude: 37.7917, longitude: -122.4091 },
      ],
    },
  ],
}

// Mock traffic data
const mockTrafficData = {
  segments: [
    {
      coordinates: [
        { latitude: 37.7749, longitude: -122.4194 },
        { latitude: 37.7753, longitude: -122.4181 },
        { latitude: 37.7775, longitude: -122.4179 },
      ],
      level: "light",
    },
    {
      coordinates: [
        { latitude: 37.7775, longitude: -122.4179 },
        { latitude: 37.7791, longitude: -122.4164 },
        { latitude: 37.7812, longitude: -122.4148 },
      ],
      level: "moderate",
    },
    {
      coordinates: [
        { latitude: 37.7812, longitude: -122.4148 },
        { latitude: 37.7835, longitude: -122.4131 },
        { latitude: 37.7851, longitude: -122.4119 },
      ],
      level: "heavy",
    },
    {
      coordinates: [
        { latitude: 37.7851, longitude: -122.4119 },
        { latitude: 37.7874, longitude: -122.4105 },
        { latitude: 37.7891, longitude: -122.4097 },
        { latitude: 37.7917, longitude: -122.4091 },
      ],
      level: "light",
    },
  ],
}

// Get directions between two points
export const getDirections = async (origin, destination, mode = "driving") => {
  // Check if offline maps are enabled and if we have cached directions
  const offlineMapsEnabled = await AsyncStorage.getItem("settings:offlineMaps")
  const cacheKey = `directions:${origin.latitude},${origin.longitude}:${destination.latitude},${destination.longitude}:${mode}`

  if (offlineMapsEnabled === "true") {
    const cachedDirections = await AsyncStorage.getItem(cacheKey)
    if (cachedDirections) {
      return JSON.parse(cachedDirections)
    }
  }

  // Simulate API call
  await delay(1500)

  // In a real app, this would call a directions API like Google Maps, Mapbox, etc.
  // For this mock, we'll return predefined data
  const directionsData = { ...mockDirectionsData }

  // Cache the directions for offline use
  if (offlineMapsEnabled === "true") {
    await AsyncStorage.setItem(cacheKey, JSON.stringify(directionsData))
  }

  return directionsData
}

// Get traffic information for a route
export const getTrafficInfo = async (route) => {
  // Simulate API call
  await delay(1000)

  // In a real app, this would call a traffic API
  // For this mock, we'll return predefined data
  return mockTrafficData
}

// Get public transport options
export const getPublicTransport = async (origin, destination) => {
  // Simulate API call
  await delay(1200)

  // Mock public transport data
  const publicTransportData = {
    routes: [
      {
        type: "bus",
        line: "38R",
        departureTime: new Date(Date.now() + 5 * 60 * 1000).toLocaleTimeString(),
        arrivalTime: new Date(Date.now() + 35 * 60 * 1000).toLocaleTimeString(),
        duration: 30, // minutes
        fare: 2.5,
        steps: [
          {
            type: "walk",
            instruction: "Walk to Geary Blvd & Powell St",
            duration: 5,
          },
          {
            type: "bus",
            line: "38R",
            instruction: "Take 38R bus towards VA Hospital",
            duration: 20,
          },
          {
            type: "walk",
            instruction: "Walk to destination",
            duration: 5,
          },
        ],
      },
      {
        type: "subway",
        line: "N",
        departureTime: new Date(Date.now() + 8 * 60 * 1000).toLocaleTimeString(),
        arrivalTime: new Date(Date.now() + 28 * 60 * 1000).toLocaleTimeString(),
        duration: 20, // minutes
        fare: 3.0,
        steps: [
          {
            type: "walk",
            instruction: "Walk to Powell St Station",
            duration: 7,
          },
          {
            type: "subway",
            line: "N",
            instruction: "Take N train towards Ocean Beach",
            duration: 10,
          },
          {
            type: "walk",
            instruction: "Walk to destination",
            duration: 3,
          },
        ],
      },
    ],
  }

  return publicTransportData
}

// Get walking directions
export const getWalkingDirections = async (origin, destination) => {
  // Simulate API call
  await delay(1000)

  // Mock walking directions
  const walkingDirections = {
    distance: 2.3, // km
    duration: 1800, // seconds
    calories: 180,
    steps: 3000,
    route: [
      { latitude: 37.7749, longitude: -122.4194 },
      { latitude: 37.7753, longitude: -122.4181 },
      { latitude: 37.7775, longitude: -122.4179 },
      { latitude: 37.7791, longitude: -122.4164 },
      { latitude: 37.7812, longitude: -122.4148 },
      { latitude: 37.7835, longitude: -122.4131 },
      { latitude: 37.7851, longitude: -122.4119 },
      { latitude: 37.7874, longitude: -122.4105 },
      { latitude: 37.7891, longitude: -122.4097 },
      { latitude: 37.7917, longitude: -122.4091 },
    ],
    instructions: [
      {
        distance: 0.3,
        duration: 240,
        instruction: "Head north on Market Street",
        startLocation: { latitude: 37.7749, longitude: -122.4194 },
      },
      {
        distance: 0.8,
        duration: 600,
        instruction: "Turn right onto California Street",
        startLocation: { latitude: 37.7775, longitude: -122.4179 },
      },
      {
        distance: 1.2,
        duration: 960,
        instruction: "Your destination will be on the right",
        startLocation: { latitude: 37.7891, longitude: -122.4097 },
      },
    ],
  }

  return walkingDirections
}

// Optimize route based on preferences
export const optimizeRoute = async (waypoints, preferences = {}) => {
  // Simulate API call
  await delay(2000)

  // Mock optimized route
  const optimizedRoute = {
    waypoints: waypoints.sort(() => Math.random() - 0.5), // Randomly reorder waypoints for mock
    totalDistance: 15.3, // km
    totalDuration: 3600, // seconds
    route: [], // This would be the full route connecting all waypoints
  }

  return optimizedRoute
}

// Get speed limits for a route
export const getSpeedLimits = async (route) => {
  // Simulate API call
  await delay(800)

  // Mock speed limits
  const speedLimits = [
    {
      segment: [0, 3], // Indices in the route array
      limit: 25, // mph
    },
    {
      segment: [3, 6],
      limit: 35,
    },
    {
      segment: [6, 10],
      limit: 45,
    },
  ]

  return speedLimits
}
