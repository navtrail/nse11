import { DestinationService } from "./destination-service"
import { NavigationService } from "./navigation-service"
import { AccommodationService } from "./accommodation-service"
import { WeatherService } from "./weather-service"
import { UserPreferencesService } from "./user-preferences-service"
import { UtilityService } from "./utility-service"
import { TravelPackageService } from "./travel-package-service"
import { AnalyticsService } from "./analytics-service"
import type { DataIntegrationConfig } from "./types"

// Create instances of all services
const destinationService = new DestinationService()
const navigationService = new NavigationService()
const accommodationService = new AccommodationService()
const weatherService = new WeatherService()
const userPreferencesService = new UserPreferencesService()
const utilityService = new UtilityService()
const travelPackageService = new TravelPackageService()
const analyticsService = new AnalyticsService()

// Export all services
export {
  destinationService,
  navigationService,
  accommodationService,
  weatherService,
  userPreferencesService,
  utilityService,
  travelPackageService,
  analyticsService,
}

// Initialize all services with configuration
export const initializeDataIntegration = (config: DataIntegrationConfig) => {
  destinationService.initialize(config)
  navigationService.initialize(config)
  accommodationService.initialize(config)
  weatherService.initialize(config)
  userPreferencesService.initialize(config)
  utilityService.initialize(config)
  travelPackageService.initialize(config)
  analyticsService.initialize(config)

  console.log("Data integration services initialized successfully")
}

// Export types
export * from "./types"
