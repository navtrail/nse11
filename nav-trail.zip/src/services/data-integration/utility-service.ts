import type { CurrencyRate, LanguagePhrase } from "./types"

// Mock data for currency rates
const mockCurrencyRates: CurrencyRate[] = [
  {
    base: "USD",
    target: "EUR",
    rate: 0.92,
    timestamp: new Date(),
  },
  {
    base: "USD",
    target: "JPY",
    rate: 149.5,
    timestamp: new Date(),
  },
  {
    base: "USD",
    target: "GBP",
    rate: 0.79,
    timestamp: new Date(),
  },
  {
    base: "USD",
    target: "AUD",
    rate: 1.52,
    timestamp: new Date(),
  },
  {
    base: "USD",
    target: "CAD",
    rate: 1.36,
    timestamp: new Date(),
  },
  {
    base: "USD",
    target: "CHF",
    rate: 0.89,
    timestamp: new Date(),
  },
  {
    base: "USD",
    target: "CNY",
    rate: 7.24,
    timestamp: new Date(),
  },
  {
    base: "USD",
    target: "INR",
    rate: 83.12,
    timestamp: new Date(),
  },
  {
    base: "USD",
    target: "BRL",
    rate: 5.05,
    timestamp: new Date(),
  },
  {
    base: "USD",
    target: "ZAR",
    rate: 18.65,
    timestamp: new Date(),
  },
]

// Mock data for language phrases
const mockLanguagePhrases: LanguagePhrase[] = [
  {
    id: "phrase-001",
    language: "French",
    category: "Greetings",
    phrase: "Hello",
    translation: "Bonjour",
    pronunciation: "bohn-zhoor",
    audioUrl: "https://example.com/audio/french/bonjour.mp3",
  },
  {
    id: "phrase-002",
    language: "French",
    category: "Greetings",
    phrase: "Goodbye",
    translation: "Au revoir",
    pronunciation: "oh ruh-vwahr",
    audioUrl: "https://example.com/audio/french/aurevoir.mp3",
  },
  {
    id: "phrase-003",
    language: "French",
    category: "Basics",
    phrase: "Please",
    translation: "S'il vous plaît",
    pronunciation: "seel voo pleh",
    audioUrl: "https://example.com/audio/french/silvousplait.mp3",
  },
  {
    id: "phrase-004",
    language: "French",
    category: "Basics",
    phrase: "Thank you",
    translation: "Merci",
    pronunciation: "mehr-see",
    audioUrl: "https://example.com/audio/french/merci.mp3",
  },
  {
    id: "phrase-005",
    language: "French",
    category: "Dining",
    phrase: "The bill, please",
    translation: "L'addition, s'il vous plaît",\
