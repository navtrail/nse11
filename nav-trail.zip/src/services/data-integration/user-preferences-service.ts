import type {
  UserProfile,
  UserSearchHistory,
  UserTrip,
  SavedItem,
  TravelStyle,
  SearchFilters,
  PaginatedResult,
} from "./types"
import { delay, generateId } from "./utils"

// Mock data for user profiles
const mockUserProfiles: UserProfile[] = [
  {
    id: "user-001",
    email: "john.doe@example.com",
    displayName: "John Doe",
    photoURL: "https://randomuser.me/api/portraits/men/1.jpg",
    homeCountry: "United States",
    language: "English",
    dateOfBirth: new Date("1985-05-15"),
    gender: "Male",
    travelStyle: ["adventure", "cultural", "budget"],
    interests: ["hiking", "photography", "history", "local cuisine"],
    dietaryPreferences: ["vegetarian"],
    accessibilityNeeds: [],
    createdAt: new Date("2022-01-01T00:00:00Z"),
    updatedAt: new Date("2023-05-15T00:00:00Z"),
  },
  {
    id: "user-002",
    email: "jane.smith@example.com",
    displayName: "Jane Smith",
    photoURL: "https://randomuser.me/api/portraits/women/2.jpg",
    homeCountry: "United Kingdom",
    language: "English",
    dateOfBirth: new Date("1990-08-22"),
    gender: "Female",
    travelStyle: ["luxury", "relaxation"],
    interests: ["spa", "shopping", "fine dining", "art"],
    dietaryPreferences: ["gluten-free"],
    accessibilityNeeds: [],
    createdAt: new Date("2022-02-15T00:00:00Z"),
    updatedAt: new Date("2023-04-20T00:00:00Z"),
  },
]

// Mock data for user search history
const mockSearchHistory: UserSearchHistory[] = [
  {
    id: "search-001",
    userId: "user-001",
    query: "Paris hotels",
    filters: {
      priceRange: { min: 100, max: 300 },
      rating: 4,
    },
    timestamp: new Date("2023-05-10T10:30:00Z"),
    resultCount: 15,
  },
  {
    id: "search-002",
    userId: "user-001",
    query: "Eiffel Tower tickets",
    filters: {
      date: "2023-06-15",
    },
    timestamp: new Date("2023-05-10T11:15:00Z"),
    resultCount: 5,
  },
  {
    id: "search-003",
    userId: "user-002",
    query: "London luxury spa hotels",
    filters: {
      priceRange: { min: 300, max: 1000 },
      rating: 5,
      features: ["spa", "pool"],
    },
    timestamp: new Date("2023-04-15T14:20:00Z"),
    resultCount: 8,
  },
]

// Mock data for user trips
const mockTrips: UserTrip[] = [
  {
    id: "trip-001",
    userId: "user-001",
    name: "Paris Adventure",
    description: "Exploring the City of Light",
    startDate: new Date("2023-06-15"),
    endDate: new Date("2023-06-22"),
    destinations: [
      {
        city: "Paris",
        country: "France",
        coordinates: { latitude: 48.8566, longitude: 2.3522 },
        arrivalDate: new Date("2023-06-15"),
        departureDate: new Date("2023-06-22"),
      },
    ],
    accommodation: [
      {
        id: "acc-001",
        name: "Grand Hotel Paris",
        checkIn: new Date("2023-06-15"),
        checkOut: new Date("2023-06-22"),
      },
    ],
    activities: [
      {
        id: "act-001",
        name: "Visit Eiffel Tower",
        date: new Date("2023-06-16"),
        time: "10:00",
        duration: 3,
        notes: "Buy tickets in advance",
      },
      {
        id: "act-002",
        name: "Louvre Museum",
        date: new Date("2023-06-17"),
        time: "09:00",
        duration: 4,
        notes: "Focus on main exhibits",
      },
      {
        id: "act-003",
        name: "Seine River Cruise",
        date: new Date("2023-06-18"),
        time: "19:00",
        duration: 2,
        notes: "Sunset cruise",
      },
    ],
    transportation: [
      {
        type: "flight",
        from: "New York JFK",
        to: "Paris CDG",
        departureTime: new Date("2023-06-15T08:00:00Z"),
        arrivalTime: new Date("2023-06-15T20:00:00Z"),
        confirmationCode: "ABC123",
      },
      {
        type: "flight",
        from: "Paris CDG",
        to: "New York JFK",
        departureTime: new Date("2023-06-22T10:00:00Z"),
        arrivalTime: new Date("2023-06-22T13:00:00Z"),
        confirmationCode: "XYZ789",
      },
    ],
    budget: {
      amount: 3000,
      currency: "USD",
      spent: 2500,
    },
    notes: "Remember to bring adapter for French outlets",
    isPublic: false,
    collaborators: [],
    createdAt: new Date("2023-01-15T00:00:00Z"),
    updatedAt: new Date("2023-05-10T00:00:00Z"),
  },
  {
    id: "trip-002",
    userId: "user-002",
    name: "London Luxury Getaway",
    description: "Relaxing weekend in London",
    startDate: new Date("2023-07-07"),
    endDate: new Date("2023-07-09"),
    destinations: [
      {
        city: "London",
        country: "United Kingdom",
        coordinates: { latitude: 51.5074, longitude: -0.1278 },
        arrivalDate: new Date("2023-07-07"),
        departureDate: new Date("2023-07-09"),
      },
    ],
    accommodation: [
      {
        id: "acc-002",
        name: "The Ritz London",
        checkIn: new Date("2023-07-07"),
        checkOut: new Date("2023-07-09"),
      },
    ],
    activities: [
      {
        id: "act-004",
        name: "Spa Day",
        date: new Date("2023-07-08"),
        time: "10:00",
        duration: 4,
        notes: "Full treatment package",
      },
      {
        id: "act-005",
        name: "Afternoon Tea",
        date: new Date("2023-07-08"),
        time: "16:00",
        duration: 2,
        notes: "At The Ritz",
      },
    ],
    transportation: [
      {
        type: "train",
        from: "Manchester",
        to: "London",
        departureTime: new Date("2023-07-07T09:00:00Z"),
        arrivalTime: new Date("2023-07-07T11:30:00Z"),
        confirmationCode: "TRN456",
      },
      {
        type: "train",
        from: "London",
        to: "Manchester",
        departureTime: new Date("2023-07-09T18:00:00Z"),
        arrivalTime: new Date("2023-07-09T20:30:00Z"),
        confirmationCode: "TRN789",
      },
    ],
    budget: {
      amount: 2000,
      currency: "GBP",
      spent: 1800,
    },
    notes: "Dinner reservation at Gordon Ramsay on Saturday",
    isPublic: false,
    collaborators: [],
    createdAt: new Date("2023-03-01T00:00:00Z"),
    updatedAt: new Date("2023-04-15T00:00:00Z"),
  },
]

// Mock data for saved items
const mockSavedItems: SavedItem[] = [
  {
    id: "saved-001",
    userId: "user-001",
    itemType: "poi",
    itemId: "poi-001", // Eiffel Tower
    notes: "Must visit",
    savedAt: new Date("2023-05-05T00:00:00Z"),
  },
  {
    id: "saved-002",
    userId: "user-001",
    itemType: "restaurant",
    itemId: "rest-001", // Le Petit Bistro
    notes: "Recommended by friend",
    savedAt: new Date("2023-05-06T00:00:00Z"),
  },
  {
    id: "saved-003",
    userId: "user-002",
    itemType: "hotel",
    itemId: "acc-003", // Central Park View Hotel
    notes: "For next NYC trip",
    savedAt: new Date("2023-04-10T00:00:00Z"),
  },
]

// Get user profile
export const getUserProfile = async (userId: string): Promise<UserProfile | null> => {
  try {
    // Simulate API call
    await delay(500)

    const profile = mockUserProfiles.find((profile) => profile.id === userId)
    return profile || null
  } catch (error) {
    console.error(`Error fetching user profile for user ${userId}:`, error)
    throw error
  }
}

// Update user profile
export const updateUserProfile = async (userId: string, data: Partial<UserProfile>): Promise<UserProfile> => {
  try {
    // Simulate API call
    await delay(800)

    const profileIndex = mockUserProfiles.findIndex((profile) => profile.id === userId)
    if (profileIndex === -1) {
      throw new Error(`User with ID ${userId} not found`)
    }

    // Update profile
    const updatedProfile = {
      ...mockUserProfiles[profileIndex],
      ...data,
      updatedAt: new Date(),
    }

    mockUserProfiles[profileIndex] = updatedProfile

    return updatedProfile
  } catch (error) {
    console.error(`Error updating user profile for user ${userId}:`, error)
    throw error
  }
}

// Get user search history
export const getUserSearchHistory = async (
  userId: string,
  filters?: SearchFilters,
): Promise<PaginatedResult<UserSearchHistory>> => {
  try {
    // Simulate API call
    await delay(700)

    const userSearchHistory = mockSearchHistory.filter((search) => search.userId === userId)
    return filterAndPaginateSearchHistory(userSearchHistory, filters)
  } catch (error) {
    console.error(`Error fetching search history for user ${userId}:`, error)
    throw error
  }
}

// Add search to history
export const addSearchToHistory = async (
  userId: string,
  query: string,
  filters?: Record<string, any>,
  resultCount?: number,
): Promise<UserSearchHistory> => {
  try {
    // Simulate API call
    await delay(500)

    const newSearch: UserSearchHistory = {
      id: generateId(),
      userId,
      query,
      filters,
      timestamp: new Date(),
      resultCount,
    }

    mockSearchHistory.push(newSearch)

    return newSearch
  } catch (error) {
    console.error(`Error adding search to history for user ${userId}:`, error)
    throw error
  }
}

// Clear search history
export const clearSearchHistory = async (userId: string): Promise<boolean> => {
  try {
    // Simulate API call
    await delay(500)

    const initialLength = mockSearchHistory.length
    const newSearchHistory = mockSearchHistory.filter((search) => search.userId !== userId)
    mockSearchHistory.length = 0
    mockSearchHistory.push(...newSearchHistory)

    return initialLength !== mockSearchHistory.length
  } catch (error) {
    console.error(`Error clearing search history for user ${userId}:`, error)
    throw error
  }
}

// Get user trips
export const getUserTrips = async (userId: string, filters?: SearchFilters): Promise<PaginatedResult<UserTrip>> => {
  try {
    // Simulate API call
    await delay(800)

    const userTrips = mockTrips.filter((trip) => trip.userId === userId)
    return filterAndPaginateTrips(userTrips, filters)
  } catch (error) {
    console.error(`Error fetching trips for user ${userId}:`, error)
    throw error
  }
}

// Get trip by ID
export const getTripById = async (tripId: string): Promise<UserTrip | null> => {
  try {
    // Simulate API call
    await delay(500)

    const trip = mockTrips.find((trip) => trip.id === tripId)
    return trip || null
  } catch (error) {
    console.error(`Error fetching trip with ID ${tripId}:`, error)
    throw error
  }
}

// Create a new trip
export const createTrip = async (userId: string, tripData: Partial<UserTrip>): Promise<UserTrip> => {
  try {
    // Simulate API call
    await delay(1000)

    const newTrip: UserTrip = {
      id: generateId(),
      userId,
      name: tripData.name || "New Trip",
      description: tripData.description || "",
      startDate: tripData.startDate || new Date(),
      endDate: tripData.endDate || new Date(),
      destinations: tripData.destinations || [],
      accommodation: tripData.accommodation || [],
      activities: tripData.activities || [],
      transportation: tripData.transportation || [],
      budget: tripData.budget,
      notes: tripData.notes || "",
      isPublic: tripData.isPublic || false,
      collaborators: tripData.collaborators || [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    mockTrips.push(newTrip)

    return newTrip
  } catch (error) {
    console.error(`Error creating trip for user ${userId}:`, error)
    throw error
  }
}

// Update a trip
export const updateTrip = async (tripId: string, tripData: Partial<UserTrip>): Promise<UserTrip> => {
  try {
    // Simulate API call
    await delay(800)

    const tripIndex = mockTrips.findIndex((trip) => trip.id === tripId)
    if (tripIndex === -1) {
      throw new Error(`Trip with ID ${tripId} not found`)
    }

    // Update trip
    const updatedTrip = {
      ...mockTrips[tripIndex],
      ...tripData,
      updatedAt: new Date(),
    }

    mockTrips[tripIndex] = updatedTrip

    return updatedTrip
  } catch (error) {
    console.error(`Error updating trip with ID ${tripId}:`, error)
    throw error
  }
}

// Delete a trip
export const deleteTrip = async (tripId: string): Promise<boolean> => {
  try {
    // Simulate API call
    await delay(700)

    const tripIndex = mockTrips.findIndex((trip) => trip.id === tripId)
    if (tripIndex === -1) {
      return false
    }

    mockTrips.splice(tripIndex, 1)
    return true
  } catch (error) {
    console.error(`Error deleting trip with ID ${tripId}:`, error)
    throw error
  }
}

// Get saved items
export const getSavedItems = async (userId: string, filters?: SearchFilters): Promise<PaginatedResult<SavedItem>> => {
  try {
    // Simulate API call
    await delay(700)

    const userSavedItems = mockSavedItems.filter((item) => item.userId === userId)
    return filterAndPaginateSavedItems(userSavedItems, filters)
  } catch (error) {
    console.error(`Error fetching saved items for user ${userId}:`, error)
    throw error
  }
}

// Get saved items by type
export const getSavedItemsByType = async (
  userId: string,
  itemType: "poi" | "restaurant" | "hotel" | "event" | "route",
  filters?: SearchFilters,
): Promise<PaginatedResult<SavedItem>> => {
  try {
    // Simulate API call
    await delay(600)

    const userSavedItemsByType = mockSavedItems.filter((item) => item.userId === userId && item.itemType === itemType)
    return filterAndPaginateSavedItems(userSavedItemsByType, filters)
  } catch (error) {
    console.error(`Error fetching saved items of type ${itemType} for user ${userId}:`, error)
    throw error
  }
}

// Save an item
export const saveItem = async (
  userId: string,
  itemType: "poi" | "restaurant" | "hotel" | "event" | "route",
  itemId: string,
  notes?: string,
): Promise<SavedItem> => {
  try {
    // Simulate API call
    await delay(500)

    // Check if item is already saved
    const existingItem = mockSavedItems.find(
      (item) => item.userId === userId && item.itemType === itemType && item.itemId === itemId,
    )

    if (existingItem) {
      // Update notes if provided
      if (notes !== undefined) {
        existingItem.notes = notes
      }
      return existingItem
    }

    // Create new saved item
    const newSavedItem: SavedItem = {
      id: generateId(),
      userId,
      itemType,
      itemId,
      notes,
      savedAt: new Date(),
    }

    mockSavedItems.push(newSavedItem)

    return newSavedItem
  } catch (error) {
    console.error(`Error saving item for user ${userId}:`, error)
    throw error
  }
}

// Unsave an item
export const unsaveItem = async (userId: string, itemId: string): Promise<boolean> => {
  try {
    // Simulate API call
    await delay(500)

    const itemIndex = mockSavedItems.findIndex((item) => item.userId === userId && item.id === itemId)
    if (itemIndex === -1) {
      return false
    }

    mockSavedItems.splice(itemIndex, 1)
    return true
  } catch (error) {
    console.error(`Error unsaving item for user ${userId}:`, error)
    throw error
  }
}

// Get travel preferences
export const getTravelPreferences = async (
  userId: string,
): Promise<{
  travelStyle: TravelStyle[]
  interests: string[]
  dietaryPreferences: string[]
  accessibilityNeeds: string[]
} | null> => {
  try {
    // Simulate API call
    await delay(500)

    const profile = await getUserProfile(userId)
    if (!profile) {
      return null
    }

    return {
      travelStyle: profile.travelStyle || [],
      interests: profile.interests || [],
      dietaryPreferences: profile.dietaryPreferences || [],
      accessibilityNeeds: profile.accessibilityNeeds || [],
    }
  } catch (error) {
    console.error(`Error fetching travel preferences for user ${userId}:`, error)
    throw error
  }
}

// Update travel preferences
export const updateTravelPreferences = async (
  userId: string,
  preferences: {
    travelStyle?: TravelStyle[]
    interests?: string[]
    dietaryPreferences?: string[]
    accessibilityNeeds?: string[]
  },
): Promise<UserProfile> => {
  try {
    // Simulate API call
    await delay(700)

    return updateUserProfile(userId, preferences)
  } catch (error) {
    console.error(`Error updating travel preferences for user ${userId}:`, error)
    throw error
  }
}

// Helper function to filter and paginate search history
const filterAndPaginateSearchHistory = (
  searchHistory: UserSearchHistory[],
  filters?: SearchFilters,
): PaginatedResult<UserSearchHistory> => {
  const filteredSearchHistory = [...searchHistory]

  // Sort by timestamp (newest first)
  filteredSearchHistory.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())

  // Apply pagination
  const limit = filters?.limit || 10
  const offset = filters?.offset || 0
  const paginatedSearchHistory = filteredSearchHistory.slice(offset, offset + limit)

  return {
    items: paginatedSearchHistory,
    total: filteredSearchHistory.length,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit,
    hasMore: offset + limit < filteredSearchHistory.length,
  }
}

// Helper function to filter and paginate trips
const filterAndPaginateTrips = (trips: UserTrip[], filters?: SearchFilters): PaginatedResult<UserTrip> => {
  let filteredTrips = [...trips]

  if (filters) {
    // Apply query filter
    if (filters.query) {
      const query = filters.query.toLowerCase()
      filteredTrips = filteredTrips.filter(
        (trip) =>
          trip.name.toLowerCase().includes(query) ||
          trip.description?.toLowerCase().includes(query) ||
          trip.destinations.some(
            (dest) => dest.city.toLowerCase().includes(query) || dest.country.toLowerCase().includes(query),
          ),
      )
    }

    // Apply date filter (upcoming trips)
    if (filters.features && filters.features.includes("upcoming")) {
      const now = new Date()
      filteredTrips = filteredTrips.filter((trip) => trip.startDate >= now)
    }

    // Apply date filter (past trips)
    if (filters.features && filters.features.includes("past")) {
      const now = new Date()
      filteredTrips = filteredTrips.filter((trip) => trip.endDate < now)
    }

    // Apply date filter (current trips)
    if (filters.features && filters.features.includes("current")) {
      const now = new Date()
      filteredTrips = filteredTrips.filter((trip) => trip.startDate <= now && trip.endDate >= now)
    }

    // Apply sorting
    if (filters.sortBy) {
      switch (filters.sortBy) {
        case "relevance":
          // Default order
          break
        case "date_asc":
          filteredTrips.sort((a, b) => a.startDate.getTime() - b.startDate.getTime())
          break
        case "date_desc":
          filteredTrips.sort((a, b) => b.startDate.getTime() - a.startDate.getTime())
          break
        case "name_asc":
          filteredTrips.sort((a, b) => a.name.localeCompare(b.name))
          break
        case "name_desc":
          filteredTrips.sort((a, b) => b.name.localeCompare(a.name))
          break
        case "created_asc":
          filteredTrips.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
          break
        case "created_desc":
          filteredTrips.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
          break
      }
    } else {
      // Default sort by start date (upcoming first)
      filteredTrips.sort((a, b) => a.startDate.getTime() - b.startDate.getTime())
    }
  }

  // Apply pagination
  const limit = filters?.limit || 10
  const offset = filters?.offset || 0
  const paginatedTrips = filteredTrips.slice(offset, offset + limit)

  return {
    items: paginatedTrips,
    total: filteredTrips.length,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit,
    hasMore: offset + limit < filteredTrips.length,
  }
}

// Helper function to filter and paginate saved items
const filterAndPaginateSavedItems = (savedItems: SavedItem[], filters?: SearchFilters): PaginatedResult<SavedItem> => {
  let filteredSavedItems = [...savedItems]

  if (filters) {
    // Apply type filter
    if (filters.categories && filters.categories.length > 0) {
      filteredSavedItems = filteredSavedItems.filter((item) => filters.categories!.includes(item.itemType))
    }

    // Apply sorting
    if (filters.sortBy) {
      switch (filters.sortBy) {
        case "relevance":
          // Default order
          break
        case "saved_asc":
          filteredSavedItems.sort((a, b) => a.savedAt.getTime() - b.savedAt.getTime())
          break
        case "saved_desc":
          filteredSavedItems.sort((a, b) => b.savedAt.getTime() - a.savedAt.getTime())
          break
      }
    } else {
      // Default sort by saved date (newest first)
      filteredSavedItems.sort((a, b) => b.savedAt.getTime() - a.savedAt.getTime())
    }
  }

  // Apply pagination
  const limit = filters?.limit || 10
  const offset = filters?.offset || 0
  const paginatedSavedItems = filteredSavedItems.slice(offset, offset + limit)

  return {
    items: paginatedSavedItems,
    total: filteredSavedItems.length,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit,
    hasMore: offset + limit < filteredSavedItems.length,
  }
}
