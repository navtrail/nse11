import type { DataIntegrationConfig } from "./types"

// Cache implementation
export class Cache<T> {
  private cache: Map<string, { data: T; timestamp: number }> = new Map()
  private ttl: number // Time to live in milliseconds

  constructor(ttlSeconds = 3600) {
    this.ttl = ttlSeconds * 1000
  }

  set(key: string, data: T): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
    })
  }

  get(key: string): T | null {
    const item = this.cache.get(key)

    if (!item) return null

    // Check if the item has expired
    if (Date.now() - item.timestamp > this.ttl) {
      this.cache.delete(key)
      return null
    }

    return item.data
  }

  has(key: string): boolean {
    return this.get(key) !== null
  }

  delete(key: string): void {
    this.cache.delete(key)
  }

  clear(): void {
    this.cache.clear()
  }
}

// API request helper with caching
export async function fetchWithCache<T>(
  url: string,
  options: RequestInit = {},
  cache?: Cache<T>,
  cacheKey?: string,
): Promise<T> {
  // If cache is provided and the key exists in cache, return cached data
  if (cache && cacheKey && cache.has(cacheKey)) {
    const cachedData = cache.get(cacheKey)
    if (cachedData) return cachedData
  }

  try {
    const response = await fetch(url, options)

    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`)
    }

    const data = (await response.json()) as T

    // If cache is provided, store the result
    if (cache && cacheKey) {
      cache.set(cacheKey, data)
    }

    return data
  } catch (error) {
    console.error("API request error:", error)
    throw error
  }
}

// Helper to generate a unique ID
export function generateUniqueId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
}

// Helper to calculate distance between two coordinates using Haversine formula
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371 // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1)
  const dLon = deg2rad(lon2 - lon1)
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  const distance = R * c // Distance in km
  return distance
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180)
}

// Helper to format currency
export function formatCurrency(amount: number, currency = "USD", locale = "en-US"): string {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency: currency,
  }).format(amount)
}

// Helper to format date
export function formatDate(date: Date | string | number, format = "short", locale = "en-US"): string {
  const dateObj = new Date(date)

  switch (format) {
    case "short":
      return dateObj.toLocaleDateString(locale)
    case "long":
      return dateObj.toLocaleDateString(locale, {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    case "time":
      return dateObj.toLocaleTimeString(locale)
    case "full":
      return dateObj.toLocaleString(locale, {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    default:
      return dateObj.toLocaleString(locale)
  }
}

// Helper to check if a device is online
export function isOnline(): boolean {
  return typeof navigator !== "undefined" && navigator.onLine
}

// Helper to debounce function calls
export function debounce<F extends (...args: any[]) => any>(
  func: F,
  waitFor: number,
): (...args: Parameters<F>) => void {
  let timeout: ReturnType<typeof setTimeout> | null = null

  return (...args: Parameters<F>): void => {
    if (timeout !== null) {
      clearTimeout(timeout)
    }
    timeout = setTimeout(() => func(...args), waitFor)
  }
}

// Helper to throttle function calls
export function throttle<F extends (...args: any[]) => any>(
  func: F,
  waitFor: number,
): (...args: Parameters<F>) => void {
  let lastTime = 0

  return (...args: Parameters<F>): void => {
    const now = Date.now()
    if (now - lastTime >= waitFor) {
      func(...args)
      lastTime = now
    }
  }
}

// Helper to parse query parameters from URL
export function parseQueryParams(url: string): Record<string, string> {
  const params: Record<string, string> = {}
  const queryString = url.split("?")[1]

  if (!queryString) return params

  const pairs = queryString.split("&")

  for (const pair of pairs) {
    const [key, value] = pair.split("=")
    params[decodeURIComponent(key)] = decodeURIComponent(value || "")
  }

  return params
}

// Helper to build URL with query parameters
export function buildUrl(baseUrl: string, params: Record<string, string | number | boolean | undefined>): string {
  const url = new URL(baseUrl)

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined) {
      url.searchParams.append(key, String(value))
    }
  })

  return url.toString()
}

// Helper to handle API errors
export function handleApiError(error: any): never {
  if (error instanceof Response) {
    throw new Error(`API error: ${error.status} ${error.statusText}`)
  } else if (error instanceof Error) {
    throw error
  } else {
    throw new Error(`Unknown API error: ${String(error)}`)
  }
}

// Helper to get configuration value with fallback
export function getConfigValue<T>(config: DataIntegrationConfig, path: string, defaultValue: T): T {
  const parts = path.split(".")
  let current: any = config

  for (const part of parts) {
    if (current === undefined || current === null) {
      return defaultValue
    }
    current = current[part]
  }

  return current !== undefined && current !== null ? current : defaultValue
}

// Helper to validate coordinates
export function isValidCoordinates(lat: number, lon: number): boolean {
  return lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180
}

// Helper to encode polyline
export function encodePolyline(coordinates: Array<[number, number]>): string {
  let output = ""
  const factor = Math.pow(10, 5)
  let lat = 0
  let lng = 0

  for (let i = 0; i < coordinates.length; i++) {
    const point = coordinates[i]
    const latDiff = Math.round(point[0] * factor) - Math.round(lat * factor)
    const lngDiff = Math.round(point[1] * factor) - Math.round(lng * factor)
    lat = point[0]
    lng = point[1]
    output += encodeValue(latDiff) + encodeValue(lngDiff)
  }

  return output
}

function encodeValue(value: number): string {
  value = value < 0 ? ~(value << 1) : value << 1
  let result = ""
  while (value >= 0x20) {
    result += String.fromCharCode((0x20 | (value & 0x1f)) + 63)
    value >>= 5
  }
  result += String.fromCharCode(value + 63)
  return result
}

// Helper to decode polyline
export function decodePolyline(str: string): Array<[number, number]> {
  let index = 0
  let lat = 0
  let lng = 0
  const coordinates: Array<[number, number]> = []
  const factor = Math.pow(10, -5)

  while (index < str.length) {
    let result = 1
    let shift = 0
    let b: number
    do {
      b = str.charCodeAt(index++) - 63 - 1
      result += b << shift
      shift += 5
    } while (b >= 0x1f)
    lat += (result & 1) !== 0 ? ~(result >> 1) : result >> 1

    result = 1
    shift = 0
    do {
      b = str.charCodeAt(index++) - 63 - 1
      result += b << shift
      shift += 5
    } while (b >= 0x1f)
    lng += (result & 1) !== 0 ? ~(result >> 1) : result >> 1

    coordinates.push([lat * factor, lng * factor])
  }

  return coordinates
}
