import type { Accommodation, Restaurant, SearchFilters, PaginatedResult, Coordinates, AccommodationType } from "./types"
import { CACHE_KEYS, CACHE_EXPIRATION, getCache, setCache, delay, calculateDistance } from "./utils"

// Mock data for accommodations
const mockAccommodations: Accommodation[] = [
  {
    id: "acc-001",
    name: "Grand Hotel Paris",
    type: "hotel",
    coordinates: { latitude: 48.8698, longitude: 2.3075 },
    address: "2 Rue Scribe, 75009 Paris, France",
    city: "Paris",
    country: "France",
    price: {
      amount: 250,
      currency: "EUR",
      period: "night",
    },
    rating: 4.7,
    reviewCount: 2345,
    amenities: [
      "Free WiFi",
      "Restaurant",
      "Room Service",
      "Fitness Center",
      "Spa",
      "Swimming Pool",
      "Bar",
      "Concierge",
      "Parking",
      "Airport Shuttle",
    ],
    images: [
      "https://images.unsplash.com/photo-1566073771259-6a8506099945",
      "https://images.unsplash.com/photo-1582719508461-905c673771fd",
      "https://images.unsplash.com/photo-1578683010236-d716f9a3f461",
    ],
    description:
      "Experience luxury in the heart of Paris at the Grand Hotel. With stunning views of the city and exceptional service, your stay will be unforgettable.",
    rooms: [
      {
        id: "room-001",
        type: "Standard Room",
        description: "Comfortable room with a queen-sized bed and city view.",
        capacity: 2,
        amenities: ["TV", "Safe", "Mini Bar", "Air Conditioning"],
        price: 250,
        currency: "EUR",
        images: ["https://images.unsplash.com/photo-1566665797739-1674de7a421a"],
      },
      {
        id: "room-002",
        type: "Deluxe Room",
        description: "Spacious room with a king-sized bed and Eiffel Tower view.",
        capacity: 2,
        amenities: ["TV", "Safe", "Mini Bar", "Air Conditioning", "Balcony"],
        price: 350,
        currency: "EUR",
        images: ["https://images.unsplash.com/photo-1590490360182-c33d57733427"],
      },
      {
        id: "room-003",
        type: "Suite",
        description: "Luxurious suite with separate living area and panoramic city views.",
        capacity: 4,
        amenities: ["TV", "Safe", "Mini Bar", "Air Conditioning", "Balcony", "Jacuzzi", "Separate Living Area"],
        price: 550,
        currency: "EUR",
        images: ["https://images.unsplash.com/photo-1591088398332-8a7791972843"],
      },
    ],
    checkInTime: "15:00",
    checkOutTime: "11:00",
    policies: ["No smoking", "No pets", "Cancellation policy: Free cancellation up to 48 hours before check-in"],
    contactInfo: "+33 1 23 45 67 89",
    website: "https://www.grandhotelparis.com",
    availability: [
      {
        startDate: "2023-06-01",
        endDate: "2023-06-30",
        isAvailable: true,
        price: 250,
      },
      {
        startDate: "2023-07-01",
        endDate: "2023-07-31",
        isAvailable: true,
        price: 300,
      },
      {
        startDate: "2023-08-01",
        endDate: "2023-08-31",
        isAvailable: true,
        price: 350,
      },
    ],
    createdAt: new Date("2023-01-01T00:00:00Z"),
    updatedAt: new Date("2023-05-15T00:00:00Z"),
  },
  {
    id: "acc-002",
    name: "Tokyo Skyline Apartment",
    type: "apartment",
    coordinates: { latitude: 35.6895, longitude: 139.6917 },
    address: "1-2-3 Shibuya, Shibuya-ku, Tokyo 150-0002, Japan",
    city: "Tokyo",
    country: "Japan",
    price: {
      amount: 180,
      currency: "USD",
      period: "night",
    },
    rating: 4.5,
    reviewCount: 1234,
    amenities: ["Free WiFi", "Kitchen", "Washing Machine", "Air Conditioning", "TV", "Balcony", "Elevator"],
    images: [
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267",
      "https://images.unsplash.com/photo-1560448204-603b3fc33ddc",
      "https://images.unsplash.com/photo-1560185007-cde436f6a4d0",
    ],
    description:
      "Modern apartment with stunning views of Tokyo skyline. Perfect for business travelers or couples exploring the city.",
    rooms: [
      {
        id: "room-004",
        type: "1 Bedroom Apartment",
        description: "Modern apartment with separate bedroom and living area.",
        capacity: 2,
        amenities: ["TV", "Kitchen", "Washing Machine", "Air Conditioning", "Balcony"],
        price: 180,
        currency: "USD",
        images: ["https://images.unsplash.com/photo-1560185007-5f0bb1866cab"],
      },
    ],
    checkInTime: "16:00",
    checkOutTime: "10:00",
    policies: ["No smoking", "No parties", "Cancellation policy: Free cancellation up to 7 days before check-in"],
    contactInfo: "+81 3 1234 5678",
    website: "https://www.tokyoskylineapartment.com",
    availability: [
      {
        startDate: "2023-06-01",
        endDate: "2023-06-15",
        isAvailable: true,
        price: 180,
      },
      {
        startDate: "2023-06-16",
        endDate: "2023-06-30",
        isAvailable: false,
      },
      {
        startDate: "2023-07-01",
        endDate: "2023-07-31",
        isAvailable: true,
        price: 200,
      },
    ],
    createdAt: new Date("2023-02-01T00:00:00Z"),
    updatedAt: new Date("2023-05-10T00:00:00Z"),
  },
  {
    id: "acc-003",
    name: "Central Park View Hotel",
    type: "hotel",
    coordinates: { latitude: 40.7641, longitude: -73.9743 },
    address: "123 W 57th St, New York, NY 10019, USA",
    city: "New York",
    country: "United States",
    price: {
      amount: 350,
      currency: "USD",
      period: "night",
    },
    rating: 4.8,
    reviewCount: 3456,
    amenities: [
      "Free WiFi",
      "Restaurant",
      "Room Service",
      "Fitness Center",
      "Spa",
      "Business Center",
      "Bar",
      "Concierge",
      "Parking",
    ],
    images: [
      "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa",
      "https://images.unsplash.com/photo-1611892440504-42a792e24d32",
      "https://images.unsplash.com/photo-1618773928121-c32242e63f39",
    ],
    description:
      "Luxury hotel with breathtaking views of Central Park. Experience the best of New York City with our prime location and world-class amenities.",
    rooms: [
      {
        id: "room-005",
        type: "Standard Room",
        description: "Comfortable room with a queen-sized bed.",
        capacity: 2,
        amenities: ["TV", "Safe", "Mini Bar", "Air Conditioning"],
        price: 350,
        currency: "USD",
        images: ["https://images.unsplash.com/photo-1618773928121-c32242e63f39"],
      },
      {
        id: "room-006",
        type: "Deluxe Room",
        description: "Spacious room with a king-sized bed and park view.",
        capacity: 2,
        amenities: ["TV", "Safe", "Mini Bar", "Air Conditioning", "Park View"],
        price: 450,
        currency: "USD",
        images: ["https://images.unsplash.com/photo-1590490359683-658d3d23f972"],
      },
      {
        id: "room-007",
        type: "Executive Suite",
        description: "Luxurious suite with separate living area and panoramic park views.",
        capacity: 4,
        amenities: ["TV", "Safe", "Mini Bar", "Air Conditioning", "Park View", "Separate Living Area", "Jacuzzi"],
        price: 650,
        currency: "USD",
        images: ["https://images.unsplash.com/photo-1578683010236-d716f9a3f461"],
      },
    ],
    checkInTime: "15:00",
    checkOutTime: "12:00",
    policies: [
      "No smoking",
      "Pets allowed (with additional fee)",
      "Cancellation policy: Free cancellation up to 24 hours before check-in",
    ],
    contactInfo: "+1 212 555 1234",
    website: "https://www.centralparkviewhotel.com",
    availability: [
      {
        startDate: "2023-06-01",
        endDate: "2023-06-30",
        isAvailable: true,
        price: 350,
      },
      {
        startDate: "2023-07-01",
        endDate: "2023-07-31",
        isAvailable: true,
        price: 400,
      },
      {
        startDate: "2023-08-01",
        endDate: "2023-08-31",
        isAvailable: true,
        price: 450,
      },
    ],
    createdAt: new Date("2023-01-15T00:00:00Z"),
    updatedAt: new Date("2023-05-20T00:00:00Z"),
  },
  {
    id: "acc-004",
    name: "Roman Holiday Guesthouse",
    type: "guesthouse",
    coordinates: { latitude: 41.9028, longitude: 12.4964 },
    address: "Via del Corso 123, 00186 Roma RM, Italy",
    city: "Rome",
    country: "Italy",
    price: {
      amount: 120,
      currency: "EUR",
      period: "night",
    },
    rating: 4.6,
    reviewCount: 987,
    amenities: ["Free WiFi", "Breakfast", "Air Conditioning", "Shared Kitchen", "Terrace"],
    images: [
      "https://images.unsplash.com/photo-1519690889869-e705e59f72e1",
      "https://images.unsplash.com/photo-1566665797739-1674de7a421a",
      "https://images.unsplash.com/photo-1574691250077-03a929faece5",
    ],
    description:
      "Charming guesthouse in the heart of Rome. Experience authentic Italian hospitality and explore the city's famous landmarks, all within walking distance.",
    rooms: [
      {
        id: "room-008",
        type: "Single Room",
        description: "Cozy room with a single bed.",
        capacity: 1,
        amenities: ["TV", "Air Conditioning", "Shared Bathroom"],
        price: 80,
        currency: "EUR",
        images: ["https://images.unsplash.com/photo-1566665797739-1674de7a421a"],
      },
      {
        id: "room-009",
        type: "Double Room",
        description: "Comfortable room with a double bed.",
        capacity: 2,
        amenities: ["TV", "Air Conditioning", "Private Bathroom"],
        price: 120,
        currency: "EUR",
        images: ["https://images.unsplash.com/photo-1574691250077-03a929faece5"],
      },
      {
        id: "room-010",
        type: "Family Room",
        description: "Spacious room with one double bed and two single beds.",
        capacity: 4,
        amenities: ["TV", "Air Conditioning", "Private Bathroom", "Balcony"],
        price: 180,
        currency: "EUR",
        images: ["https://images.unsplash.com/photo-1590490360182-c33d57733427"],
      },
    ],
    checkInTime: "14:00",
    checkOutTime: "10:00",
    policies: ["No smoking", "No pets", "Cancellation policy: Free cancellation up to 7 days before check-in"],
    contactInfo: "+39 06 1234 5678",
    website: "https://www.romanholidayguesthouse.com",
    availability: [
      {
        startDate: "2023-06-01",
        endDate: "2023-06-30",
        isAvailable: true,
        price: 120,
      },
      {
        startDate: "2023-07-01",
        endDate: "2023-07-31",
        isAvailable: true,
        price: 150,
      },
      {
        startDate: "2023-08-01",
        endDate: "2023-08-31",
        isAvailable: true,
        price: 180,
      },
    ],
    createdAt: new Date("2023-02-15T00:00:00Z"),
    updatedAt: new Date("2023-05-05T00:00:00Z"),
  },
  {
    id: "acc-005",
    name: "Sydney Harbour Apartment",
    type: "apartment",
    coordinates: { latitude: -33.8568, longitude: 151.2153 },
    address: "123 George St, The Rocks NSW 2000, Australia",
    city: "Sydney",
    country: "Australia",
    price: {
      amount: 220,
      currency: "AUD",
      period: "night",
    },
    rating: 4.7,
    reviewCount: 1543,
    amenities: [
      "Free WiFi",
      "Kitchen",
      "Washing Machine",
      "Air Conditioning",
      "TV",
      "Balcony",
      "Harbor View",
      "Elevator",
    ],
    images: [
      "https://images.unsplash.com/photo-1560185007-cde436f6a4d0",
      "https://images.unsplash.com/photo-1560185127-6ed189bf02f4",
      "https://images.unsplash.com/photo-1560448204-603b3fc33ddc",
    ],
    description:
      "Modern apartment with stunning views of Sydney Harbour and the Opera House. Perfect location for exploring Sydney's attractions.",
    rooms: [
      {
        id: "room-011",
        type: "2 Bedroom Apartment",
        description: "Spacious apartment with two bedrooms and harbour views.",
        capacity: 4,
        amenities: ["TV", "Kitchen", "Washing Machine", "Air Conditioning", "Balcony", "Harbor View"],
        price: 220,
        currency: "AUD",
        images: ["https://images.unsplash.com/photo-1560185007-cde436f6a4d0"],
      },
    ],
    checkInTime: "14:00",
    checkOutTime: "10:00",
    policies: ["No smoking", "No parties", "Cancellation policy: Free cancellation up to 14 days before check-in"],
    contactInfo: "+61 2 9876 5432",
    website: "https://www.sydneyharbourview.com",
    availability: [
      {
        startDate: "2023-06-01",
        endDate: "2023-06-30",
        isAvailable: true,
        price: 220,
      },
      {
        startDate: "2023-07-01",
        endDate: "2023-07-31",
        isAvailable: true,
        price: 250,
      },
      {
        startDate: "2023-08-01",
        endDate: "2023-08-31",
        isAvailable: true,
        price: 280,
      },
    ],
    createdAt: new Date("2023-03-01T00:00:00Z"),
    updatedAt: new Date("2023-05-12T00:00:00Z"),
  },
]

// Mock data for restaurants
const mockRestaurants: Restaurant[] = [
  {
    id: "rest-001",
    name: "Le Petit Bistro",
    coordinates: { latitude: 48.8566, longitude: 2.3522 },
    address: "123 Rue de Rivoli, 75001 Paris, France",
    city: "Paris",
    country: "France",
    cuisine: ["French", "European"],
    priceLevel: 3,
    rating: 4.6,
    reviewCount: 1234,
    openingHours: {
      monday: [
        { open: "12:00", close: "14:30" },
        { open: "19:00", close: "22:30" },
      ],
      tuesday: [
        { open: "12:00", close: "14:30" },
        { open: "19:00", close: "22:30" },
      ],
      wednesday: [
        { open: "12:00", close: "14:30" },
        { open: "19:00", close: "22:30" },
      ],
      thursday: [
        { open: "12:00", close: "14:30" },
        { open: "19:00", close: "22:30" },
      ],
      friday: [
        { open: "12:00", close: "14:30" },
        { open: "19:00", close: "23:00" },
      ],
      saturday: [
        { open: "12:00", close: "15:00" },
        { open: "19:00", close: "23:00" },
      ],
      sunday: [{ open: "12:00", close: "15:00" }],
    },
    images: [
      "https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c",
      "https://images.unsplash.com/photo-1414235077428-338989a2e8c0",
      "https://images.unsplash.com/photo-1600891964599-f61ba0e24092",
    ],
    description:
      "Authentic French bistro serving classic dishes in a cozy atmosphere. Our chef uses only the freshest local ingredients.",
    menu: [
      {
        name: "Coq au Vin",
        description: "Traditional French dish of chicken braised with wine, lardons, mushrooms, and garlic.",
        price: 24,
        currency: "EUR",
        category: "Main Course",
        dietaryLabels: ["Gluten-Free"],
      },
      {
        name: "Beef Bourguignon",
        description: "Slow-cooked beef stew braised in red wine with carrots, onions, and mushrooms.",
        price: 26,
        currency: "EUR",
        category: "Main Course",
      },
      {
        name: "Crème Brûlée",
        description:
          "Classic French dessert consisting of a rich custard base topped with a layer of hardened caramelized sugar.",
        price: 10,
        currency: "EUR",
        category: "Dessert",
        dietaryLabels: ["Vegetarian"],
      },
    ],
    contactInfo: "+33 1 23 45 67 89",
    website: "https://www.lepetitbistro.com",
    features: ["Outdoor Seating", "Romantic", "Serves Alcohol", "Reservations"],
    dietaryOptions: ["Vegetarian", "Gluten-Free"],
    reservationUrl: "https://www.lepetitbistro.com/reservations",
    createdAt: new Date("2023-01-01T00:00:00Z"),
    updatedAt: new Date("2023-05-15T00:00:00Z"),
  },
  {
    id: "rest-002",
    name: "Sushi Delight",
    coordinates: { latitude: 35.6895, longitude: 139.6917 },
    address: "4-5-6 Shibuya, Shibuya-ku, Tokyo 150-0002, Japan",
    city: "Tokyo",
    country: "Japan",
    cuisine: ["Japanese", "Sushi", "Asian"],
    priceLevel: 4,
    rating: 4.8,
    reviewCount: 2345,
    openingHours: {
      monday: [
        { open: "11:30", close: "14:00" },
        { open: "17:30", close: "22:00" },
      ],
      tuesday: [
        { open: "11:30", close: "14:00" },
        { open: "17:30", close: "22:00" },
      ],
      wednesday: [
        { open: "11:30", close: "14:00" },
        { open: "17:30", close: "22:00" },
      ],
      thursday: [
        { open: "11:30", close: "14:00" },
        { open: "17:30", close: "22:00" },
      ],
      friday: [
        { open: "11:30", close: "14:00" },
        { open: "17:30", close: "22:30" },
      ],
      saturday: [
        { open: "11:30", close: "14:30" },
        { open: "17:00", close: "22:30" },
      ],
      sunday: [
        { open: "11:30", close: "14:30" },
        { open: "17:00", close: "21:30" },
      ],
    },
    images: [
      "https://images.unsplash.com/photo-1579871494447-9811cf80d66c",
      "https://images.unsplash.com/photo-1611143669185-af224c5e3252",
      "https://images.unsplash.com/photo-1553621042-f6e147245754",
    ],
    description:
      "Premium sushi restaurant offering the freshest seafood and authentic Japanese cuisine. Our master chef has over 30 years of experience.",
    menu: [
      {
        name: "Omakase",
        description: "Chef's selection of the finest sushi and sashimi.",
        price: 15000,
        currency: "JPY",
        category: "Set Menu",
        isSpecial: true,
      },
      {
        name: "Nigiri Set",
        description: "Assortment of 10 pieces of nigiri sushi.",
        price: 8000,
        currency: "JPY",
        category: "Sushi",
      },
      {
        name: "Vegetarian Roll Set",
        description: "Selection of vegetarian sushi rolls.",
        price: 5000,
        currency: "JPY",
        category: "Sushi",
        dietaryLabels: ["Vegetarian", "Vegan"],
      },
    ],
    contactInfo: "+81 3 1234 5678",
    website: "https://www.sushidelight.com",
    features: ["Reservations", "Serves Alcohol", "Private Dining", "Counter Seating"],
    dietaryOptions: ["Vegetarian", "Gluten-Free"],
    reservationUrl: "https://www.sushidelight.com/reservations",
    createdAt: new Date("2023-02-01T00:00:00Z"),
    updatedAt: new Date("2023-05-10T00:00:00Z"),
  },
  {
    id: "rest-003",
    name: "New York Steakhouse",
    coordinates: { latitude: 40.7128, longitude: -74.006 },
    address: "456 Broadway, New York, NY 10013, USA",
    city: "New York",
    country: "United States",
    cuisine: ["American", "Steakhouse", "Grill"],
    priceLevel: 4,
    rating: 4.7,
    reviewCount: 3456,
    openingHours: {
      monday: [{ open: "17:00", close: "23:00" }],
      tuesday: [{ open: "17:00", close: "23:00" }],
      wednesday: [{ open: "17:00", close: "23:00" }],
      thursday: [{ open: "17:00", close: "23:00" }],
      friday: [{ open: "17:00", close: "00:00" }],
      saturday: [{ open: "16:00", close: "00:00" }],
      sunday: [{ open: "16:00", close: "22:00" }],
    },
    images: [
      "https://images.unsplash.com/photo-1544148103-0773bf10d330",
      "https://images.unsplash.com/photo-1558030006-450675393462",
      "https://images.unsplash.com/photo-1594041680534-e8c8cdebd659",
    ],
    description:
      "Premium steakhouse serving the finest USDA prime beef, aged to perfection. Enjoy classic American cuisine in an elegant setting.",
    menu: [
      {
        name: "Porterhouse Steak (for two)",
        description: "32oz USDA Prime, dry-aged for 28 days.",
        price: 120,
        currency: "USD",
        category: "Main Course",
        isSpecial: true,
      },
      {
        name: "Filet Mignon",
        description: "8oz center cut, served with truffle butter.",
        price: 65,
        currency: "USD",
        category: "Main Course",
        dietaryLabels: ["Gluten-Free"],
      },
      {
        name: "Lobster Mac & Cheese",
        description: "Creamy macaroni with chunks of lobster meat and a crispy topping.",
        price: 30,
        currency: "USD",
        category: "Side Dish",
      },
    ],
    contactInfo: "+1 212 555 6789",
    website: "https://www.nysteakhouse.com",
    features: ["Reservations", "Full Bar", "Private Dining", "Valet Parking"],
    dietaryOptions: ["Gluten-Free"],
    reservationUrl: "https://www.nysteakhouse.com/reservations",
    createdAt: new Date("2023-01-15T00:00:00Z"),
    updatedAt: new Date("2023-05-20T00:00:00Z"),
  },
  {
    id: "rest-004",
    name: "Trattoria Roma",
    coordinates: { latitude: 41.9028, longitude: 12.4964 },
    address: "Via del Corso 456, 00186 Roma RM, Italy",
    city: "Rome",
    country: "Italy",
    cuisine: ["Italian", "Mediterranean", "Pizza", "Pasta"],
    priceLevel: 2,
    rating: 4.5,
    reviewCount: 1876,
    openingHours: {
      monday: [
        { open: "12:00", close: "15:00" },
        { open: "19:00", close: "23:00" },
      ],
      tuesday: [
        { open: "12:00", close: "15:00" },
        { open: "19:00", close: "23:00" },
      ],
      wednesday: [
        { open: "12:00", close: "15:00" },
        { open: "19:00", close: "23:00" },
      ],
      thursday: [
        { open: "12:00", close: "15:00" },
        { open: "19:00", close: "23:00" },
      ],
      friday: [
        { open: "12:00", close: "15:00" },
        { open: "19:00", close: "23:30" },
      ],
      saturday: [
        { open: "12:00", close: "15:30" },
        { open: "19:00", close: "23:30" },
      ],
      sunday: [
        { open: "12:00", close: "15:30" },
        { open: "19:00", close: "22:30" },
      ],
    },
    images: [
      "https://images.unsplash.com/photo-1555396273-367ea4eb4db5",
      "https://images.unsplash.com/photo-1498579809087-ef1e558fd1da",
      "https://images.unsplash.com/photo-1595295333158-4742f28fbd85",
    ],
    description:
      "Family-run trattoria serving authentic Roman cuisine. Our recipes have been passed down through generations.",
    menu: [
      {
        name: "Carbonara",
        description: "Traditional Roman pasta with eggs, pecorino cheese, guanciale, and black pepper.",
        price: 14,
        currency: "EUR",
        category: "Pasta",
      },
      {
        name: "Margherita Pizza",
        description: "Classic pizza with tomato sauce, mozzarella, and basil.",
        price: 10,
        currency: "EUR",
        category: "Pizza",
        dietaryLabels: ["Vegetarian"],
      },
      {
        name: "Tiramisu",
        description: "Homemade tiramisu with mascarpone cream and coffee-soaked ladyfingers.",
        price: 7,
        currency: "EUR",
        category: "Dessert",
        dietaryLabels: ["Vegetarian"],
      },
    ],
    contactInfo: "+39 06 9876 5432",
    website: "https://www.trattoriaroma.com",
    features: ["Outdoor Seating", "Family-friendly", "Serves Alcohol", "Takeout"],
    dietaryOptions: ["Vegetarian", "Vegan Options"],
    reservationUrl: "https://www.trattoriaroma.com/reservations",
    createdAt: new Date("2023-02-15T00:00:00Z"),
    updatedAt: new Date("2023-05-05T00:00:00Z"),
  },
  {
    id: "rest-005",
    name: "Sydney Seafood House",
    coordinates: { latitude: -33.8688, longitude: 151.2093 },
    address: "789 Darling Harbour, Sydney NSW 2000, Australia",
    city: "Sydney",
    country: "Australia",
    cuisine: ["Seafood", "Australian", "Pacific"],
    priceLevel: 3,
    rating: 4.6,
    reviewCount: 2187,
    openingHours: {
      monday: [
        { open: "12:00", close: "15:00" },
        { open: "18:00", close: "22:00" },
      ],
      tuesday: [
        { open: "12:00", close: "15:00" },
        { open: "18:00", close: "22:00" },
      ],
      wednesday: [
        { open: "12:00", close: "15:00" },
        { open: "18:00", close: "22:00" },
      ],
      thursday: [
        { open: "12:00", close: "15:00" },
        { open: "18:00", close: "22:00" },
      ],
      friday: [
        { open: "12:00", close: "15:00" },
        { open: "18:00", close: "22:30" },
      ],
      saturday: [
        { open: "12:00", close: "15:30" },
        { open: "18:00", close: "22:30" },
      ],
      sunday: [
        { open: "12:00", close: "15:30" },
        { open: "18:00", close: "21:30" },
      ],
    },
    images: [
      "https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62",
      "https://images.unsplash.com/photo-1559339352-11d035aa65de",
      "https://images.unsplash.com/photo-1579631542720-3a87824fff86",
    ],
    description:
      "Waterfront restaurant specializing in fresh Australian seafood. Enjoy stunning harbor views while dining on the catch of the day.",
    menu: [
      {
        name: "Seafood Platter for Two",
        description: "Selection of fresh oysters, prawns, mussels, grilled fish, and lobster.",
        price: 150,
        currency: "AUD",
        category: "Main Course",
        isSpecial: true,
      },
      {
        name: "Barramundi Fillet",
        description: "Grilled Australian barramundi with lemon butter sauce and seasonal vegetables.",
        price: 38,
        currency: "AUD",
        category: "Main Course",
        dietaryLabels: ["Gluten-Free"],
      },
      {
        name: "Pavlova",
        description: "Classic Australian dessert with meringue, fresh cream, and seasonal fruits.",
        price: 15,
        currency: "AUD",
        category: "Dessert",
        dietaryLabels: ["Vegetarian", "Gluten-Free"],
      },
    ],
    contactInfo: "+61 2 8765 4321",
    website: "https://www.sydneyseafoodhouse.com",
    features: ["Waterfront", "Scenic View", "Outdoor Seating", "Full Bar"],
    dietaryOptions: ["Gluten-Free", "Vegetarian Options"],
    reservationUrl: "https://www.sydneyseafoodhouse.com/reservations",
    createdAt: new Date("2023-03-01T00:00:00Z"),
    updatedAt: new Date("2023-05-12T00:00:00Z"),
  },
]

// Get all accommodations
export const getAccommodations = async (filters?: SearchFilters): Promise<PaginatedResult<Accommodation>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Accommodation[]>(CACHE_KEYS.ACCOMMODATIONS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      return filterAndPaginateAccommodations(cachedData, filters)
    }

    // Simulate API call
    await delay(1200)

    // Cache the data
    await setCache(CACHE_KEYS.ACCOMMODATIONS, mockAccommodations)

    return filterAndPaginateAccommodations(mockAccommodations, filters)
  } catch (error) {
    console.error("Error fetching accommodations:", error)
    throw error
  }
}

// Get accommodation by ID
export const getAccommodationById = async (id: string): Promise<Accommodation | null> => {
  try {
    // Check cache first
    const cachedData = await getCache<Accommodation[]>(CACHE_KEYS.ACCOMMODATIONS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const accommodation = cachedData.find((acc) => acc.id === id)
      return accommodation || null
    }

    // Simulate API call
    await delay(500)

    const accommodation = mockAccommodations.find((acc) => acc.id === id)
    return accommodation || null
  } catch (error) {
    console.error(`Error fetching accommodation with ID ${id}:`, error)
    throw error
  }
}

// Get accommodations by city
export const getAccommodationsByCity = async (
  cityName: string,
  filters?: SearchFilters,
): Promise<PaginatedResult<Accommodation>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Accommodation[]>(CACHE_KEYS.ACCOMMODATIONS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const cityAccommodations = cachedData.filter((acc) => acc.city.toLowerCase() === cityName.toLowerCase())
      return filterAndPaginateAccommodations(cityAccommodations, filters)
    }

    // Simulate API call
    await delay(800)

    const cityAccommodations = mockAccommodations.filter((acc) => acc.city.toLowerCase() === cityName.toLowerCase())
    return filterAndPaginateAccommodations(cityAccommodations, filters)
  } catch (error) {
    console.error(`Error fetching accommodations for city ${cityName}:`, error)
    throw error
  }
}

// Get accommodations by type
export const getAccommodationsByType = async (
  type: AccommodationType,
  filters?: SearchFilters,
): Promise<PaginatedResult<Accommodation>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Accommodation[]>(CACHE_KEYS.ACCOMMODATIONS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const typeAccommodations = cachedData.filter((acc) => acc.type === type)
      return filterAndPaginateAccommodations(typeAccommodations, filters)
    }

    // Simulate API call
    await delay(800)

    const typeAccommodations = mockAccommodations.filter((acc) => acc.type === type)
    return filterAndPaginateAccommodations(typeAccommodations, filters)
  } catch (error) {
    console.error(`Error fetching accommodations of type ${type}:`, error)
    throw error
  }
}

// Get all restaurants
export const getRestaurants = async (filters?: SearchFilters): Promise<PaginatedResult<Restaurant>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Restaurant[]>(CACHE_KEYS.RESTAURANTS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      return filterAndPaginateRestaurants(cachedData, filters)
    }

    // Simulate API call
    await delay(1200)

    // Cache the data
    await setCache(CACHE_KEYS.RESTAURANTS, mockRestaurants)

    return filterAndPaginateRestaurants(mockRestaurants, filters)
  } catch (error) {
    console.error("Error fetching restaurants:", error)
    throw error
  }
}

// Get restaurant by ID
export const getRestaurantById = async (id: string): Promise<Restaurant | null> => {
  try {
    // Check cache first
    const cachedData = await getCache<Restaurant[]>(CACHE_KEYS.RESTAURANTS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const restaurant = cachedData.find((rest) => rest.id === id)
      return restaurant || null
    }

    // Simulate API call
    await delay(500)

    const restaurant = mockRestaurants.find((rest) => rest.id === id)
    return restaurant || null
  } catch (error) {
    console.error(`Error fetching restaurant with ID ${id}:`, error)
    throw error
  }
}

// Get restaurants by city
export const getRestaurantsByCity = async (
  cityName: string,
  filters?: SearchFilters,
): Promise<PaginatedResult<Restaurant>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Restaurant[]>(CACHE_KEYS.RESTAURANTS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const cityRestaurants = cachedData.filter((rest) => rest.city.toLowerCase() === cityName.toLowerCase())
      return filterAndPaginateRestaurants(cityRestaurants, filters)
    }

    // Simulate API call
    await delay(800)

    const cityRestaurants = mockRestaurants.filter((rest) => rest.city.toLowerCase() === cityName.toLowerCase())
    return filterAndPaginateRestaurants(cityRestaurants, filters)
  } catch (error) {
    console.error(`Error fetching restaurants for city ${cityName}:`, error)
    throw error
  }
}

// Get restaurants by cuisine
export const getRestaurantsByCuisine = async (
  cuisine: string,
  filters?: SearchFilters,
): Promise<PaginatedResult<Restaurant>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Restaurant[]>(CACHE_KEYS.RESTAURANTS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const cuisineRestaurants = cachedData.filter((rest) =>
        rest.cuisine.some((c) => c.toLowerCase() === cuisine.toLowerCase()),
      )
      return filterAndPaginateRestaurants(cuisineRestaurants, filters)
    }

    // Simulate API call
    await delay(800)

    const cuisineRestaurants = mockRestaurants.filter((rest) =>
      rest.cuisine.some((c) => c.toLowerCase() === cuisine.toLowerCase()),
    )
    return filterAndPaginateRestaurants(cuisineRestaurants, filters)
  } catch (error) {
    console.error(`Error fetching restaurants with cuisine ${cuisine}:`, error)
    throw error
  }
}

// Get restaurants near coordinates
export const getRestaurantsNearCoordinates = async (
  coordinates: Coordinates,
  radiusKm = 5,
  filters?: SearchFilters,
): Promise<PaginatedResult<Restaurant>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Restaurant[]>(CACHE_KEYS.RESTAURANTS, CACHE_EXPIRATION.MEDIUM)
    let nearbyRestaurants: Restaurant[] = []

    if (cachedData) {
      nearbyRestaurants = cachedData.filter((rest) => {
        const distance = calculateDistance(
          coordinates.latitude,
          coordinates.longitude,
          rest.coordinates.latitude,
          rest.coordinates.longitude,
        )
        return distance <= radiusKm
      })
    } else {
      // Simulate API call
      await delay(1000)

      nearbyRestaurants = mockRestaurants.filter((rest) => {
        const distance = calculateDistance(
          coordinates.latitude,
          coordinates.longitude,
          rest.coordinates.latitude,
          rest.coordinates.longitude,
        )
        return distance <= radiusKm
      })

      // Cache the data
      await setCache(CACHE_KEYS.RESTAURANTS, mockRestaurants)
    }

    return filterAndPaginateRestaurants(nearbyRestaurants, filters)
  } catch (error) {
    console.error("Error fetching restaurants near coordinates:", error)
    throw error
  }
}

// Helper function to filter and paginate accommodations
const filterAndPaginateAccommodations = (
  accommodations: Accommodation[],
  filters?: SearchFilters,
): PaginatedResult<Accommodation> => {
  let filteredAccommodations = [...accommodations]

  if (filters) {
    // Apply query filter
    if (filters.query) {
      const query = filters.query.toLowerCase()
      filteredAccommodations = filteredAccommodations.filter(
        (acc) =>
          acc.name.toLowerCase().includes(query) ||
          acc.city.toLowerCase().includes(query) ||
          acc.country.toLowerCase().includes(query) ||
          acc.description?.toLowerCase().includes(query) ||
          acc.amenities?.some((amenity) => amenity.toLowerCase().includes(query)),
      )
    }

    // Apply category filter (accommodation type)
    if (filters.categories && filters.categories.length > 0) {
      filteredAccommodations = filteredAccommodations.filter((acc) => filters.categories!.includes(acc.type))
    }

    // Apply price range filter
    if (filters.priceRange) {
      if (filters.priceRange.min !== undefined) {
        filteredAccommodations = filteredAccommodations.filter((acc) => acc.price.amount >= filters.priceRange!.min!)
      }
      if (filters.priceRange.max !== undefined) {
        filteredAccommodations = filteredAccommodations.filter((acc) => acc.price.amount <= filters.priceRange!.max!)
      }
    }

    // Apply rating filter
    if (filters.rating) {
      filteredAccommodations = filteredAccommodations.filter((acc) => (acc.rating || 0) >= (filters.rating || 0))
    }

    // Apply features filter
    if (filters.features && filters.features.length > 0) {
      filteredAccommodations = filteredAccommodations.filter((acc) =>
        filters.features!.every((feature) => acc.amenities?.includes(feature)),
      )
    }

    // Apply sorting
    if (filters.sortBy) {
      switch (filters.sortBy) {
        case "relevance":
          // Default order
          break
        case "distance":
          // Would need user's location for this
          break
        case "rating":
          filteredAccommodations.sort((a, b) => (b.rating || 0) - (a.rating || 0))
          break
        case "price_low":
          filteredAccommodations.sort((a, b) => a.price.amount - b.price.amount)
          break
        case "price_high":
          filteredAccommodations.sort((a, b) => b.price.amount - a.price.amount)
          break
      }
    }
  }

  // Apply pagination
  const limit = filters?.limit || 10
  const offset = filters?.offset || 0
  const paginatedAccommodations = filteredAccommodations.slice(offset, offset + limit)

  return {
    items: paginatedAccommodations,
    total: filteredAccommodations.length,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit,
    hasMore: offset + limit < filteredAccommodations.length,
  }
}

// Helper function to filter and paginate restaurants
const filterAndPaginateRestaurants = (
  restaurants: Restaurant[],
  filters?: SearchFilters,
): PaginatedResult<Restaurant> => {
  let filteredRestaurants = [...restaurants]

  if (filters) {
    // Apply query filter
    if (filters.query) {
      const query = filters.query.toLowerCase()
      filteredRestaurants = filteredRestaurants.filter(
        (restaurant) =>
          restaurant.name.toLowerCase().includes(query) ||
          restaurant.city.toLowerCase().includes(query) ||
          restaurant.country.toLowerCase().includes(query) ||
          restaurant.description?.toLowerCase().includes(query) ||
          restaurant.cuisine.some((c) => c.toLowerCase().includes(query)) ||
          restaurant.features?.some((feature) => feature.toLowerCase().includes(query)),
      )
    }

    // Apply category filter (cuisine)
    if (filters.categories && filters.categories.length > 0) {
      filteredRestaurants = filteredRestaurants.filter((restaurant) =>
        restaurant.cuisine.some((c) => filters.categories!.includes(c)),
      )
    }

    // Apply price level filter
    if (filters.priceRange) {
      if (filters.priceRange.min !== undefined) {
        filteredRestaurants = filteredRestaurants.filter(
          (restaurant) => restaurant.priceLevel >= filters.priceRange!.min!,
        )
      }
      if (filters.priceRange.max !== undefined) {
        filteredRestaurants = filteredRestaurants.filter(
          (restaurant) => restaurant.priceLevel <= filters.priceRange!.max!,
        )
      }
    }

    // Apply rating filter
    if (filters.rating) {
      filteredRestaurants = filteredRestaurants.filter(
        (restaurant) => (restaurant.rating || 0) >= (filters.rating || 0),
      )
    }

    // Apply open now filter
    if (filters.openNow) {
      const now = new Date()
      const day = now.getDay()
      const time = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`

      const dayMap: Record<number, keyof (typeof mockRestaurants)[0]["openingHours"]> = {
        0: "sunday",
        1: "monday",
        2: "tuesday",
        3: "wednesday",
        4: "thursday",
        5: "friday",
        6: "saturday",
      }

      filteredRestaurants = filteredRestaurants.filter((restaurant) => {
        if (!restaurant.openingHours) return false

        const dayHours = restaurant.openingHours[dayMap[day]]
        if (!dayHours || dayHours.length === 0) return false

        return dayHours.some((hours) => hours.open <= time && time <= hours.close)
      })
    }

    // Apply features filter
    if (filters.features && filters.features.length > 0) {
      filteredRestaurants = filteredRestaurants.filter((restaurant) =>
        filters.features!.every((feature) => restaurant.features?.includes(feature)),
      )
    }

    // Apply sorting
    if (filters.sortBy) {
      switch (filters.sortBy) {
        case "relevance":
          // Default order
          break
        case "distance":
          // Would need user's location for this
          break
        case "rating":
          filteredRestaurants.sort((a, b) => (b.rating || 0) - (a.rating || 0))
          break
        case "price_low":
          filteredRestaurants.sort((a, b) => a.priceLevel - b.priceLevel)
          break
        case "price_high":
          filteredRestaurants.sort((a, b) => b.priceLevel - a.priceLevel)
          break
      }
    }
  }

  // Apply pagination
  const limit = filters?.limit || 10
  const offset = filters?.offset || 0
  const paginatedRestaurants = filteredRestaurants.slice(offset, offset + limit)

  return {
    items: paginatedRestaurants,
    total: filteredRestaurants.length,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit,
    hasMore: offset + limit < filteredRestaurants.length,
  }
}
