// Configuration for data integration services
export interface DataIntegrationConfig {
  apiKeys: {
    openWeatherMap?: string
    googleMaps?: string
    booking?: string
    amadeus?: string
    tripAdvisor?: string
    openAI?: string
    [key: string]: string | undefined
  }
  endpoints: {
    weather?: string
    maps?: string
    accommodation?: string
    flights?: string
    attractions?: string
    [key: string]: string | undefined
  }
  cacheOptions?: {
    enabled: boolean
    ttl: number // Time to live in seconds
  }
  offlineMode?: boolean
  debugMode?: boolean
}

// Base interface for all services
export interface BaseService {
  initialize(config: DataIntegrationConfig): void
}

// Destination related types
export interface Destination {
  id: string
  name: string
  type: "city" | "park" | "landmark" | "region" | "country"
  coordinates: {
    latitude: number
    longitude: number
  }
  description?: string
  images?: string[]
  rating?: number
  tags?: string[]
  popularity?: number
}

export interface PointOfInterest {
  id: string
  name: string
  type: "restaurant" | "hotel" | "attraction" | "shop" | "transport" | "other"
  coordinates: {
    latitude: number
    longitude: number
  }
  description?: string
  images?: string[]
  rating?: number
  priceLevel?: number // 1-5
  openingHours?: {
    [day: string]: string
  }
  contactInfo?: {
    phone?: string
    email?: string
    website?: string
  }
  address?: string
  tags?: string[]
}

export interface SearchFilters {
  query?: string
  types?: string[]
  priceRange?: {
    min: number
    max: number
  }
  rating?: number
  tags?: string[]
  coordinates?: {
    latitude: number
    longitude: number
    radius: number // in kilometers
  }
}

// Navigation related types
export interface Route {
  id: string
  name?: string
  origin: {
    latitude: number
    longitude: number
    name?: string
  }
  destination: {
    latitude: number
    longitude: number
    name?: string
  }
  waypoints?: {
    latitude: number
    longitude: number
    name?: string
  }[]
  distance: number // in kilometers
  duration: number // in minutes
  mode: "driving" | "walking" | "cycling" | "transit" | "hiking"
  polyline?: string // Encoded polyline
  elevation?: number[] // Elevation data along the route
  difficulty?: "easy" | "moderate" | "hard" | "extreme"
  instructions?: RouteInstruction[]
  trafficInfo?: TrafficInfo
}

export interface RouteInstruction {
  index: number
  distance: number // in meters
  duration: number // in seconds
  instruction: string
  maneuver?: string
  coordinates: {
    latitude: number
    longitude: number
  }
}

export interface TrafficInfo {
  congestionLevel: "low" | "moderate" | "high" | "severe"
  incidents?: {
    type: "accident" | "construction" | "closure" | "event"
    description: string
    coordinates: {
      latitude: number
      longitude: number
    }
  }[]
}

// Accommodation related types
export interface Accommodation {
  id: string
  name: string
  type: "hotel" | "hostel" | "apartment" | "guesthouse" | "resort" | "camping"
  coordinates: {
    latitude: number
    longitude: number
  }
  address: string
  rating?: number
  pricePerNight: number
  currency: string
  amenities?: string[]
  images?: string[]
  description?: string
  contactInfo?: {
    phone?: string
    email?: string
    website?: string
  }
  availability?: {
    startDate: string
    endDate: string
    available: boolean
  }[]
  reviews?: {
    rating: number
    comment: string
    author: string
    date: string
  }[]
}

export interface AccommodationFilters extends SearchFilters {
  priceRange?: {
    min: number
    max: number
  }
  amenities?: string[]
  accommodationType?: string[]
  dates?: {
    checkIn: string
    checkOut: string
  }
  guests?: {
    adults: number
    children: number
    rooms: number
  }
}

// Weather related types
export interface WeatherForecast {
  location: {
    name: string
    coordinates: {
      latitude: number
      longitude: number
    }
  }
  current?: WeatherCondition
  hourly?: WeatherCondition[]
  daily?: DailyWeatherForecast[]
  alerts?: WeatherAlert[]
}

export interface WeatherCondition {
  timestamp: number
  temperature: number
  feelsLike: number
  humidity: number
  windSpeed: number
  windDirection: number
  precipitation: number
  pressure: number
  visibility: number
  uvIndex: number
  condition: {
    main: string
    description: string
    icon: string
  }
}

export interface DailyWeatherForecast {
  date: string
  sunrise: number
  sunset: number
  temperature: {
    min: number
    max: number
    morning: number
    day: number
    evening: number
    night: number
  }
  feelsLike: {
    morning: number
    day: number
    evening: number
    night: number
  }
  humidity: number
  windSpeed: number
  windDirection: number
  precipitation: {
    probability: number
    amount: number
  }
  condition: {
    main: string
    description: string
    icon: string
  }
}

export interface WeatherAlert {
  senderName: string
  event: string
  start: number
  end: number
  description: string
  severity: "minor" | "moderate" | "severe" | "extreme"
}

// User preferences related types
export interface UserPreferences {
  id: string
  userId: string
  travelPreferences: {
    preferredTransportation: string[]
    preferredAccommodation: string[]
    budgetRange: {
      min: number
      max: number
      currency: string
    }
    interests: string[]
    dietaryRestrictions: string[]
    accessibility: string[]
  }
  appPreferences: {
    darkMode: boolean
    language: string
    units: "metric" | "imperial"
    notifications: {
      enabled: boolean
      types: string[]
    }
    privacySettings: {
      shareLocation: boolean
      shareActivity: boolean
      allowAnalytics: boolean
    }
  }
  savedItems: {
    destinations: string[]
    routes: string[]
    accommodations: string[]
    pointsOfInterest: string[]
  }
  history: {
    searches: {
      query: string
      timestamp: number
    }[]
    viewedItems: {
      itemId: string
      itemType: string
      timestamp: number
    }[]
  }
}

// Travel package related types
export interface TravelPackage {
  id: string
  name: string
  description: string
  destination: {
    id: string
    name: string
  }
  duration: number // in days
  price: number
  currency: string
  inclusions: string[]
  exclusions: string[]
  itinerary: {
    day: number
    activities: {
      time: string
      description: string
      location?: {
        name: string
        coordinates?: {
          latitude: number
          longitude: number
        }
      }
      duration: number // in minutes
      included: boolean
    }[]
  }[]
  accommodation?: {
    id: string
    name: string
    type: string
    rating?: number
  }
  transportation?: {
    type: string
    details: string
  }
  images?: string[]
  startDates?: string[]
  maxGroupSize?: number
  minAge?: number
  difficulty?: "easy" | "moderate" | "challenging" | "difficult"
  tags?: string[]
}

// Analytics related types
export interface AnalyticsEvent {
  eventName: string
  timestamp: number
  userId?: string
  sessionId: string
  properties: {
    [key: string]: any
  }
}

export interface AnalyticsReport {
  reportId: string
  reportName: string
  timeRange: {
    start: string
    end: string
  }
  metrics: {
    name: string
    value: number
    change?: number // Percentage change from previous period
  }[]
  dimensions?: {
    name: string
    values: {
      name: string
      count: number
      percentage: number
    }[]
  }[]
}

// Utility service types
export interface CurrencyConversion {
  from: string
  to: string
  rate: number
  amount: number
  convertedAmount: number
  timestamp: number
}

export interface TranslationRequest {
  text: string
  from: string
  to: string
}

export interface TranslationResponse {
  originalText: string
  translatedText: string
  from: string
  to: string
}

export interface EmergencyContact {
  country: string
  police: string
  ambulance: string
  fire: string
  embassy?: {
    [country: string]: {
      address: string
      phone: string
      email?: string
    }
  }
}
