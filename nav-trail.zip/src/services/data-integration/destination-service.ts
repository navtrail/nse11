import type { City, PointOfInterest, SearchFilters, PaginatedResult, Coordinates, OpeningHours } from "./types"
import { CACHE_KEYS, CACHE_EXPIRATION, getCache, setCache, delay, calculateDistance } from "./utils"

// Mock data for cities
const mockCities: City[] = [
  {
    id: "city-001",
    name: "Paris",
    country: "France",
    countryCode: "FR",
    coordinates: { latitude: 48.8566, longitude: 2.3522 },
    timezone: "Europe/Paris",
    region: "Île-de-France",
    language: ["French"],
    currency: "EUR",
    population: 2148271,
    description:
      "Paris, France's capital, is a major European city and a global center for art, fashion, gastronomy and culture.",
    imageUrl: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34",
  },
  {
    id: "city-002",
    name: "Tokyo",
    country: "Japan",
    countryCode: "JP",
    coordinates: { latitude: 35.6762, longitude: 139.6503 },
    timezone: "Asia/Tokyo",
    region: "Kanto",
    language: ["Japanese"],
    currency: "JPY",
    population: 13929286,
    description:
      "Tokyo, Japan's busy capital, mixes the ultramodern and the traditional, from neon-lit skyscrapers to historic temples.",
    imageUrl: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26",
  },
  {
    id: "city-003",
    name: "New York",
    country: "United States",
    countryCode: "US",
    coordinates: { latitude: 40.7128, longitude: -74.006 },
    timezone: "America/New_York",
    region: "New York State",
    language: ["English"],
    currency: "USD",
    population: 8336817,
    description: "New York City comprises 5 boroughs sitting where the Hudson River meets the Atlantic Ocean.",
    imageUrl: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9",
  },
  {
    id: "city-004",
    name: "Rome",
    country: "Italy",
    countryCode: "IT",
    coordinates: { latitude: 41.9028, longitude: 12.4964 },
    timezone: "Europe/Rome",
    region: "Lazio",
    language: ["Italian"],
    currency: "EUR",
    population: 2872800,
    description:
      "Rome, Italy's capital, is a sprawling, cosmopolitan city with nearly 3,000 years of globally influential art, architecture and culture on display.",
    imageUrl: "https://images.unsplash.com/photo-1529260830199-42c24126f198",
  },
  {
    id: "city-005",
    name: "Sydney",
    country: "Australia",
    countryCode: "AU",
    coordinates: { latitude: -33.8688, longitude: 151.2093 },
    timezone: "Australia/Sydney",
    region: "New South Wales",
    language: ["English"],
    currency: "AUD",
    population: 5312163,
    description:
      "Sydney, capital of New South Wales and one of Australia's largest cities, is best known for its harbourfront Sydney Opera House.",
    imageUrl: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9",
  },
  {
    id: "city-006",
    name: "Cairo",
    country: "Egypt",
    countryCode: "EG",
    coordinates: { latitude: 30.0444, longitude: 31.2357 },
    timezone: "Africa/Cairo",
    region: "Cairo Governorate",
    language: ["Arabic"],
    currency: "EGP",
    population: 9500000,
    description:
      "Cairo, Egypt's sprawling capital, is set on the Nile River. At its heart is Tahrir Square and the vast Egyptian Museum.",
    imageUrl: "https://images.unsplash.com/photo-1572252009286-268acec5ca0a",
  },
  {
    id: "city-007",
    name: "Rio de Janeiro",
    country: "Brazil",
    countryCode: "BR",
    coordinates: { latitude: -22.9068, longitude: -43.1729 },
    timezone: "America/Sao_Paulo",
    region: "Rio de Janeiro State",
    language: ["Portuguese"],
    currency: "BRL",
    population: 6747815,
    description:
      "Rio de Janeiro is a huge seaside city in Brazil, famed for its Copacabana and Ipanema beaches, 38m Christ the Redeemer statue atop Mount Corcovado and for Sugarloaf Mountain.",
    imageUrl: "https://images.unsplash.com/photo-1483729558449-99ef09a8c325",
  },
  {
    id: "city-008",
    name: "Cape Town",
    country: "South Africa",
    countryCode: "ZA",
    coordinates: { latitude: -33.9249, longitude: 18.4241 },
    timezone: "Africa/Johannesburg",
    region: "Western Cape",
    language: ["English", "Afrikaans", "Xhosa"],
    currency: "ZAR",
    population: 433688,
    description:
      "Cape Town is a port city on South Africa's southwest coast, on a peninsula beneath the imposing Table Mountain.",
    imageUrl: "https://images.unsplash.com/photo-1580060839134-75a5edca2e99",
  },
  {
    id: "city-009",
    name: "Bangkok",
    country: "Thailand",
    countryCode: "TH",
    coordinates: { latitude: 13.7563, longitude: 100.5018 },
    timezone: "Asia/Bangkok",
    region: "Central Thailand",
    language: ["Thai"],
    currency: "THB",
    population: 8305218,
    description: "Bangkok, Thailand's capital, is a large city known for ornate shrines and vibrant street life.",
    imageUrl: "https://images.unsplash.com/photo-1508009603885-50cf7c8dd0d5",
  },
  {
    id: "city-010",
    name: "Mumbai",
    country: "India",
    countryCode: "IN",
    coordinates: { latitude: 19.076, longitude: 72.8777 },
    timezone: "Asia/Kolkata",
    region: "Maharashtra",
    language: ["Hindi", "Marathi", "English"],
    currency: "INR",
    population: 12442373,
    description: "Mumbai (formerly called Bombay) is a densely populated city on India's west coast.",
    imageUrl: "https://images.unsplash.com/photo-1529253355930-ddbe423a2ac7",
  },
]

// Mock data for POIs
const mockPOIs: PointOfInterest[] = [
  {
    id: "poi-001",
    name: "Eiffel Tower",
    type: "landmark",
    coordinates: { latitude: 48.8584, longitude: 2.2945 },
    city: "Paris",
    country: "France",
    description: "Iconic wrought-iron tower on the Champ de Mars in Paris, France.",
    rating: 4.7,
    reviewCount: 140356,
    popularity: 9.8,
    openingHours: {
      monday: [{ open: "09:00", close: "23:45" }],
      tuesday: [{ open: "09:00", close: "23:45" }],
      wednesday: [{ open: "09:00", close: "23:45" }],
      thursday: [{ open: "09:00", close: "23:45" }],
      friday: [{ open: "09:00", close: "23:45" }],
      saturday: [{ open: "09:00", close: "23:45" }],
      sunday: [{ open: "09:00", close: "23:45" }],
    },
    entryFee: {
      amount: 25.9,
      currency: "EUR",
    },
    bestTimeToVisit: ["Spring", "Fall", "Evening"],
    images: [
      "https://images.unsplash.com/photo-1543349689-9a4d426bee8e",
      "https://images.unsplash.com/photo-1511739001486-6bfe10ce785f",
    ],
    tags: ["iconic", "tower", "view", "romantic"],
    address: "Champ de Mars, 5 Avenue Anatole France, 75007 Paris, France",
    website: "https://www.toureiffel.paris/en",
    contactInfo: "+33 892 70 12 39",
  },
  {
    id: "poi-002",
    name: "Louvre Museum",
    type: "museum",
    coordinates: { latitude: 48.8606, longitude: 2.3376 },
    city: "Paris",
    country: "France",
    description: "The world's largest art museum and a historic monument in Paris, France.",
    rating: 4.8,
    reviewCount: 201478,
    popularity: 9.7,
    openingHours: {
      monday: [{ open: "09:00", close: "18:00" }],
      tuesday: [], // Closed
      wednesday: [{ open: "09:00", close: "18:00" }],
      thursday: [{ open: "09:00", close: "18:00" }],
      friday: [{ open: "09:00", close: "21:45" }],
      saturday: [{ open: "09:00", close: "18:00" }],
      sunday: [{ open: "09:00", close: "18:00" }],
    },
    entryFee: {
      amount: 17,
      currency: "EUR",
    },
    bestTimeToVisit: ["Weekday", "Morning", "Evening on Friday"],
    images: [
      "https://images.unsplash.com/photo-1499856871958-5b9357976b82",
      "https://images.unsplash.com/photo-1605101479435-005f9c563944",
    ],
    tags: ["art", "museum", "history", "culture"],
    address: "Rue de Rivoli, 75001 Paris, France",
    website: "https://www.louvre.fr/en",
    contactInfo: "+33 1 40 20 50 50",
  },
  {
    id: "poi-003",
    name: "Tokyo Skytree",
    type: "landmark",
    coordinates: { latitude: 35.7101, longitude: 139.8107 },
    city: "Tokyo",
    country: "Japan",
    description: "A broadcasting and observation tower in Sumida, Tokyo, and the tallest structure in Japan.",
    rating: 4.5,
    reviewCount: 87654,
    popularity: 9.2,
    openingHours: {
      monday: [{ open: "10:00", close: "21:00" }],
      tuesday: [{ open: "10:00", close: "21:00" }],
      wednesday: [{ open: "10:00", close: "21:00" }],
      thursday: [{ open: "10:00", close: "21:00" }],
      friday: [{ open: "10:00", close: "21:00" }],
      saturday: [{ open: "10:00", close: "21:00" }],
      sunday: [{ open: "10:00", close: "21:00" }],
    },
    entryFee: {
      amount: 2100,
      currency: "JPY",
    },
    bestTimeToVisit: ["Evening", "Clear day"],
    images: [
      "https://images.unsplash.com/photo-1536098561742-ca998e48cbcc",
      "https://images.unsplash.com/photo-1526481280693-3bfa7568e0f3",
    ],
    tags: ["tower", "view", "modern"],
    address: "1 Chome-1-2 Oshiage, Sumida City, Tokyo 131-0045, Japan",
    website: "http://www.tokyo-skytree.jp/en/",
    contactInfo: "+81 570-550-634",
  },
  {
    id: "poi-004",
    name: "Central Park",
    type: "nature",
    coordinates: { latitude: 40.7829, longitude: -73.9654 },
    city: "New York",
    country: "United States",
    description: "An urban park in Manhattan, New York City, located between the Upper West and Upper East Sides.",
    rating: 4.9,
    reviewCount: 189753,
    popularity: 9.6,
    openingHours: {
      monday: [{ open: "06:00", close: "01:00" }],
      tuesday: [{ open: "06:00", close: "01:00" }],
      wednesday: [{ open: "06:00", close: "01:00" }],
      thursday: [{ open: "06:00", close: "01:00" }],
      friday: [{ open: "06:00", close: "01:00" }],
      saturday: [{ open: "06:00", close: "01:00" }],
      sunday: [{ open: "06:00", close: "01:00" }],
    },
    entryFee: {
      amount: 0,
      currency: "USD",
    },
    bestTimeToVisit: ["Spring", "Fall", "Morning"],
    images: [
      "https://images.unsplash.com/photo-1534251369789-5067c8b8602a",
      "https://images.unsplash.com/photo-1569155828039-7d42e86c4ce9",
    ],
    tags: ["park", "nature", "recreation", "walking"],
    address: "Central Park, New York, NY, USA",
    website: "https://www.centralparknyc.org/",
    contactInfo: "+1 212-310-6600",
  },
  {
    id: "poi-005",
    name: "Colosseum",
    type: "historic_site",
    coordinates: { latitude: 41.8902, longitude: 12.4922 },
    city: "Rome",
    country: "Italy",
    description:
      "An oval amphitheatre in the centre of the city of Rome, Italy, the largest ancient amphitheatre ever built.",
    rating: 4.8,
    reviewCount: 234567,
    popularity: 9.9,
    openingHours: {
      monday: [{ open: "08:30", close: "19:00" }],
      tuesday: [{ open: "08:30", close: "19:00" }],
      wednesday: [{ open: "08:30", close: "19:00" }],
      thursday: [{ open: "08:30", close: "19:00" }],
      friday: [{ open: "08:30", close: "19:00" }],
      saturday: [{ open: "08:30", close: "19:00" }],
      sunday: [{ open: "08:30", close: "19:00" }],
    },
    entryFee: {
      amount: 16,
      currency: "EUR",
    },
    bestTimeToVisit: ["Early morning", "Late afternoon", "Off-season"],
    images: [
      "https://images.unsplash.com/photo-1552832230-c0197dd311b5",
      "https://images.unsplash.com/photo-1604580864964-0462f5d5b1a8",
    ],
    tags: ["ancient", "history", "architecture", "roman"],
    address: "Piazza del Colosseo, 1, 00184 Roma RM, Italy",
    website: "https://www.parcocolosseo.it/en/",
    contactInfo: "+39 06 3996 7700",
  },
  {
    id: "poi-006",
    name: "Sydney Opera House",
    type: "landmark",
    coordinates: { latitude: -33.8568, longitude: 151.2153 },
    city: "Sydney",
    country: "Australia",
    description:
      "A multi-venue performing arts centre at Sydney Harbour, identified as one of the 20th century's most distinctive buildings.",
    rating: 4.7,
    reviewCount: 156789,
    popularity: 9.5,
    openingHours: {
      monday: [{ open: "09:00", close: "17:00" }],
      tuesday: [{ open: "09:00", close: "17:00" }],
      wednesday: [{ open: "09:00", close: "17:00" }],
      thursday: [{ open: "09:00", close: "17:00" }],
      friday: [{ open: "09:00", close: "17:00" }],
      saturday: [{ open: "09:00", close: "17:00" }],
      sunday: [{ open: "09:00", close: "17:00" }],
    },
    entryFee: {
      amount: 42,
      currency: "AUD",
    },
    bestTimeToVisit: ["Morning", "Sunset"],
    images: [
      "https://images.unsplash.com/photo-1549180030-48bf079fb38a",
      "https://images.unsplash.com/photo-1524293581917-878a6d017c71",
    ],
    tags: ["architecture", "arts", "iconic", "harbour"],
    address: "Bennelong Point, Sydney NSW 2000, Australia",
    website: "https://www.sydneyoperahouse.com/",
    contactInfo: "+61 2 9250 7111",
  },
  {
    id: "poi-007",
    name: "Great Pyramids of Giza",
    type: "historic_site",
    coordinates: { latitude: 29.9792, longitude: 31.1342 },
    city: "Cairo",
    country: "Egypt",
    description:
      "The oldest and largest of the three pyramids in the Giza pyramid complex, the only one of the Seven Wonders of the Ancient World still in existence.",
    rating: 4.8,
    reviewCount: 178945,
    popularity: 9.7,
    openingHours: {
      monday: [{ open: "08:00", close: "17:00" }],
      tuesday: [{ open: "08:00", close: "17:00" }],
      wednesday: [{ open: "08:00", close: "17:00" }],
      thursday: [{ open: "08:00", close: "17:00" }],
      friday: [{ open: "08:00", close: "17:00" }],
      saturday: [{ open: "08:00", close: "17:00" }],
      sunday: [{ open: "08:00", close: "17:00" }],
    },
    entryFee: {
      amount: 200,
      currency: "EGP",
    },
    bestTimeToVisit: ["Early morning", "Late afternoon", "Winter"],
    images: [
      "https://images.unsplash.com/photo-1503177119275-0aa32b3a9368",
      "https://images.unsplash.com/photo-1568322445389-f64ac2515020",
    ],
    tags: ["ancient", "history", "wonder", "archaeology"],
    address: "Al Haram, Giza Governorate, Egypt",
    website: "https://egymonuments.gov.eg/",
    contactInfo: "+20 2 33777263",
  },
  {
    id: "poi-008",
    name: "Christ the Redeemer",
    type: "landmark",
    coordinates: { latitude: -22.9519, longitude: -43.2106 },
    city: "Rio de Janeiro",
    country: "Brazil",
    description:
      "An Art Deco statue of Jesus Christ in Rio de Janeiro, Brazil, created by French sculptor Paul Landowski.",
    rating: 4.7,
    reviewCount: 145678,
    popularity: 9.4,
    openingHours: {
      monday: [{ open: "08:00", close: "19:00" }],
      tuesday: [{ open: "08:00", close: "19:00" }],
      wednesday: [{ open: "08:00", close: "19:00" }],
      thursday: [{ open: "08:00", close: "19:00" }],
      friday: [{ open: "08:00", close: "19:00" }],
      saturday: [{ open: "08:00", close: "19:00" }],
      sunday: [{ open: "08:00", close: "19:00" }],
    },
    entryFee: {
      amount: 84,
      currency: "BRL",
    },
    bestTimeToVisit: ["Morning", "Clear day"],
    images: [
      "https://images.unsplash.com/photo-1564659907532-6b5f98c8e70f",
      "https://images.unsplash.com/photo-1516306580123-e6e52b1b7b5f",
    ],
    tags: ["statue", "view", "iconic", "religious"],
    address: "Parque Nacional da Tijuca - Alto da Boa Vista, Rio de Janeiro - RJ, Brazil",
    website: "https://en.cristoredentoroficial.com.br/",
    contactInfo: "+55 21 2492-2252",
  },
  {
    id: "poi-009",
    name: "Table Mountain",
    type: "nature",
    coordinates: { latitude: -33.9628, longitude: 18.4098 },
    city: "Cape Town",
    country: "South Africa",
    description:
      "A flat-topped mountain forming a prominent landmark overlooking the city of Cape Town in South Africa.",
    rating: 4.9,
    reviewCount: 98765,
    popularity: 9.3,
    openingHours: {
      monday: [{ open: "08:30", close: "18:00" }],
      tuesday: [{ open: "08:30", close: "18:00" }],
      wednesday: [{ open: "08:30", close: "18:00" }],
      thursday: [{ open: "08:30", close: "18:00" }],
      friday: [{ open: "08:30", close: "18:00" }],
      saturday: [{ open: "08:30", close: "18:00" }],
      sunday: [{ open: "08:30", close: "18:00" }],
    },
    entryFee: {
      amount: 380,
      currency: "ZAR",
    },
    bestTimeToVisit: ["Early morning", "Clear day"],
    images: [
      "https://images.unsplash.com/photo-1578301978693-85fa9c0320b9",
      "https://images.unsplash.com/photo-1576662236292-c1536656b56d",
    ],
    tags: ["mountain", "hiking", "view", "nature"],
    address: "Table Mountain (Nature Reserve), Cape Town, South Africa",
    website: "https://tablemountain.net/",
    contactInfo: "+27 21 424 8181",
  },
  {
    id: "poi-010",
    name: "Grand Palace",
    type: "historic_site",
    coordinates: { latitude: 13.75, longitude: 100.4914 },
    city: "Bangkok",
    country: "Thailand",
    description:
      "A complex of buildings at the heart of Bangkok, Thailand, serving as the official residence of the Kings of Siam since 1782.",
    rating: 4.6,
    reviewCount: 123456,
    popularity: 9.1,
    openingHours: {
      monday: [{ open: "08:30", close: "15:30" }],
      tuesday: [{ open: "08:30", close: "15:30" }],
      wednesday: [{ open: "08:30", close: "15:30" }],
      thursday: [{ open: "08:30", close: "15:30" }],
      friday: [{ open: "08:30", close: "15:30" }],
      saturday: [{ open: "08:30", close: "15:30" }],
      sunday: [{ open: "08:30", close: "15:30" }],
    },
    entryFee: {
      amount: 500,
      currency: "THB",
    },
    bestTimeToVisit: ["Morning", "Weekday"],
    images: [
      "https://images.unsplash.com/photo-1528181304800-259b08848526",
      "https://images.unsplash.com/photo-1562602833-0f4ab2fc46e3",
    ],
    tags: ["palace", "temple", "history", "architecture"],
    address: "Na Phra Lan Rd, Phra Borom Maha Ratchawang, Phra Nakhon, Bangkok 10200, Thailand",
    website: "https://www.royalgrandpalace.th/en/home",
    contactInfo: "+66 2 623 5500",
  },
  {
    id: "poi-011",
    name: "Gateway of India",
    type: "landmark",
    coordinates: { latitude: 18.922, longitude: 72.8347 },
    city: "Mumbai",
    country: "India",
    description: "An arch-monument built in the early 20th century in the city of Mumbai, India.",
    rating: 4.5,
    reviewCount: 87654,
    popularity: 8.9,
    openingHours: {
      monday: [{ open: "00:00", close: "23:59" }], // 24 hours
      tuesday: [{ open: "00:00", close: "23:59" }],
      wednesday: [{ open: "00:00", close: "23:59" }],
      thursday: [{ open: "00:00", close: "23:59" }],
      friday: [{ open: "00:00", close: "23:59" }],
      saturday: [{ open: "00:00", close: "23:59" }],
      sunday: [{ open: "00:00", close: "23:59" }],
    },
    entryFee: {
      amount: 0,
      currency: "INR",
    },
    bestTimeToVisit: ["Early morning", "Evening", "Weekday"],
    images: [
      "https://images.unsplash.com/photo-1570168007204-dfb528c6958f",
      "https://images.unsplash.com/photo-1567157577867-05ccb1388e66",
    ],
    tags: ["monument", "history", "architecture", "waterfront"],
    address: "Apollo Bandar, Colaba, Mumbai, Maharashtra 400001, India",
    website: "https://www.maharashtratourism.gov.in/",
    contactInfo: "+91 22 2284 4430",
  },
  {
    id: "poi-012",
    name: "Montmartre",
    type: "hidden_gem",
    coordinates: { latitude: 48.8867, longitude: 2.3431 },
    city: "Paris",
    country: "France",
    description:
      "A large hill in Paris's 18th arrondissement, known for its artistic history, the white-domed Basilica of the Sacré-Cœur, and as a nightclub district.",
    rating: 4.7,
    reviewCount: 98765,
    popularity: 8.8,
    openingHours: {
      monday: [{ open: "00:00", close: "23:59" }], // 24 hours
      tuesday: [{ open: "00:00", close: "23:59" }],
      wednesday: [{ open: "00:00", close: "23:59" }],
      thursday: [{ open: "00:00", close: "23:59" }],
      friday: [{ open: "00:00", close: "23:59" }],
      saturday: [{ open: "00:00", close: "23:59" }],
      sunday: [{ open: "00:00", close: "23:59" }],
    },
    entryFee: {
      amount: 0,
      currency: "EUR",
    },
    bestTimeToVisit: ["Morning", "Sunset", "Weekday"],
    images: [
      "https://images.unsplash.com/photo-1550340499-a6c60f8c7e87",
      "https://images.unsplash.com/photo-1574843513262-1f7a2ef1d6a1",
    ],
    tags: ["art", "culture", "view", "bohemian"],
    address: "Montmartre, 75018 Paris, France",
    isHiddenGem: true,
  },
  {
    id: "poi-013",
    name: "Yanaka Ginza",
    type: "hidden_gem",
    coordinates: { latitude: 35.7277, longitude: 139.7667 },
    city: "Tokyo",
    country: "Japan",
    description:
      "A traditional shopping street in the Yanaka district of Tokyo, offering a glimpse into old Tokyo with its retro atmosphere.",
    rating: 4.6,
    reviewCount: 12345,
    popularity: 7.9,
    openingHours: {
      monday: [{ open: "10:00", close: "18:00" }],
      tuesday: [{ open: "10:00", close: "18:00" }],
      wednesday: [{ open: "10:00", close: "18:00" }],
      thursday: [{ open: "10:00", close: "18:00" }],
      friday: [{ open: "10:00", close: "18:00" }],
      saturday: [{ open: "10:00", close: "18:00" }],
      sunday: [{ open: "10:00", close: "18:00" }],
    },
    entryFee: {
      amount: 0,
      currency: "JPY",
    },
    bestTimeToVisit: ["Afternoon", "Weekday"],
    images: [
      "https://images.unsplash.com/photo-1617339860293-8c1b58e7c87e",
      "https://images.unsplash.com/photo-1617339860293-8c1b58e7c87e",
    ],
    tags: ["shopping", "traditional", "local", "food"],
    address: "Yanaka Ginza, 3 Chome-13 Yanaka, Taito City, Tokyo 110-0001, Japan",
    isHiddenGem: true,
  },
  {
    id: "poi-014",
    name: "The High Line",
    type: "hidden_gem",
    coordinates: { latitude: 40.748, longitude: -74.0048 },
    city: "New York",
    country: "United States",
    description:
      "A 1.45-mile-long elevated linear park, greenway and rail trail created on a former New York Central Railroad spur on the west side of Manhattan.",
    rating: 4.8,
    reviewCount: 87654,
    popularity: 8.7,
    openingHours: {
      monday: [{ open: "07:00", close: "22:00" }],
      tuesday: [{ open: "07:00", close: "22:00" }],
      wednesday: [{ open: "07:00", close: "22:00" }],
      thursday: [{ open: "07:00", close: "22:00" }],
      friday: [{ open: "07:00", close: "22:00" }],
      saturday: [{ open: "07:00", close: "22:00" }],
      sunday: [{ open: "07:00", close: "22:00" }],
    },
    entryFee: {
      amount: 0,
      currency: "USD",
    },
    bestTimeToVisit: ["Morning", "Sunset", "Weekday"],
    images: [
      "https://images.unsplash.com/photo-1498354136128-58f790194fa7",
      "https://images.unsplash.com/photo-1558370781-d6196949e317",
    ],
    tags: ["park", "urban", "walking", "art"],
    address: "The High Line, New York, NY 10011, USA",
    website: "https://www.thehighline.org/",
    contactInfo: "+1 212-500-6035",
    isHiddenGem: true,
  },
  {
    id: "poi-015",
    name: "Trastevere",
    type: "hidden_gem",
    coordinates: { latitude: 41.8891, longitude: 12.4696 },
    city: "Rome",
    country: "Italy",
    description:
      "A charming neighborhood in Rome known for its narrow streets, traditional trattorias, and authentic Roman atmosphere.",
    rating: 4.7,
    reviewCount: 54321,
    popularity: 8.5,
    openingHours: {
      monday: [{ open: "00:00", close: "23:59" }], // 24 hours
      tuesday: [{ open: "00:00", close: "23:59" }],
      wednesday: [{ open: "00:00", close: "23:59" }],
      thursday: [{ open: "00:00", close: "23:59" }],
      friday: [{ open: "00:00", close: "23:59" }],
      saturday: [{ open: "00:00", close: "23:59" }],
      sunday: [{ open: "00:00", close: "23:59" }],
    },
    entryFee: {
      amount: 0,
      currency: "EUR",
    },
    bestTimeToVisit: ["Evening", "Weekday"],
    images: [
      "https://images.unsplash.com/photo-1529154166925-574a0236a4f4",
      "https://images.unsplash.com/photo-1525874684015-58379d421a52",
    ],
    tags: ["neighborhood", "food", "nightlife", "authentic"],
    address: "Trastevere, Rome, Italy",
    isHiddenGem: true,
  },
]

// Get all cities
export const getCities = async (filters?: SearchFilters): Promise<PaginatedResult<City>> => {
  try {
    // Check cache first
    const cachedData = await getCache<City[]>(CACHE_KEYS.DESTINATIONS, CACHE_EXPIRATION.LONG)
    if (cachedData) {
      return filterAndPaginateCities(cachedData, filters)
    }

    // Simulate API call
    await delay(1000)

    // Cache the data
    await setCache(CACHE_KEYS.DESTINATIONS, mockCities)

    return filterAndPaginateCities(mockCities, filters)
  } catch (error) {
    console.error("Error fetching cities:", error)
    throw error
  }
}

// Get city by ID
export const getCityById = async (id: string): Promise<City | null> => {
  try {
    // Check cache first
    const cachedData = await getCache<City[]>(CACHE_KEYS.DESTINATIONS, CACHE_EXPIRATION.LONG)
    if (cachedData) {
      const city = cachedData.find((city) => city.id === id)
      return city || null
    }

    // Simulate API call
    await delay(500)

    const city = mockCities.find((city) => city.id === id)
    return city || null
  } catch (error) {
    console.error(`Error fetching city with ID ${id}:`, error)
    throw error
  }
}

// Get all POIs
export const getPOIs = async (filters?: SearchFilters): Promise<PaginatedResult<PointOfInterest>> => {
  try {
    // Check cache first
    const cachedData = await getCache<PointOfInterest[]>(CACHE_KEYS.POIS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      return filterAndPaginatePOIs(cachedData, filters)
    }

    // Simulate API call
    await delay(1200)

    // Cache the data
    await setCache(CACHE_KEYS.POIS, mockPOIs)

    return filterAndPaginatePOIs(mockPOIs, filters)
  } catch (error) {
    console.error("Error fetching POIs:", error)
    throw error
  }
}

// Get POI by ID
export const getPOIById = async (id: string): Promise<PointOfInterest | null> => {
  try {
    // Check cache first
    const cachedData = await getCache<PointOfInterest[]>(CACHE_KEYS.POIS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const poi = cachedData.find((poi) => poi.id === id)
      return poi || null
    }

    // Simulate API call
    await delay(500)

    const poi = mockPOIs.find((poi) => poi.id === id)
    return poi || null
  } catch (error) {
    console.error(`Error fetching POI with ID ${id}:`, error)
    throw error
  }
}

// Get POIs by city
export const getPOIsByCity = async (
  cityName: string,
  filters?: SearchFilters,
): Promise<PaginatedResult<PointOfInterest>> => {
  try {
    // Check cache first
    const cachedData = await getCache<PointOfInterest[]>(CACHE_KEYS.POIS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const cityPOIs = cachedData.filter((poi) => poi.city.toLowerCase() === cityName.toLowerCase())
      return filterAndPaginatePOIs(cityPOIs, filters)
    }

    // Simulate API call
    await delay(800)

    const cityPOIs = mockPOIs.filter((poi) => poi.city.toLowerCase() === cityName.toLowerCase())
    return filterAndPaginatePOIs(cityPOIs, filters)
  } catch (error) {
    console.error(`Error fetching POIs for city ${cityName}:`, error)
    throw error
  }
}

// Get POIs by type
export const getPOIsByType = async (
  type: string,
  filters?: SearchFilters,
): Promise<PaginatedResult<PointOfInterest>> => {
  try {
    // Check cache first
    const cachedData = await getCache<PointOfInterest[]>(CACHE_KEYS.POIS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const typePOIs = cachedData.filter((poi) => poi.type.toLowerCase() === type.toLowerCase())
      return filterAndPaginatePOIs(typePOIs, filters)
    }

    // Simulate API call
    await delay(800)

    const typePOIs = mockPOIs.filter((poi) => poi.type.toLowerCase() === type.toLowerCase())
    return filterAndPaginatePOIs(typePOIs, filters)
  } catch (error) {
    console.error(`Error fetching POIs of type ${type}:`, error)
    throw error
  }
}

// Get hidden gems
export const getHiddenGems = async (filters?: SearchFilters): Promise<PaginatedResult<PointOfInterest>> => {
  try {
    // Check cache first
    const cachedData = await getCache<PointOfInterest[]>(CACHE_KEYS.POIS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const hiddenGems = cachedData.filter((poi) => poi.isHiddenGem === true)
      return filterAndPaginatePOIs(hiddenGems, filters)
    }

    // Simulate API call
    await delay(1000)

    const hiddenGems = mockPOIs.filter((poi) => poi.isHiddenGem === true)
    return filterAndPaginatePOIs(hiddenGems, filters)
  } catch (error) {
    console.error("Error fetching hidden gems:", error)
    throw error
  }
}

// Get POIs near coordinates
export const getPOIsNearCoordinates = async (
  coordinates: Coordinates,
  radiusKm = 5,
  filters?: SearchFilters,
): Promise<PaginatedResult<PointOfInterest>> => {
  try {
    // Check cache first
    const cachedData = await getCache<PointOfInterest[]>(CACHE_KEYS.POIS, CACHE_EXPIRATION.MEDIUM)
    let nearbyPOIs: PointOfInterest[] = []

    if (cachedData) {
      nearbyPOIs = cachedData.filter((poi) => {
        const distance = calculateDistance(
          coordinates.latitude,
          coordinates.longitude,
          poi.coordinates.latitude,
          poi.coordinates.longitude,
        )
        return distance <= radiusKm
      })
    } else {
      // Simulate API call
      await delay(1000)

      nearbyPOIs = mockPOIs.filter((poi) => {
        const distance = calculateDistance(
          coordinates.latitude,
          coordinates.longitude,
          poi.coordinates.latitude,
          poi.coordinates.longitude,
        )
        return distance <= radiusKm
      })

      // Cache the data
      await setCache(CACHE_KEYS.POIS, mockPOIs)
    }

    return filterAndPaginatePOIs(nearbyPOIs, filters)
  } catch (error) {
    console.error("Error fetching POIs near coordinates:", error)
    throw error
  }
}

// Helper function to filter and paginate cities
const filterAndPaginateCities = (cities: City[], filters?: SearchFilters): PaginatedResult<City> => {
  let filteredCities = [...cities]

  if (filters) {
    // Apply query filter
    if (filters.query) {
      const query = filters.query.toLowerCase()
      filteredCities = filteredCities.filter(
        (city) =>
          city.name.toLowerCase().includes(query) ||
          city.country.toLowerCase().includes(query) ||
          city.region.toLowerCase().includes(query),
      )
    }

    // Apply sorting
    if (filters.sortBy) {
      switch (filters.sortBy) {
        case "relevance":
          // Default order
          break
        case "distance":
          // Would need user's location for this
          break
        case "rating":
          // Cities don't have ratings in our model
          break
        case "price_low":
        case "price_high":
          // Cities don't have prices in our model
          break
      }
    }
  }

  // Apply pagination
  const limit = filters?.limit || 10
  const offset = filters?.offset || 0
  const paginatedCities = filteredCities.slice(offset, offset + limit)

  return {
    items: paginatedCities,
    total: filteredCities.length,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit,
    hasMore: offset + limit < filteredCities.length,
  }
}

// Helper function to filter and paginate POIs
const filterAndPaginatePOIs = (pois: PointOfInterest[], filters?: SearchFilters): PaginatedResult<PointOfInterest> => {
  let filteredPOIs = [...pois]

  if (filters) {
    // Apply query filter
    if (filters.query) {
      const query = filters.query.toLowerCase()
      filteredPOIs = filteredPOIs.filter(
        (poi) =>
          poi.name.toLowerCase().includes(query) ||
          poi.city.toLowerCase().includes(query) ||
          poi.country.toLowerCase().includes(query) ||
          poi.description?.toLowerCase().includes(query) ||
          poi.tags?.some((tag) => tag.toLowerCase().includes(query)),
      )
    }

    // Apply category filter
    if (filters.categories && filters.categories.length > 0) {
      filteredPOIs = filteredPOIs.filter((poi) => filters.categories!.includes(poi.type))
    }

    // Apply rating filter
    if (filters.rating) {
      filteredPOIs = filteredPOIs.filter((poi) => (poi.rating || 0) >= (filters.rating || 0))
    }

    // Apply open now filter
    if (filters.openNow) {
      const now = new Date()
      const day = now.getDay()
      const time = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`

      const dayMap: Record<number, keyof OpeningHours> = {
        0: "sunday",
        1: "monday",
        2: "tuesday",
        3: "wednesday",
        4: "thursday",
        5: "friday",
        6: "saturday",
      }

      filteredPOIs = filteredPOIs.filter((poi) => {
        if (!poi.openingHours) return false

        const dayHours = poi.openingHours[dayMap[day]]
        if (!dayHours || dayHours.length === 0) return false

        return dayHours.some((hours) => hours.open <= time && time <= hours.close)
      })
    }

    // Apply features filter
    if (filters.features && filters.features.length > 0) {
      filteredPOIs = filteredPOIs.filter((poi) => filters.features!.some((feature) => poi.tags?.includes(feature)))
    }

    // Apply sorting
    if (filters.sortBy) {
      switch (filters.sortBy) {
        case "relevance":
          // Default order
          break
        case "distance":
          // Would need user's location for this
          break
        case "rating":
          filteredPOIs.sort((a, b) => (b.rating || 0) - (a.rating || 0))
          break
        case "price_low":
          filteredPOIs.sort((a, b) => (a.entryFee?.amount || 0) - (b.entryFee?.amount || 0))
          break
        case "price_high":
          filteredPOIs.sort((a, b) => (b.entryFee?.amount || 0) - (a.entryFee?.amount || 0))
          break
      }
    }
  }

  // Apply pagination
  const limit = filters?.limit || 10
  const offset = filters?.offset || 0
  const paginatedPOIs = filteredPOIs.slice(offset, offset + limit)

  return {
    items: paginatedPOIs,
    total: filteredPOIs.length,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit,
    hasMore: offset + limit < filteredPOIs.length,
  }
}
