import type {
  WeatherForecast,
  WeatherCondition,
  WeatherAlert,
  Event,
  SearchFilters,
  PaginatedResult,
  Coordinates,
  EventCategory,
} from "./types"
import { CACHE_KEYS, CACHE_EXPIRATION, getCache, setCache, delay } from "./utils"

// Mock data for weather forecasts
const mockWeatherForecasts: WeatherForecast[] = [
  {
    location: {
      city: "Paris",
      country: "France",
      coordinates: { latitude: 48.8566, longitude: 2.3522 },
    },
    current: {
      temperature: 22,
      feelsLike: 23,
      humidity: 65,
      windSpeed: 10,
      windDirection: 180,
      pressure: 1015,
      uvIndex: 5,
      visibility: 10,
      condition: "partly-cloudy",
      icon: "partly-cloudy-day",
      precipitation: 0,
      timestamp: new Date(),
    },
    hourly: Array.from({ length: 24 }, (_, i) => ({
      timestamp: new Date(Date.now() + i * 3600 * 1000),
      temperature: 22 + Math.sin(i / 3) * 5,
      feelsLike: 23 + Math.sin(i / 3) * 5,
      humidity: 65 + Math.sin(i / 6) * 10,
      windSpeed: 10 + Math.sin(i / 4) * 5,
      windDirection: 180 + Math.sin(i / 2) * 90,
      precipitation: Math.max(0, Math.sin(i / 4) * 2),
      precipitationProbability: Math.max(0, Math.sin(i / 4) * 50),
      condition: i % 8 === 0 ? "rain" : "partly-cloudy",
      icon: i % 8 === 0 ? "rain" : "partly-cloudy-day",
    })),
    daily: Array.from({ length: 7 }, (_, i) => ({
      date: new Date(Date.now() + i * 24 * 3600 * 1000),
      sunrise: new Date(Date.now() + i * 24 * 3600 * 1000 + 6 * 3600 * 1000),
      sunset: new Date(Date.now() + i * 24 * 3600 * 1000 + 20 * 3600 * 1000),
      temperatureMin: 18 + Math.sin(i / 2) * 3,
      temperatureMax: 27 + Math.sin(i / 2) * 3,
      humidity: 65 + Math.sin(i / 3) * 10,
      windSpeed: 10 + Math.sin(i / 2) * 5,
      windDirection: 180 + Math.sin(i) * 90,
      precipitation: Math.max(0, Math.sin(i / 2) * 5),
      precipitationProbability: Math.max(0, Math.sin(i / 2) * 40),
      condition: i % 3 === 0 ? "rain" : "partly-cloudy",
      icon: i % 3 === 0 ? "rain" : "partly-cloudy-day",
    })),
    alerts: [
      {
        type: "rain",
        severity: "moderate",
        title: "Heavy Rain Warning",
        description: "Heavy rain expected in the afternoon. Potential for localized flooding.",
        startTime: new Date(Date.now() + 8 * 3600 * 1000),
        endTime: new Date(Date.now() + 14 * 3600 * 1000),
        source: "Météo-France",
      },
    ],
    updatedAt: new Date(),
  },
  {
    location: {
      city: "Tokyo",
      country: "Japan",
      coordinates: { latitude: 35.6762, longitude: 139.6503 },
    },
    current: {
      temperature: 28,
      feelsLike: 30,
      humidity: 75,
      windSpeed: 8,
      windDirection: 90,
      pressure: 1010,
      uvIndex: 7,
      visibility: 8,
      condition: "clear",
      icon: "clear-day",
      precipitation: 0,
      timestamp: new Date(),
    },
    hourly: Array.from({ length: 24 }, (_, i) => ({
      timestamp: new Date(Date.now() + i * 3600 * 1000),
      temperature: 28 + Math.sin(i / 3) * 4,
      feelsLike: 30 + Math.sin(i / 3) * 4,
      humidity: 75 + Math.sin(i / 6) * 10,
      windSpeed: 8 + Math.sin(i / 4) * 4,
      windDirection: 90 + Math.sin(i / 2) * 45,
      precipitation: 0,
      precipitationProbability: 0,
      condition: "clear",
      icon: i >= 6 && i <= 18 ? "clear-day" : "clear-night",
    })),
    daily: Array.from({ length: 7 }, (_, i) => ({
      date: new Date(Date.now() + i * 24 * 3600 * 1000),
      sunrise: new Date(Date.now() + i * 24 * 3600 * 1000 + 5 * 3600 * 1000),
      sunset: new Date(Date.now() + i * 24 * 3600 * 1000 + 19 * 3600 * 1000),
      temperatureMin: 24 + Math.sin(i / 2) * 2,
      temperatureMax: 32 + Math.sin(i / 2) * 2,
      humidity: 75 + Math.sin(i / 3) * 10,
      windSpeed: 8 + Math.sin(i / 2) * 4,
      windDirection: 90 + Math.sin(i) * 45,
      precipitation: 0,
      precipitationProbability: 0,
      condition: "clear",
      icon: "clear-day",
    })),
    alerts: [],
    updatedAt: new Date(),
  },
  {
    location: {
      city: "New York",
      country: "United States",
      coordinates: { latitude: 40.7128, longitude: -74.006 },
    },
    current: {
      temperature: 25,
      feelsLike: 27,
      humidity: 60,
      windSpeed: 12,
      windDirection: 270,
      pressure: 1012,
      uvIndex: 6,
      visibility: 9,
      condition: "cloudy",
      icon: "cloudy",
      precipitation: 0,
      timestamp: new Date(),
    },
    hourly: Array.from({ length: 24 }, (_, i) => ({
      timestamp: new Date(Date.now() + i * 3600 * 1000),
      temperature: 25 + Math.sin(i / 3) * 5,
      feelsLike: 27 + Math.sin(i / 3) * 5,
      humidity: 60 + Math.sin(i / 6) * 15,
      windSpeed: 12 + Math.sin(i / 4) * 6,
      windDirection: 270 + Math.sin(i / 2) * 45,
      precipitation: Math.max(0, Math.sin(i / 3) * 3),
      precipitationProbability: Math.max(0, Math.sin(i / 3) * 60),
      condition: i % 6 === 0 ? "rain" : "cloudy",
      icon: i % 6 === 0 ? "rain" : "cloudy",
    })),
    daily: Array.from({ length: 7 }, (_, i) => ({
      date: new Date(Date.now() + i * 24 * 3600 * 1000),
      sunrise: new Date(Date.now() + i * 24 * 3600 * 1000 + 5.5 * 3600 * 1000),
      sunset: new Date(Date.now() + i * 24 * 3600 * 1000 + 20.5 * 3600 * 1000),
      temperatureMin: 20 + Math.sin(i / 2) * 3,
      temperatureMax: 30 + Math.sin(i / 2) * 3,
      humidity: 60 + Math.sin(i / 3) * 15,
      windSpeed: 12 + Math.sin(i / 2) * 6,
      windDirection: 270 + Math.sin(i) * 45,
      precipitation: Math.max(0, Math.sin(i / 2) * 10),
      precipitationProbability: Math.max(0, Math.sin(i / 2) * 50),
      condition: i % 3 === 0 ? "rain" : "cloudy",
      icon: i % 3 === 0 ? "rain" : "cloudy",
    })),
    alerts: [
      {
        type: "thunderstorm",
        severity: "moderate",
        title: "Thunderstorm Watch",
        description: "Thunderstorms possible in the evening. Stay indoors if possible.",
        startTime: new Date(Date.now() + 10 * 3600 * 1000),
        endTime: new Date(Date.now() + 16 * 3600 * 1000),
        source: "National Weather Service",
      },
    ],
    updatedAt: new Date(),
  },
]

// Mock data for events
const mockEvents: Event[] = [
  {
    id: "event-001",
    name: "Paris Jazz Festival",
    description: "Annual jazz festival featuring local and international artists.",
    category: "music",
    startTime: new Date(Date.now() + 5 * 24 * 3600 * 1000),
    endTime: new Date(Date.now() + 12 * 24 * 3600 * 1000),
    coordinates: { latitude: 48.8566, longitude: 2.3522 },
    venue: "Parc Floral de Paris",
    address: "Route de la Pyramide, 75012 Paris, France",
    city: "Paris",
    country: "France",
    price: {
      amount: 25,
      currency: "EUR",
    },
    images: [
      "https://images.unsplash.com/photo-1514525253161-7a46d19cd819",
      "https://images.unsplash.com/photo-1511192336575-5a79af67a629",
    ],
    url: "https://www.parisjazzfestival.com",
    organizer: "Paris Cultural Department",
    tags: ["jazz", "music", "festival", "outdoor"],
    attendingCount: 5000,
    isFree: false,
    createdAt: new Date("2023-01-15T00:00:00Z"),
    updatedAt: new Date("2023-05-20T00:00:00Z"),
  },
  {
    id: "event-002",
    name: "Tokyo Anime Convention",
    description: "The largest anime convention in Japan, featuring exhibitions, cosplay, and special guests.",
    category: "exhibition",
    startTime: new Date(Date.now() + 15 * 24 * 3600 * 1000),
    endTime: new Date(Date.now() + 17 * 24 * 3600 * 1000),
    coordinates: { latitude: 35.6298, longitude: 139.7945 },
    venue: "Tokyo Big Sight",
    address: "3-11-1 Ariake, Koto City, Tokyo 135-0063, Japan",
    city: "Tokyo",
    country: "Japan",
    price: {
      amount: 3000,
      currency: "JPY",
    },
    images: [
      "https://images.unsplash.com/photo-1560169897-fc0cdbdfa4d5",
      "https://images.unsplash.com/photo-1578950435899-d1c1bf932b1f",
    ],
    url: "https://www.tokyoanimecon.jp",
    organizer: "Anime Association of Japan",
    tags: ["anime", "cosplay", "convention", "exhibition"],
    attendingCount: 50000,
    isFree: false,
    createdAt: new Date("2023-02-01T00:00:00Z"),
    updatedAt: new Date("2023-05-10T00:00:00Z"),
  },
  {
    id: "event-003",
    name: "New York Food Festival",
    description:
      "A celebration of New York's diverse culinary scene with food stalls, cooking demonstrations, and tastings.",
    category: "food",
    startTime: new Date(Date.now() + 3 * 24 * 3600 * 1000),
    endTime: new Date(Date.now() + 5 * 24 * 3600 * 1000),
    coordinates: { latitude: 40.7831, longitude: -73.9712 },
    venue: "Central Park",
    address: "Central Park, New York, NY 10022, USA",
    city: "New York",
    country: "United States",
    price: {
      amount: 15,
      currency: "USD",
    },
    images: [
      "https://images.unsplash.com/photo-1555939594-58d7cb561ad1",
      "https://images.unsplash.com/photo-1504674900247-0877df9cc836",
    ],
    url: "https://www.nyfoodfestival.com",
    organizer: "NYC Food & Wine",
    tags: ["food", "festival", "culinary", "tasting"],
    attendingCount: 25000,
    isFree: false,
    createdAt: new Date("2023-01-20T00:00:00Z"),
    updatedAt: new Date("2023-05-15T00:00:00Z"),
  },
  {
    id: "event-004",
    name: "Rome Art Exhibition",
    description: "Contemporary art exhibition featuring works from emerging Italian artists.",
    category: "arts",
    startTime: new Date(Date.now() + 10 * 24 * 3600 * 1000),
    endTime: new Date(Date.now() + 30 * 24 * 3600 * 1000),
    coordinates: { latitude: 41.9028, longitude: 12.4964 },
    venue: "Galleria Nazionale d'Arte Moderna",
    address: "Viale delle Belle Arti, 131, 00197 Roma RM, Italy",
    city: "Rome",
    country: "Italy",
    price: {
      amount: 12,
      currency: "EUR",
    },
    images: [
      "https://images.unsplash.com/photo-1531259683007-016a7b628fc3",
      "https://images.unsplash.com/photo-1518998053901-5348d3961a04",
    ],
    url: "https://www.romartexhibition.it",
    organizer: "Italian Arts Council",
    tags: ["art", "exhibition", "contemporary", "culture"],
    attendingCount: 8000,
    isFree: false,
    createdAt: new Date("2023-02-15T00:00:00Z"),
    updatedAt: new Date("2023-05-05T00:00:00Z"),
  },
  {
    id: "event-005",
    name: "Sydney Harbor Festival",
    description: "Annual festival celebrating Sydney's maritime heritage with boat parades, music, and fireworks.",
    category: "festival",
    startTime: new Date(Date.now() + 20 * 24 * 3600 * 1000),
    endTime: new Date(Date.now() + 22 * 24 * 3600 * 1000),
    coordinates: { latitude: -33.8568, longitude: 151.2153 },
    venue: "Sydney Harbor",
    address: "Circular Quay, Sydney NSW 2000, Australia",
    city: "Sydney",
    country: "Australia",
    price: {
      amount: 0,
      currency: "AUD",
    },
    images: [
      "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9",
      "https://images.unsplash.com/photo-1524293581917-878a6d017c71",
    ],
    url: "https://www.sydneyharborfestival.com.au",
    organizer: "City of Sydney",
    tags: ["festival", "harbor", "fireworks", "boats", "music"],
    attendingCount: 100000,
    isFree: true,
    createdAt: new Date("2023-03-01T00:00:00Z"),
    updatedAt: new Date("2023-05-12T00:00:00Z"),
  },
]

// Get weather forecast for a city
export const getWeatherForecast = async (cityName: string): Promise<WeatherForecast | null> => {
  try {
    // Check cache first
    const cachedData = await getCache<WeatherForecast[]>(CACHE_KEYS.WEATHER, CACHE_EXPIRATION.SHORT)
    if (cachedData) {
      const forecast = cachedData.find((forecast) => forecast.location.city.toLowerCase() === cityName.toLowerCase())
      return forecast || null
    }

    // Simulate API call
    await delay(1000)

    const forecast = mockWeatherForecasts.find(
      (forecast) => forecast.location.city.toLowerCase() === cityName.toLowerCase(),
    )

    if (forecast) {
      // Update timestamp
      forecast.updatedAt = new Date()
      forecast.current.timestamp = new Date()

      // Cache the data
      await setCache(CACHE_KEYS.WEATHER, mockWeatherForecasts)
    }

    return forecast || null
  } catch (error) {
    console.error(`Error fetching weather forecast for ${cityName}:`, error)
    throw error
  }
}

// Get weather forecast for coordinates
export const getWeatherForecastByCoordinates = async (coordinates: Coordinates): Promise<WeatherForecast | null> => {
  try {
    // Check cache first
    const cachedData = await getCache<WeatherForecast[]>(CACHE_KEYS.WEATHER, CACHE_EXPIRATION.SHORT)
    if (cachedData) {
      // Find the closest forecast
      let closestForecast: WeatherForecast | null = null
      let minDistance = Number.MAX_VALUE

      for (const forecast of cachedData) {
        const distance = Math.sqrt(
          Math.pow(forecast.location.coordinates.latitude - coordinates.latitude, 2) +
            Math.pow(forecast.location.coordinates.longitude - coordinates.longitude, 2),
        )
        if (distance < minDistance) {
          minDistance = distance
          closestForecast = forecast
        }
      }

      if (closestForecast && minDistance < 0.5) {
        // If within ~50km
        return closestForecast
      }
    }

    // Simulate API call
    await delay(1200)

    // Find the closest forecast
    let closestForecast: WeatherForecast | null = null
    let minDistance = Number.MAX_VALUE

    for (const forecast of mockWeatherForecasts) {
      const distance = Math.sqrt(
        Math.pow(forecast.location.coordinates.latitude - coordinates.latitude, 2) +
          Math.pow(forecast.location.coordinates.longitude - coordinates.longitude, 2),
      )
      if (distance < minDistance) {
        minDistance = distance
        closestForecast = forecast
      }
    }

    if (closestForecast) {
      // Update timestamp
      closestForecast.updatedAt = new Date()
      closestForecast.current.timestamp = new Date()

      // Cache the data
      await setCache(CACHE_KEYS.WEATHER, mockWeatherForecasts)
    }

    return closestForecast
  } catch (error) {
    console.error("Error fetching weather forecast for coordinates:", error)
    throw error
  }
}

// Get current weather condition for a city
export const getCurrentWeather = async (cityName: string): Promise<WeatherCondition | null> => {
  try {
    const forecast = await getWeatherForecast(cityName)
    return forecast ? forecast.current : null
  } catch (error) {
    console.error(`Error fetching current weather for ${cityName}:`, error)
    throw error
  }
}

// Get weather alerts for a city
export const getWeatherAlerts = async (cityName: string): Promise<WeatherAlert[]> => {
  try {
    const forecast = await getWeatherForecast(cityName)
    return forecast?.alerts || []
  } catch (error) {
    console.error(`Error fetching weather alerts for ${cityName}:`, error)
    throw error
  }
}

// Get all events
export const getEvents = async (filters?: SearchFilters): Promise<PaginatedResult<Event>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Event[]>(CACHE_KEYS.EVENTS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      return filterAndPaginateEvents(cachedData, filters)
    }

    // Simulate API call
    await delay(1200)

    // Cache the data
    await setCache(CACHE_KEYS.EVENTS, mockEvents)

    return filterAndPaginateEvents(mockEvents, filters)
  } catch (error) {
    console.error("Error fetching events:", error)
    throw error
  }
}

// Get event by ID
export const getEventById = async (id: string): Promise<Event | null> => {
  try {
    // Check cache first
    const cachedData = await getCache<Event[]>(CACHE_KEYS.EVENTS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const event = cachedData.find((event) => event.id === id)
      return event || null
    }

    // Simulate API call
    await delay(500)

    const event = mockEvents.find((event) => event.id === id)
    return event || null
  } catch (error) {
    console.error(`Error fetching event with ID ${id}:`, error)
    throw error
  }
}

// Get events by city
export const getEventsByCity = async (cityName: string, filters?: SearchFilters): Promise<PaginatedResult<Event>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Event[]>(CACHE_KEYS.EVENTS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const cityEvents = cachedData.filter((event) => event.city.toLowerCase() === cityName.toLowerCase())
      return filterAndPaginateEvents(cityEvents, filters)
    }

    // Simulate API call
    await delay(800)

    const cityEvents = mockEvents.filter((event) => event.city.toLowerCase() === cityName.toLowerCase())
    return filterAndPaginateEvents(cityEvents, filters)
  } catch (error) {
    console.error(`Error fetching events for city ${cityName}:`, error)
    throw error
  }
}

// Get events by category
export const getEventsByCategory = async (
  category: EventCategory,
  filters?: SearchFilters,
): Promise<PaginatedResult<Event>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Event[]>(CACHE_KEYS.EVENTS, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const categoryEvents = cachedData.filter((event) => event.category === category)
      return filterAndPaginateEvents(categoryEvents, filters)
    }

    // Simulate API call
    await delay(800)

    const categoryEvents = mockEvents.filter((event) => event.category === category)
    return filterAndPaginateEvents(categoryEvents, filters)
  } catch (error) {
    console.error(`Error fetching events of category ${category}:`, error)
    throw error
  }
}

// Get events near coordinates
export const getEventsNearCoordinates = async (
  coordinates: Coordinates,
  radiusKm = 10,
  filters?: SearchFilters,
): Promise<PaginatedResult<Event>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Event[]>(CACHE_KEYS.EVENTS, CACHE_EXPIRATION.MEDIUM)
    let nearbyEvents: Event[] = []

    if (cachedData) {
      nearbyEvents = cachedData.filter((event) => {
        const distance = Math.sqrt(
          Math.pow(event.coordinates.latitude - coordinates.latitude, 2) +
            Math.pow(event.coordinates.longitude - coordinates.longitude, 2),
        )
        // Rough approximation: 0.01 degrees ≈ 1km
        return distance <= radiusKm / 100
      })
    } else {
      // Simulate API call
      await delay(1000)

      nearbyEvents = mockEvents.filter((event) => {
        const distance = Math.sqrt(
          Math.pow(event.coordinates.latitude - coordinates.latitude, 2) +
            Math.pow(event.coordinates.longitude - coordinates.longitude, 2),
        )
        // Rough approximation: 0.01 degrees ≈ 1km
        return distance <= radiusKm / 100
      })

      // Cache the data
      await setCache(CACHE_KEYS.EVENTS, mockEvents)
    }

    return filterAndPaginateEvents(nearbyEvents, filters)
  } catch (error) {
    console.error("Error fetching events near coordinates:", error)
    throw error
  }
}

// Helper function to filter and paginate events
const filterAndPaginateEvents = (events: Event[], filters?: SearchFilters): PaginatedResult<Event> => {
  let filteredEvents = [...events]

  if (filters) {
    // Apply query filter
    if (filters.query) {
      const query = filters.query.toLowerCase()
      filteredEvents = filteredEvents.filter(
        (event) =>
          event.name.toLowerCase().includes(query) ||
          event.description?.toLowerCase().includes(query) ||
          event.city.toLowerCase().includes(query) ||
          event.venue?.toLowerCase().includes(query) ||
          event.tags?.some((tag) => tag.toLowerCase().includes(query)),
      )
    }

    // Apply category filter
    if (filters.categories && filters.categories.length > 0) {
      filteredEvents = filteredEvents.filter((event) => filters.categories!.includes(event.category))
    }

    // Apply price filter
    if (filters.priceRange) {
      if (filters.priceRange.min !== undefined) {
        filteredEvents = filteredEvents.filter((event) => (event.price?.amount || 0) >= (filters.priceRange?.min || 0))
      }
      if (filters.priceRange.max !== undefined) {
        filteredEvents = filteredEvents.filter((event) => (event.price?.amount || 0) <= (filters.priceRange?.max || 0))
      }
    }

    // Apply date filter (assuming we want events that start after now)
    filteredEvents = filteredEvents.filter((event) => event.startTime > new Date())

    // Apply free events filter
    if (filters.features && filters.features.includes("free")) {
      filteredEvents = filteredEvents.filter((event) => event.isFree)
    }

    // Apply sorting
    if (filters.sortBy) {
      switch (filters.sortBy) {
        case "relevance":
          // Default order
          break
        case "distance":
          // Would need user's location for this
          break
        case "rating":
          // Events don't have ratings in our model
          break
        case "price_low":
          filteredEvents.sort((a, b) => (a.price?.amount || 0) - (b.price?.amount || 0))
          break
        case "price_high":
          filteredEvents.sort((a, b) => (b.price?.amount || 0) - (a.price?.amount || 0))
          break
      }
    } else {
      // Default sort by start date
      filteredEvents.sort((a, b) => a.startTime.getTime() - b.startTime.getTime())
    }
  }

  // Apply pagination
  const limit = filters?.limit || 10
  const offset = filters?.offset || 0
  const paginatedEvents = filteredEvents.slice(offset, offset + limit)

  return {
    items: paginatedEvents,
    total: filteredEvents.length,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit,
    hasMore: offset + limit < filteredEvents.length,
  }
}
