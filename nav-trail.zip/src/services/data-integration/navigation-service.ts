import type { Route, Coordinates, TransportMode, SearchFilters, PaginatedResult } from "./types"
import { CACHE_KEYS, CACHE_EXPIRATION, getCache, setCache, delay, generateId } from "./utils"

// Mock data for routes
const mockRoutes: Route[] = [
  {
    id: "route-001",
    origin: { latitude: 48.8584, longitude: 2.2945 },
    destination: { latitude: 48.8606, longitude: 2.3376 },
    distance: 5200, // 5.2 km
    duration: 3900, // 65 minutes
    polyline: "gzriHkrfM??...", // Simplified polyline
    steps: [
      {
        instruction: "Head east on Avenue Gustave Eiffel toward Allée Jean Paulhan",
        distance: 130,
        duration: 94,
        coordinates: { latitude: 48.8584, longitude: 2.2945 },
        maneuver: "depart",
        streetName: "Avenue Gustave Eiffel",
      },
      {
        instruction: "Turn right onto Quai Branly",
        distance: 750,
        duration: 540,
        coordinates: { latitude: 48.8592, longitude: 2.2967 },
        maneuver: "turn-right",
        streetName: "Quai Branly",
      },
      {
        instruction: "Continue onto Pont d'Iéna",
        distance: 350,
        duration: 252,
        coordinates: { latitude: 48.8613, longitude: 2.3033 },
        maneuver: "continue",
        streetName: "Pont d'Iéna",
      },
      {
        instruction: "Continue onto Place de Varsovie",
        distance: 200,
        duration: 144,
        coordinates: { latitude: 48.8626, longitude: 2.3067 },
        maneuver: "continue",
        streetName: "Place de Varsovie",
      },
      {
        instruction: "Turn left onto Avenue de New York",
        distance: 1200,
        duration: 864,
        coordinates: { latitude: 48.8635, longitude: 2.3089 },
        maneuver: "turn-left",
        streetName: "Avenue de New York",
      },
      {
        instruction: "Turn right onto Pont de l'Alma",
        distance: 400,
        duration: 288,
        coordinates: { latitude: 48.8647, longitude: 2.3212 },
        maneuver: "turn-right",
        streetName: "Pont de l'Alma",
      },
      {
        instruction: "Continue onto Avenue du Général Eisenhower",
        distance: 800,
        duration: 576,
        coordinates: { latitude: 48.8658, longitude: 2.3256 },
        maneuver: "continue",
        streetName: "Avenue du Général Eisenhower",
      },
      {
        instruction: "Turn left onto Rue de Rivoli",
        distance: 1200,
        duration: 864,
        coordinates: { latitude: 48.8592, longitude: 2.3345 },
        maneuver: "turn-left",
        streetName: "Rue de Rivoli",
      },
      {
        instruction: "Arrive at the Louvre Museum",
        distance: 0,
        duration: 0,
        coordinates: { latitude: 48.8606, longitude: 2.3376 },
        maneuver: "arrive",
        streetName: "Rue de Rivoli",
      },
    ],
    transportMode: "walking",
    trafficLevel: "low",
    createdAt: new Date("2023-01-15T10:30:00Z"),
  },
  {
    id: "route-002",
    origin: { latitude: 40.7829, longitude: -73.9654 },
    destination: { latitude: 40.7484, longitude: -73.9857 },
    distance: 4800, // 4.8 km
    duration: 1800, // 30 minutes
    polyline: "??...", // Simplified polyline
    steps: [
      {
        instruction: "Head south on Central Park West",
        distance: 1500,
        duration: 600,
        coordinates: { latitude: 40.7829, longitude: -73.9654 },
        maneuver: "depart",
        streetName: "Central Park West",
      },
      {
        instruction: "Turn right onto W 59th St",
        distance: 800,
        duration: 300,
        coordinates: { latitude: 40.7712, longitude: -73.9679 },
        maneuver: "turn-right",
        streetName: "W 59th St",
      },
      {
        instruction: "Turn left onto 6th Ave",
        distance: 1200,
        duration: 450,
        coordinates: { latitude: 40.7667, longitude: -73.9771 },
        maneuver: "turn-left",
        streetName: "6th Ave",
      },
      {
        instruction: "Turn right onto W 34th St",
        distance: 1300,
        duration: 450,
        coordinates: { latitude: 40.7539, longitude: -73.9831 },
        maneuver: "turn-right",
        streetName: "W 34th St",
      },
      {
        instruction: "Arrive at Empire State Building",
        distance: 0,
        duration: 0,
        coordinates: { latitude: 40.7484, longitude: -73.9857 },
        maneuver: "arrive",
        streetName: "W 34th St",
      },
    ],
    transportMode: "driving",
    trafficLevel: "moderate",
    createdAt: new Date("2023-02-20T15:45:00Z"),
  },
  {
    id: "route-003",
    origin: { latitude: 35.7101, longitude: 139.8107 },
    destination: { latitude: 35.6895, longitude: 139.6917 },
    distance: 12500, // 12.5 km
    duration: 2700, // 45 minutes
    polyline: "??...", // Simplified polyline
    steps: [
      {
        instruction: "Head west on Oshiage Ekimae Dori",
        distance: 300,
        duration: 60,
        coordinates: { latitude: 35.7101, longitude: 139.8107 },
        maneuver: "depart",
        streetName: "Oshiage Ekimae Dori",
      },
      {
        instruction: "Turn left onto Keiyo Doro",
        distance: 2500,
        duration: 480,
        coordinates: { latitude: 35.7098, longitude: 139.8074 },
        maneuver: "turn-left",
        streetName: "Keiyo Doro",
      },
      {
        instruction: "Take the ramp onto Shuto Expressway",
        distance: 8000,
        duration: 1800,
        coordinates: { latitude: 35.6912, longitude: 139.7856 },
        maneuver: "ramp",
        streetName: "Shuto Expressway",
      },
      {
        instruction: "Take exit toward Shibuya",
        distance: 1200,
        duration: 240,
        coordinates: { latitude: 35.6823, longitude: 139.7103 },
        maneuver: "exit",
        streetName: "Exit",
      },
      {
        instruction: "Turn right onto Meiji Dori",
        distance: 500,
        duration: 120,
        coordinates: { latitude: 35.6867, longitude: 139.6987 },
        maneuver: "turn-right",
        streetName: "Meiji Dori",
      },
      {
        instruction: "Arrive at Shibuya Crossing",
        distance: 0,
        duration: 0,
        coordinates: { latitude: 35.6895, longitude: 139.6917 },
        maneuver: "arrive",
        streetName: "Meiji Dori",
      },
    ],
    transportMode: "driving",
    trafficLevel: "heavy",
    tolls: [
      {
        location: { latitude: 35.6912, longitude: 139.7856 },
        price: 500,
        currency: "JPY",
        name: "Shuto Expressway Entrance",
      },
    ],
    createdAt: new Date("2023-03-10T09:15:00Z"),
  },
]

// Get route between two points
export const getRoute = async (
  origin: Coordinates,
  destination: Coordinates,
  transportMode: TransportMode = "driving",
): Promise<Route> => {
  try {
    // Simulate API call
    await delay(1500)

    // Generate a new route (in a real app, this would call a routing API)
    const route: Route = {
      id: generateId(),
      origin,
      destination,
      distance: Math.floor(Math.random() * 10000) + 1000, // Random distance between 1-11 km
      duration: Math.floor(Math.random() * 3600) + 600, // Random duration between 10-70 minutes
      polyline: "??...", // Simplified polyline
      steps: [
        {
          instruction: "Start your journey",
          distance: 0,
          duration: 0,
          coordinates: origin,
          maneuver: "depart",
        },
        {
          instruction: "Continue on the main road",
          distance: Math.floor(Math.random() * 5000) + 500,
          duration: Math.floor(Math.random() * 1800) + 300,
          coordinates: {
            latitude: (origin.latitude + destination.latitude) / 2,
            longitude: (origin.longitude + destination.longitude) / 2,
          },
          maneuver: "continue",
        },
        {
          instruction: "Arrive at your destination",
          distance: 0,
          duration: 0,
          coordinates: destination,
          maneuver: "arrive",
        },
      ],
      transportMode,
      trafficLevel: "moderate",
      createdAt: new Date(),
    }

    return route
  } catch (error) {
    console.error("Error getting route:", error)
    throw error
  }
}

// Get saved routes
export const getSavedRoutes = async (filters?: SearchFilters): Promise<PaginatedResult<Route>> => {
  try {
    // Check cache first
    const cachedData = await getCache<Route[]>(CACHE_KEYS.ROUTES, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      return filterAndPaginateRoutes(cachedData, filters)
    }

    // Simulate API call
    await delay(1000)

    // Cache the data
    await setCache(CACHE_KEYS.ROUTES, mockRoutes)

    return filterAndPaginateRoutes(mockRoutes, filters)
  } catch (error) {
    console.error("Error fetching saved routes:", error)
    throw error
  }
}

// Get route by ID
export const getRouteById = async (id: string): Promise<Route | null> => {
  try {
    // Check cache first
    const cachedData = await getCache<Route[]>(CACHE_KEYS.ROUTES, CACHE_EXPIRATION.MEDIUM)
    if (cachedData) {
      const route = cachedData.find((route) => route.id === id)
      return route || null
    }

    // Simulate API call
    await delay(500)

    const route = mockRoutes.find((route) => route.id === id)
    return route || null
  } catch (error) {
    console.error(`Error fetching route with ID ${id}:`, error)
    throw error
  }
}

// Save a route
export const saveRoute = async (route: Route): Promise<Route> => {
  try {
    // Check cache first
    const cachedData = await getCache<Route[]>(CACHE_KEYS.ROUTES, CACHE_EXPIRATION.MEDIUM)
    let routes = cachedData || mockRoutes

    // Add the new route
    const newRoute = {
      ...route,
      id: route.id || generateId(),
      createdAt: route.createdAt || new Date(),
    }

    routes = [newRoute, ...routes]

    // Update cache
    await setCache(CACHE_KEYS.ROUTES, routes)

    return newRoute
  } catch (error) {
    console.error("Error saving route:", error)
    throw error
  }
}

// Delete a route
export const deleteRoute = async (id: string): Promise<boolean> => {
  try {
    // Check cache first
    const cachedData = await getCache<Route[]>(CACHE_KEYS.ROUTES, CACHE_EXPIRATION.MEDIUM)
    if (!cachedData) {
      return false
    }

    // Filter out the route to delete
    const updatedRoutes = cachedData.filter((route) => route.id !== id)

    // Update cache
    await setCache(CACHE_KEYS.ROUTES, updatedRoutes)

    return true
  } catch (error) {
    console.error(`Error deleting route with ID ${id}:`, error)
    throw error
  }
}

// Helper function to filter and paginate routes
const filterAndPaginateRoutes = (routes: Route[], filters?: SearchFilters): PaginatedResult<Route> => {
  let filteredRoutes = [...routes]

  if (filters) {
    // Apply transport mode filter
    if (filters.categories && filters.categories.length > 0) {
      filteredRoutes = filteredRoutes.filter((route) => filters.categories!.includes(route.transportMode as string))
    }

    // Apply sorting
    if (filters.sortBy) {
      switch (filters.sortBy) {
        case "relevance":
          // Default order (by creation date)
          filteredRoutes.sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
          break
        case "distance":
          filteredRoutes.sort((a, b) => a.distance - b.distance)
          break
        case "rating":
          // Routes don't have ratings in our model
          break
        case "price_low":
          // Sort by toll costs if available
          filteredRoutes.sort(
            (a, b) =>
              (a.tolls?.reduce((sum, toll) => sum + (toll.price || 0), 0) || 0) -
              (b.tolls?.reduce((sum, toll) => sum + (toll.price || 0), 0) || 0),
          )
          break
        case "price_high":
          // Sort by toll costs if available
          filteredRoutes.sort(
            (a, b) =>
              (b.tolls?.reduce((sum, toll) => sum + (toll.price || 0), 0) || 0) -
              (a.tolls?.reduce((sum, toll) => sum + (toll.price || 0), 0) || 0),
          )
          break
      }
    }
  }

  // Apply pagination
  const limit = filters?.limit || 10
  const offset = filters?.offset || 0
  const paginatedRoutes = filteredRoutes.slice(offset, offset + limit)

  return {
    items: paginatedRoutes,
    total: filteredRoutes.length,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit,
    hasMore: offset + limit < filteredRoutes.length,
  }
}
