// Mock delay to simulate network request
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Generate AI trip plan
export const generateTripPlan = async (
  destination: string,
  startDate: Date,
  endDate: Date,
  budget: string,
  interests: string[],
  customPrompt?: string,
) => {
  // Simulate API call
  await delay(3000)

  // Calculate number of days
  const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1

  // Generate mock trip plan
  const tripPlan = {
    destination,
    startDate,
    endDate,
    budget,
    totalCost: budget === "budget" ? 450 : budget === "medium" ? 850 : 1500,
    totalActivities: days * 4,
    days: Array.from({ length: days }, (_, i) => ({
      date: new Date(startDate.getTime() + i * 24 * 60 * 60 * 1000),
      title: i === 0 ? "Arrival & Exploration" : i === days - 1 ? "Departure Day" : `Exploring ${destination}`,
      activities: generateActivities(destination, budget, interests, i),
    })),
  }

  return tripPlan
}

// Generate activities for a day
const generateActivities = (destination: string, budget: string, interests: string[], dayIndex: number) => {
  const budgetMultiplier = budget === "budget" ? 1 : budget === "medium" ? 2 : 3
  const activityTypes = [
    "sightseeing",
    "museum",
    "food",
    "shopping",
    "nature",
    "entertainment",
    "relaxation",
    "adventure",
  ]

  // Filter activity types based on interests
  const filteredTypes = activityTypes.filter((type) => {
    if (interests.includes("nature") && ["nature", "adventure"].includes(type)) return true
    if (interests.includes("history") && ["museum", "sightseeing"].includes(type)) return true
    if (interests.includes("food") && ["food"].includes(type)) return true
    if (interests.includes("adventure") && ["adventure", "nature"].includes(type)) return true
    if (interests.includes("art") && ["museum", "entertainment"].includes(type)) return true
    if (interests.includes("shopping") && ["shopping"].includes(type)) return true
    if (interests.includes("nightlife") && ["entertainment"].includes(type)) return true
    if (interests.includes("relaxation") && ["relaxation"].includes(type)) return true
    return interests.length === 0 // If no interests selected, include all types
  })

  // Generate 4-6 activities per day
  const numActivities = Math.floor(Math.random() * 3) + 4
  const activities = []

  // Start time at 9 AM
  let currentHour = 9
  let currentMinute = 0

  for (let i = 0; i < numActivities; i++) {
    // Format time
    const timeStr = `${currentHour}:${currentMinute === 0 ? "00" : currentMinute} ${currentHour >= 12 ? "PM" : "AM"}`

    // Get activity type
    const activityType = filteredTypes[Math.floor(Math.random() * filteredTypes.length)]

    // Generate activity
    const activity = generateActivity(destination, activityType, budgetMultiplier, timeStr)
    activities.push(activity)

    // Increment time
    currentHour += Math.floor(activity.duration / 60)
    currentMinute += activity.duration % 60
    if (currentMinute >= 60) {
      currentHour += 1
      currentMinute -= 60
    }

    // Add travel time between activities (15-30 minutes)
    const travelTime = Math.floor(Math.random() * 16) + 15
    currentMinute += travelTime
    if (currentMinute >= 60) {
      currentHour += 1
      currentMinute -= 60
    }

    // Convert to 12-hour format
    if (currentHour > 12) {
      currentHour -= 12
    }
  }

  return activities
}

// Generate a single activity
const generateActivity = (destination: string, type: string, budgetMultiplier: number, time: string) => {
  const activities = {
    sightseeing: [
      { name: "Visit the Eiffel Tower", location: "Champ de Mars", cost: 25 * budgetMultiplier, duration: 120 },
      { name: "Explore Central Park", location: "Manhattan", cost: 0, duration: 90 },
      { name: "Tour the Colosseum", location: "Rome", cost: 20 * budgetMultiplier, duration: 120 },
      { name: "Walk the Great Wall", location: "Beijing", cost: 30 * budgetMultiplier, duration: 180 },
      { name: "See the Statue of Liberty", location: "New York Harbor", cost: 25 * budgetMultiplier, duration: 150 },
    ],
    museum: [
      { name: "Louvre Museum", location: "Paris", cost: 15 * budgetMultiplier, duration: 180 },
      { name: "British Museum", location: "London", cost: 0, duration: 150 },
      { name: "Metropolitan Museum of Art", location: "New York", cost: 25 * budgetMultiplier, duration: 180 },
      { name: "Vatican Museums", location: "Vatican City", cost: 20 * budgetMultiplier, duration: 150 },
      { name: "National Museum", location: `${destination}`, cost: 10 * budgetMultiplier, duration: 120 },
    ],
    food: [
      { name: "Local Food Tour", location: `Downtown ${destination}`, cost: 50 * budgetMultiplier, duration: 180 },
      { name: "Lunch at Café Central", location: `${destination} Old Town`, cost: 30 * budgetMultiplier, duration: 90 },
      { name: "Dinner at Sunset Restaurant", location: "Waterfront", cost: 60 * budgetMultiplier, duration: 120 },
      { name: "Street Food Experience", location: "Market District", cost: 15 * budgetMultiplier, duration: 60 },
      { name: "Wine Tasting", location: "Vineyard Valley", cost: 40 * budgetMultiplier, duration: 120 },
    ],
    shopping: [
      { name: "Visit Local Market", location: "Market Square", cost: 0, duration: 90 },
      { name: "Shopping at Main Street", location: "City Center", cost: 100 * budgetMultiplier, duration: 120 },
      { name: "Souvenir Shopping", location: "Tourist District", cost: 50 * budgetMultiplier, duration: 60 },
      { name: "Visit the Mall", location: `${destination} Mall`, cost: 0, duration: 120 },
      { name: "Artisan Crafts Shopping", location: "Old Town", cost: 80 * budgetMultiplier, duration: 90 },
    ],
    nature: [
      {
        name: "Hike in National Park",
        location: `${destination} National Park`,
        cost: 10 * budgetMultiplier,
        duration: 240,
      },
      { name: "Beach Relaxation", location: "Coastal Beach", cost: 0, duration: 180 },
      { name: "Botanical Gardens", location: "City Gardens", cost: 15 * budgetMultiplier, duration: 120 },
      { name: "Scenic Viewpoint", location: "Mountain Overlook", cost: 0, duration: 90 },
      { name: "Nature Reserve Tour", location: "Wildlife Reserve", cost: 25 * budgetMultiplier, duration: 150 },
    ],
    entertainment: [
      { name: "Watch a Broadway Show", location: "Theater District", cost: 100 * budgetMultiplier, duration: 180 },
      { name: "Visit a Local Bar", location: "Nightlife District", cost: 40 * budgetMultiplier, duration: 120 },
      { name: "Live Music Performance", location: "Music Venue", cost: 35 * budgetMultiplier, duration: 150 },
      { name: "Cinema Experience", location: "City Center", cost: 15 * budgetMultiplier, duration: 120 },
      {
        name: "Cultural Performance",
        location: `${destination} Cultural Center`,
        cost: 30 * budgetMultiplier,
        duration: 90,
      },
    ],
    relaxation: [
      { name: "Spa Treatment", location: "Wellness Center", cost: 80 * budgetMultiplier, duration: 120 },
      { name: "Yoga Class", location: "Beachfront", cost: 20 * budgetMultiplier, duration: 60 },
      { name: "Meditation Session", location: "Zen Garden", cost: 15 * budgetMultiplier, duration: 60 },
      { name: "Hot Springs Visit", location: "Thermal Area", cost: 30 * budgetMultiplier, duration: 120 },
      { name: "Massage Therapy", location: "Spa Resort", cost: 70 * budgetMultiplier, duration: 90 },
    ],
    adventure: [
      { name: "Zip-lining Adventure", location: "Forest Canopy", cost: 60 * budgetMultiplier, duration: 120 },
      { name: "Scuba Diving", location: "Coral Reef", cost: 100 * budgetMultiplier, duration: 180 },
      { name: "Rock Climbing", location: "Mountain Face", cost: 50 * budgetMultiplier, duration: 150 },
      { name: "White Water Rafting", location: "River Rapids", cost: 70 * budgetMultiplier, duration: 180 },
      { name: "Paragliding Experience", location: "Coastal Cliffs", cost: 90 * budgetMultiplier, duration: 120 },
    ],
  }

  // Select a random activity of the given type
  const activityOptions = activities[type]
  const selectedActivity = activityOptions[Math.floor(Math.random() * activityOptions.length)]

  return {
    id: `activity-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    time,
    ...selectedActivity,
    type,
    description: `Enjoy this ${type} activity in ${destination}`,
    coordinates: {
      latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
      longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
    },
  }
}

// Get weather forecast
export const getWeatherForecast = async (destination: string, startDate: Date, endDate: Date) => {
  // Simulate API call
  await delay(1000)

  // Calculate number of days
  const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1

  // Weather conditions
  const conditions = ["sunny", "cloudy", "partly-cloudy", "rainy", "stormy", "snowy"]

  // Generate mock weather forecast
  const forecast = {
    destination,
    days: Array.from({ length: days }, () => ({
      condition: conditions[Math.floor(Math.random() * conditions.length)],
      temperature: Math.floor(Math.random() * 30) + 10, // 10-40°C
      precipitation: Math.floor(Math.random() * 100), // 0-100%
      humidity: Math.floor(Math.random() * 50) + 30, // 30-80%
      wind: Math.floor(Math.random() * 30), // 0-30 km/h
    })),
  }

  return forecast
}

// Get travel packages
export const getTravelPackages = async (destination: string, startDate: Date, endDate: Date, budget: string) => {
  // Simulate API call
  await delay(1500)

  // Calculate number of days
  const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1

  // Base price per day based on budget
  const basePricePerDay = budget === "budget" ? 100 : budget === "medium" ? 200 : 400

  // Generate mock travel packages
  const packages = [
    {
      id: "1",
      name: `${days}-Day Essential ${destination}`,
      description: `Experience the best of ${destination} with this ${days}-day package including hotel, transportation, and guided tours.`,
      price: Math.round(days * basePricePerDay * 0.9), // 10% discount
      rating: 4.2,
      reviewCount: 128,
      includes: ["Hotel", "Breakfast", "Airport Transfer", "City Tour"],
      image:
        "https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
    {
      id: "2",
      name: `${destination} Explorer Package`,
      description: `Discover the hidden gems of ${destination} with this comprehensive package designed for adventurous travelers.`,
      price: Math.round(days * basePricePerDay * 1.1), // 10% premium
      rating: 4.5,
      reviewCount: 89,
      includes: ["4-Star Hotel", "All Meals", "Private Guide", "Adventure Activities"],
      image:
        "https://images.unsplash.com/photo-1552521684-edc2a078660e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
    {
      id: "3",
      name: `Luxury ${destination} Getaway`,
      description: `Indulge in the ultimate luxury experience in ${destination} with premium accommodations and exclusive access to attractions.`,
      price: Math.round(days * basePricePerDay * 1.5), // 50% premium
      rating: 4.8,
      reviewCount: 64,
      includes: ["5-Star Hotel", "Gourmet Dining", "Private Transportation", "VIP Access"],
      image:
        "https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
  ]

  return packages
}

// Get food recommendations
export const getFoodRecommendations = async (location: string, cuisine?: string, budget?: string) => {
  // Simulate API call
  await delay(1200)

  // Budget multiplier
  const budgetMultiplier = budget === "budget" ? 1 : budget === "medium" ? 2 : 3

  // Generate mock restaurant recommendations
  const restaurants = [
    {
      id: "1",
      name: "The Local Kitchen",
      cuisine: "Local",
      priceRange: "$".repeat(budgetMultiplier),
      rating: 4.5,
      reviewCount: 324,
      address: `123 Main St, ${location}`,
      description: "Authentic local cuisine with fresh ingredients from the region.",
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
    {
      id: "2",
      name: "Gourmet Bistro",
      cuisine: "French",
      priceRange: "$".repeat(budgetMultiplier),
      rating: 4.7,
      reviewCount: 256,
      address: `456 Oak St, ${location}`,
      description: "Fine dining experience with a modern twist on classic French cuisine.",
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
    {
      id: "3",
      name: "Spice Garden",
      cuisine: "Indian",
      priceRange: "$".repeat(budgetMultiplier),
      rating: 4.3,
      reviewCount: 189,
      address: `789 Spice Alley, ${location}`,
      description: "Authentic Indian cuisine with a variety of spice levels to suit all tastes.",
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
    {
      id: "4",
      name: "Sushi Express",
      cuisine: "Japanese",
      priceRange: "$".repeat(budgetMultiplier),
      rating: 4.6,
      reviewCount: 210,
      address: `101 Sakura Blvd, ${location}`,
      description: "Fresh sushi and Japanese specialties prepared by master chefs.",
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
    {
      id: "5",
      name: "Taco Fiesta",
      cuisine: "Mexican",
      priceRange: "$".repeat(budgetMultiplier),
      rating: 4.4,
      reviewCount: 178,
      address: `202 Fiesta St, ${location}`,
      description: "Authentic Mexican street food with homemade salsas and fresh ingredients.",
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
  ]

  // Filter by cuisine if provided
  let filteredRestaurants = restaurants
  if (cuisine) {
    filteredRestaurants = restaurants.filter((r) => r.cuisine.toLowerCase() === cuisine.toLowerCase())
  }

  return filteredRestaurants
}

// Get hidden gems
export const getHiddenGems = async (location: string, interests: string[]) => {
  // Simulate API call
  await delay(1800)

  // Generate mock hidden gems
  const hiddenGems = [
    {
      id: "1",
      name: "Secret Garden",
      type: "nature",
      description: "A hidden oasis in the middle of the city with rare plant species and peaceful atmosphere.",
      rating: 4.8,
      reviewCount: 45,
      address: `Hidden Path 1, ${location}`,
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
    {
      id: "2",
      name: "Underground Jazz Club",
      type: "entertainment",
      description: "Local favorite jazz club with nightly performances by talented musicians.",
      rating: 4.7,
      reviewCount: 67,
      address: `Basement, 123 Jazz St, ${location}`,
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
    {
      id: "3",
      name: "Artisan Workshop",
      type: "art",
      description: "Visit local artisans creating traditional crafts using centuries-old techniques.",
      rating: 4.9,
      reviewCount: 32,
      address: `Craft Alley 5, ${location}`,
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
    {
      id: "4",
      name: "Hidden Waterfall",
      type: "nature",
      description: "A beautiful waterfall tucked away in the forest, accessible by a short hiking trail.",
      rating: 4.6,
      reviewCount: 89,
      address: `Forest Trail 7, ${location}`,
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
    {
      id: "5",
      name: "Local's Café",
      type: "food",
      description: "Cozy café frequented by locals with the best pastries in town and unique coffee blends.",
      rating: 4.5,
      reviewCount: 112,
      address: `Side Street 42, ${location}`,
      image:
        "https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      coordinates: {
        latitude: 37.7749 + (Math.random() - 0.5) * 0.1,
        longitude: -122.4194 + (Math.random() - 0.5) * 0.1,
      },
    },
  ]

  // Filter by interests if provided
  let filteredGems = hiddenGems
  if (interests && interests.length > 0) {
    filteredGems = hiddenGems.filter((gem) => {
      if (interests.includes("nature") && gem.type === "nature") return true
      if (interests.includes("art") && gem.type === "art") return true
      if (interests.includes("food") && gem.type === "food") return true
      if (interests.includes("entertainment") && gem.type === "entertainment") return true
      return false
    })
  }

  return filteredGems
}
