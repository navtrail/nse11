import AsyncStorage from "@react-native-async-storage/async-storage"

// Mock delay to simulate network request
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Mock user data
const userStats = {
  trailsCompleted: 24,
  totalDistance: 156, // km
  elevationGain: 4320, // m
  hoursActive: 48.5,
}

const userAchievements = [
  { id: 1, title: "Early Bird", description: "Complete 5 trails before 8 AM", icon: "sunrise", completed: true },
  { id: 2, title: "Mountain Goat", description: "Climb 5,000m in elevation", icon: "trending-up", completed: true },
  { id: 3, title: "Explorer", description: "Visit 10 different trail regions", icon: "compass", completed: false },
  { id: 4, title: "Photographer", description: "Share 20 trail photos", icon: "camera", completed: false },
  { id: 5, title: "Trail Runner", description: "Complete a trail in under 1 hour", icon: "stopwatch", completed: true },
  { id: 6, title: "Night Hiker", description: "Complete a trail after sunset", icon: "moon", completed: false },
]

const userTrails = [
  {
    id: "1",
    name: "Eagle Peak Trail",
    date: "2023-05-15",
    distance: 8.2,
    duration: 185, // minutes
    difficulty: "Moderate",
    image: "https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
  },
  {
    id: "2",
    name: "Redwood Forest Loop",
    date: "2023-04-30",
    distance: 5.4,
    duration: 120, // minutes
    difficulty: "Easy",
    image: "https://images.unsplash.com/photo-1552521684-edc2a078660e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
  },
]

// Get user stats
export const getUserStats = async () => {
  // Simulate API call
  await delay(800)
  return userStats
}

// Get user achievements
export const getUserAchievements = async () => {
  // Simulate API call
  await delay(1000)
  return userAchievements
}

// Get user completed trails
export const getUserTrails = async () => {
  // Simulate API call
  await delay(1200)
  return userTrails
}

// Update user settings
export const updateUserSettings = async (settings: any) => {
  // Simulate API call
  await delay(500)

  // Save settings to AsyncStorage
  for (const [key, value] of Object.entries(settings)) {
    await AsyncStorage.setItem(`settings:${key}`, String(value))
  }

  return true
}

// Get user settings
export const getUserSettings = async () => {
  // Default settings
  const defaultSettings = {
    notifications: true,
    locationTracking: true,
    darkMode: false,
    offlineMaps: true,
    metricUnits: true,
    saveTrailHistory: true,
    highQualityMaps: false,
    autoDownloadMaps: false,
  }

  // Get settings from AsyncStorage
  const settings = { ...defaultSettings }
  for (const key of Object.keys(defaultSettings)) {
    const value = await AsyncStorage.getItem(`settings:${key}`)
    if (value !== null) {
      settings[key] = value === "true"
    }
  }

  return settings
}

// Record completed trail
export const recordTrailCompletion = async (trailData: any) => {
  // Simulate API call
  await delay(1500)

  // In a real app, this would send data to the server
  // For now, we'll just return success
  return {
    success: true,
    message: "Trail recorded successfully",
  }
}
