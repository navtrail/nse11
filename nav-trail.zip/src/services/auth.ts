// Mock authentication service
// In a real app, this would connect to Firebase, Auth0, or your own backend

import { generateRandomAvatar } from "../utils/helpers"

// Simulated delay to mimic network request
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Mock user database
const users = [
  {
    uid: "1",
    email: "demo@example.com",
    password: "password123",
    displayName: "Demo User",
    photoURL: "https://via.placeholder.com/150",
  },
]

export const login = async (email: string, password: string) => {
  // Simulate API call
  await delay(1000)

  const user = users.find((u) => u.email === email && u.password === password)

  if (!user) {
    throw new Error("Invalid email or password")
  }

  // Don't return the password
  const { password: _, ...userWithoutPassword } = user
  return userWithoutPassword
}

export const signup = async (email: string, password: string, name: string) => {
  // Simulate API call
  await delay(1500)

  // Check if user already exists
  if (users.some((u) => u.email === email)) {
    throw new Error("Email already in use")
  }

  // Create new user
  const newUser = {
    uid: `user_${Date.now()}`,
    email,
    password,
    displayName: name,
    photoURL: generateRandomAvatar(name),
  }

  // Add to mock database
  users.push(newUser)

  // Don't return the password
  const { password: _, ...userWithoutPassword } = newUser
  return userWithoutPassword
}

export const logout = async () => {
  // Simulate API call
  await delay(500)
  return true
}

export const updateProfile = async (uid: string, data: any) => {
  // Simulate API call
  await delay(1000)

  const userIndex = users.findIndex((u) => u.uid === uid)

  if (userIndex === -1) {
    throw new Error("User not found")
  }

  // Update user
  users[userIndex] = {
    ...users[userIndex],
    ...data,
  }

  // Don't return the password
  const { password: _, ...userWithoutPassword } = users[userIndex]
  return userWithoutPassword
}
